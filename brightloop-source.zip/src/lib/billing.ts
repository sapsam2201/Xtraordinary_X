// Brightloop billing engine — pure logic shared by API routes and the seed script.
// No Next.js or auth imports here on purpose.

export type Cycle = 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'YEARLY'
export type PaymentTerms = 'DUE_ON_RECEIPT' | 'NET_15' | 'NET_30'
export type DiscountType = 'PERCENTAGE' | 'FIXED'
export type DiscountScope = 'PRODUCT' | 'SUBSCRIPTION'

export const PAYMENT_TERMS_DAYS: Record<PaymentTerms, number> = {
  DUE_ON_RECEIPT: 0,
  NET_15: 15,
  NET_30: 30,
}

export const PAYMENT_TERMS_LABELS: Record<PaymentTerms, string> = {
  DUE_ON_RECEIPT: 'Due on receipt',
  NET_15: 'Net 15 days',
  NET_30: 'Net 30 days',
}

export const CYCLE_LABELS: Record<Cycle, string> = {
  DAILY: 'Daily',
  WEEKLY: 'Weekly',
  MONTHLY: 'Monthly',
  YEARLY: 'Yearly',
}

export function r2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100
}

/** Add one billing cycle to a date (calendar-aware: monthly adds 1 month etc.) */
export function addCycle(date: Date, cycle: Cycle): Date {
  const d = new Date(date)
  switch (cycle) {
    case 'DAILY':
      d.setDate(d.getDate() + 1)
      break
    case 'WEEKLY':
      d.setDate(d.getDate() + 7)
      break
    case 'MONTHLY':
      d.setMonth(d.getMonth() + 1)
      break
    case 'YEARLY':
      d.setFullYear(d.getFullYear() + 1)
      break
  }
  return d
}

/** Monthly-normalised recurring value of an amount billed on a cycle. */
export function monthlyNormalized(amount: number, cycle: Cycle): number {
  switch (cycle) {
    case 'DAILY':
      return amount * 30
    case 'WEEKLY':
      return (amount * 52) / 12
    case 'YEARLY':
      return amount / 12
    default:
      return amount
  }
}

export type DiscountRuleLike = {
  id: string
  name: string
  type: DiscountType | string
  value: number
  scope: DiscountScope | string
  productId?: string | null
  minPurchase?: number | null
  minQuantity?: number | null
  startDate: Date | string
  endDate: Date | string
  maxUses?: number | null
  usedCount?: number
  active?: boolean
}

export type InvoiceLineInput = {
  productId?: string | null
  description: string
  quantity: number
  unitPrice: number
  taxRate: number
  sortOrder?: number
}

export type ComputedLine = InvoiceLineInput & {
  discount: number
  taxAmount: number
  netAmount: number
  total: number
}

export type ComputedInvoice = {
  lines: ComputedLine[]
  subtotal: number
  discountTotal: number
  discountNote: string
  taxTotal: number
  total: number
  usedDiscountIds: string[]
}

/**
 * Decide which discount rules apply to a subscription right now.
 * - PRODUCT scope: applies to matching product lines only.
 * - SUBSCRIPTION scope: applies to the whole invoice.
 * Honors date window, usage limits, min quantity and min purchase.
 */
export function pickApplicableDiscounts(
  rules: DiscountRuleLike[],
  lines: InvoiceLineInput[],
  onDate: Date
): { productRules: Record<string, DiscountRuleLike>; subscriptionRule: DiscountRuleLike | null } {
  const t = onDate.getTime()
  const eligible = rules.filter((r) => {
    if (r.active === false) return false
    const start = new Date(r.startDate).getTime()
    const end = new Date(r.endDate).getTime()
    // rule window must cover the billing date (end-of-day inclusive)
    if (t < start || t > end + 24 * 3600 * 1000 - 1) return false
    if (r.maxUses != null && (r.usedCount ?? 0) >= r.maxUses) return false
    return true
  })

  const productRules: Record<string, DiscountRuleLike> = {}
  let subscriptionRule: DiscountRuleLike | null = null

  const totalQty = lines.reduce((s, l) => s + l.quantity, 0)
  const totalAmount = lines.reduce((s, l) => s + l.quantity * l.unitPrice, 0)

  for (const rule of eligible) {
    if (rule.scope === 'PRODUCT' && rule.productId) {
      const matching = lines.filter((l) => l.productId === rule.productId)
      if (matching.length === 0) continue
      const okQty =
        rule.minQuantity == null || matching.some((l) => l.quantity >= (rule.minQuantity as number))
      const lineAmount = matching.reduce((s, l) => s + l.quantity * l.unitPrice, 0)
      const okAmt = rule.minPurchase == null || lineAmount >= (rule.minPurchase as number)
      if (okQty && okAmt) {
        // first eligible rule per product wins
        if (!productRules[rule.productId]) productRules[rule.productId] = rule
      }
    } else if (rule.scope === 'SUBSCRIPTION') {
      const okQty = rule.minQuantity == null || totalQty >= (rule.minQuantity as number)
      const okAmt = rule.minPurchase == null || totalAmount >= (rule.minPurchase as number)
      if (okQty && okAmt && !subscriptionRule) {
        subscriptionRule = rule
      }
    }
  }
  return { productRules, subscriptionRule }
}

/**
 * Compute an invoice from raw lines + applicable discount rules.
 * Taxes are calculated per line after discounts. The subscription-scope
 * discount is spread across lines proportionally so every amount reconciles.
 */
export function computeInvoice(
  lines: InvoiceLineInput[],
  discounts: { productRules: Record<string, DiscountRuleLike>; subscriptionRule: DiscountRuleLike | null }
): ComputedInvoice {
  const base = lines.map((l) => r2(l.quantity * l.unitPrice))
  const grandBase = r2(base.reduce((s, b) => s + b, 0))

  // per-line product-scope discount
  const productDiscount = base.map((b, i) => {
    const rule = lines[i].productId ? discounts.productRules[lines[i].productId as string] : undefined
    if (!rule) return 0
    let d =
      rule.type === 'PERCENTAGE'
        ? (b * rule.value) / 100
        : Math.min(rule.value, b)
    return r2(d)
  })

  // subscription-scope discount on the remainder, spread proportionally
  const afterProduct = r2(base.reduce((s, b, i) => s + (b - productDiscount[i]), 0))
  let subDiscountTotal = 0
  if (discounts.subscriptionRule) {
    const rule = discounts.subscriptionRule
    subDiscountTotal =
      rule.type === 'PERCENTAGE'
        ? r2((afterProduct * rule.value) / 100)
        : Math.min(rule.value, afterProduct)
    subDiscountTotal = r2(subDiscountTotal)
  }

  const subShare = base.map((b) => {
    if (subDiscountTotal <= 0 || grandBase <= 0) return 0
    return r2((subDiscountTotal * b) / grandBase)
  })
  // fix rounding drift on the last non-zero line
  const shareSum = r2(subShare.reduce((s, v) => s + v, 0))
  if (shareSum !== subDiscountTotal && subShare.length > 0) {
    for (let i = subShare.length - 1; i >= 0; i--) {
      if (subShare[i] > 0) {
        subShare[i] = r2(subShare[i] + (subDiscountTotal - shareSum))
        break
      }
    }
  }

  const computed: ComputedLine[] = lines.map((l, i) => {
    const discount = r2(productDiscount[i] + subShare[i])
    const netAmount = r2(base[i] - discount)
    const taxAmount = r2((netAmount * l.taxRate) / 100)
    return {
      ...l,
      discount,
      netAmount,
      taxAmount,
      total: r2(netAmount + taxAmount),
    }
  })

  const subtotal = r2(computed.reduce((s, l) => s + r2(l.quantity * l.unitPrice), 0))
  const discountTotal = r2(computed.reduce((s, l) => s + l.discount, 0))
  const taxTotal = r2(computed.reduce((s, l) => s + l.taxAmount, 0))
  const total = r2(computed.reduce((s, l) => s + l.total, 0))

  const usedDiscountIds: string[] = []
  const notes: string[] = []
  const seen = new Set<string>()
  for (const rule of Object.values(discounts.productRules)) {
    if (computed.some((l, i) => l.discount > 0 && lines[i].productId === rule.productId)) {
      usedDiscountIds.push(rule.id)
      if (!seen.has(rule.name)) {
        notes.push(`${rule.name}`)
        seen.add(rule.name)
      }
    }
  }
  if (discounts.subscriptionRule && subDiscountTotal > 0) {
    usedDiscountIds.push(discounts.subscriptionRule.id)
    if (!seen.has(discounts.subscriptionRule.name)) notes.push(discounts.subscriptionRule.name)
  }

  return {
    lines: computed,
    subtotal,
    discountTotal,
    discountNote: notes.join(', '),
    taxTotal,
    total,
    usedDiscountIds,
  }
}

export function statusLabel(status: string): string {
  const map: Record<string, string> = {
    DRAFT: 'Draft',
    QUOTATION: 'Quotation',
    CONFIRMED: 'Confirmed',
    ACTIVE: 'Active',
    PAUSED: 'Paused',
    CLOSED: 'Closed',
    PAID: 'Paid',
    CANCELLED: 'Cancelled',
  }
  return map[status] ?? status
}
