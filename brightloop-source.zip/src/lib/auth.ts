import crypto from 'crypto'
import { cookies, headers } from 'next/headers'
import { db } from '@/lib/db'

export { hashPassword, verifyPassword, validatePasswordPolicy, validateEmail } from '@/lib/password'
import { validateEmail, validatePasswordPolicy } from '@/lib/password'

export const SESSION_COOKIE = 'bl_session'
export const SESSION_HEADER = 'authorization'
const SESSION_DAYS = 30

// ---------- sessions ----------

export async function createSession(userId: string): Promise<string> {
  const token = crypto.randomBytes(32).toString('hex')
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000)
  await db.session.create({ data: { token, userId, expiresAt } })
  const jar = await cookies()
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    expires: expiresAt,
  })
  return token
}

/**
 * Resolve the session token for this request. Browsers that block cookies in
 * third-party iframes (e.g. embedded previews) send the token via the
 * Authorization header instead, so it takes precedence when present.
 */
export async function getRequestToken(): Promise<string | null> {
  const h = await headers()
  const auth = h.get(SESSION_HEADER)
  if (auth?.toLowerCase().startsWith('bearer ')) {
    const token = auth.slice(7).trim()
    if (token) return token
  }
  const jar = await cookies()
  return jar.get(SESSION_COOKIE)?.value ?? null
}

export async function destroySession(): Promise<void> {
  const token = await getRequestToken()
  if (token) {
    await db.session.deleteMany({ where: { token } })
  }
  const jar = await cookies()
  jar.delete(SESSION_COOKIE)
}

export type SafeUser = {
  id: string
  email: string
  name: string
  role: string
  customerId: string | null
}

export async function getSessionUser(): Promise<SafeUser | null> {
  const token = await getRequestToken()
  if (!token) return null
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })
  if (!session) return null
  if (session.expiresAt.getTime() < Date.now()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => {})
    return null
  }
  if (!session.user.isActive) return null
  return {
    id: session.user.id,
    email: session.user.email,
    name: session.user.name,
    role: session.user.role,
    customerId: session.user.customerId,
  }
}

// ---------- API helpers ----------

export class ApiError extends Error {
  status: number
  constructor(status: number, message: string) {
    super(message)
    this.status = status
  }
}

export function ok(data: unknown, status = 200) {
  return Response.json(data as object, { status })
}

export async function handle(fn: () => Promise<Response>): Promise<Response> {
  try {
    return await fn()
  } catch (err) {
    if (err instanceof ApiError) {
      return Response.json({ error: err.message }, { status: err.status })
    }
    console.error('[api] unexpected error:', err)
    const message = err instanceof Error ? err.message : 'Internal server error'
    return Response.json({ error: message }, { status: 500 })
  }
}

export async function requireUser(): Promise<SafeUser> {
  const user = await getSessionUser()
  if (!user) throw new ApiError(401, 'You must be signed in.')
  return user
}

export async function requireRole(...roles: string[]): Promise<SafeUser> {
  const user = await requireUser()
  if (!roles.includes(user.role)) {
    throw new ApiError(403, 'You do not have permission to perform this action.')
  }
  return user
}

export async function requireAdmin(): Promise<SafeUser> {
  return requireRole('ADMIN')
}
