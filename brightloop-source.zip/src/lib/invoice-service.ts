import { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import {
  PAYMENT_TERMS_DAYS,
  addCycle,
  computeInvoice,
  pickApplicableDiscounts,
  r2,
  type Cycle,
  type PaymentTerms,
} from '@/lib/billing'

/** Sequential document numbers: INV-0001, SUB-0001, PAY-0001 … */
export async function nextNumber(tx: Prisma.TransactionClient, key: string, prefix: string): Promise<string> {
  const c = await tx.counter.upsert({
    where: { key },
    update: { value: { increment: 1 } },
    create: { key, value: 1 },
  })
  return `${prefix}-${String(c.value).padStart(4, '0')}`
}

export type GenerateInvoiceResult = {
  invoice: { id: string; number: string; total: number; status: string }
  discountNames: string[]
}

/**
 * Create a DRAFT invoice from a subscription: customer details, product lines,
 * taxes and totals are filled automatically; discounts that are in force are
 * applied without anyone having to remember them.
 */
export async function generateInvoiceForSubscription(
  subscriptionId: string,
  opts?: { issueDate?: Date; skipBillingAdvance?: boolean }
): Promise<GenerateInvoiceResult> {
  const sub = await db.subscription.findUnique({
    where: { id: subscriptionId },
    include: {
      customer: true,
      plan: true,
      lines: { orderBy: { sortOrder: 'asc' } },
    },
  })
  if (!sub) throw new Error('Subscription not found')
  if (!['CONFIRMED', 'ACTIVE', 'PAUSED'].includes(sub.status) && !opts?.skipBillingAdvance) {
    throw new Error('Only confirmed or active subscriptions can be billed.')
  }
  if (sub.lines.length === 0) throw new Error('Subscription has no product lines to bill.')

  // never bill twice: an open invoice already exists for this subscription
  const open = await db.invoice.findFirst({
    where: { subscriptionId: sub.id, status: { in: ['DRAFT', 'CONFIRMED'] } },
  })
  if (open) throw new Error(`Invoice ${open.number} is already open for this subscription.`)

  const issueDate = opts?.issueDate ? startOfDay(opts.issueDate) : startOfDay(new Date())

  const lineInputs = sub.lines.map((l) => ({
    productId: l.productId,
    description: lineDescription(l),
    quantity: l.quantity,
    unitPrice: l.unitPrice,
    taxRate: l.taxRate,
    sortOrder: l.sortOrder,
  }))

  const rules = await db.discountRule.findMany({ where: { active: true } })
  const picked = pickApplicableDiscounts(rules, lineInputs, issueDate)
  const computed = computeInvoice(lineInputs, picked)

  const termsDays = PAYMENT_TERMS_DAYS[(sub.paymentTerms as PaymentTerms) ?? 'DUE_ON_RECEIPT'] ?? 0
  const dueDate = new Date(issueDate)
  dueDate.setDate(dueDate.getDate() + termsDays)

  const periodStart = sub.nextBillingDate ?? sub.startDate
  const periodEnd = sub.plan ? new Date(addCycle(periodStart, sub.plan.billingCycle as Cycle).getTime() - 24 * 3600 * 1000) : null

  const invoice = await db.$transaction(async (tx) => {
    const number = await nextNumber(tx, 'INV', 'INV')
    const created = await tx.invoice.create({
      data: {
        number,
        subscriptionId: sub.id,
        customerId: sub.customerId,
        status: 'DRAFT',
        issueDate,
        dueDate,
        subtotal: computed.subtotal,
        discountTotal: computed.discountTotal,
        discountNote: computed.discountNote || null,
        taxTotal: computed.taxTotal,
        total: computed.total,
        periodStart,
        periodEnd,
        notes: `Generated from subscription ${sub.number}`,
        lines: {
          create: computed.lines.map((l, i) => ({
            productId: l.productId ?? null,
            description: l.description,
            quantity: l.quantity,
            unitPrice: l.unitPrice,
            discount: l.discount,
            taxRate: l.taxRate,
            taxAmount: l.taxAmount,
            netAmount: l.netAmount,
            total: l.total,
            sortOrder: i,
          })),
        },
      },
    })
    if (computed.usedDiscountIds.length > 0) {
      await tx.discountRule.updateMany({
        where: { id: { in: computed.usedDiscountIds } },
        data: { usedCount: { increment: 1 } },
      })
    }
    if (!opts?.skipBillingAdvance && sub.plan) {
      await tx.subscription.update({
        where: { id: sub.id },
        data: { nextBillingDate: addCycle(periodStart, sub.plan.billingCycle as Cycle) },
      })
    }
    return created
  })

  return {
    invoice: { id: invoice.id, number: invoice.number, total: invoice.total, status: invoice.status },
    discountNames: computed.discountNote ? computed.discountNote.split(', ') : [],
  }
}

function lineDescription(line: {
  product?: { name: string } | null
  description?: string | null
}): string {
  return line.description || line.product?.name || 'Item'
}

export function startOfDay(d: Date): Date {
  const x = new Date(d)
  x.setHours(0, 0, 0, 0)
  return x
}

/** Record a payment against an invoice; flips the invoice to PAID when settled. */
export async function recordPayment(input: {
  invoiceId: string
  method: string
  amount: number
  date?: Date
  note?: string | null
  /** when the caller already knows the customer (portal users) */
  customerId?: string
}): Promise<{ paymentId: string; invoiceStatus: string; balance: number }> {
  const invoice = await db.invoice.findUnique({ where: { id: input.invoiceId } })
  if (!invoice) throw new Error('Invoice not found')
  if (invoice.status === 'CANCELLED') throw new Error('Cannot pay a cancelled invoice.')
  if (invoice.status === 'DRAFT') throw new Error('Confirm the invoice before recording a payment.')

  const amount = r2(input.amount)
  if (amount <= 0) throw new Error('Payment amount must be positive.')
  const balance = r2(invoice.total - invoice.amountPaid)
  if (amount > balance + 0.001) throw new Error(`Amount exceeds the outstanding balance (₹${balance.toFixed(2)}).`)

  const date = input.date ? startOfDay(input.date) : new Date()

  const result = await db.$transaction(async (tx) => {
    const number = await nextNumber(tx, 'PAY', 'PAY')
    const payment = await tx.payment.create({
      data: {
        number,
        invoiceId: invoice.id,
        customerId: input.customerId ?? invoice.customerId,
        method: input.method,
        amount,
        date,
        note: input.note ?? null,
      },
    })
    const amountPaid = r2(invoice.amountPaid + amount)
    const fullyPaid = amountPaid >= invoice.total - 0.001
    const updated = await tx.invoice.update({
      where: { id: invoice.id },
      data: {
        amountPaid,
        status: fullyPaid ? 'PAID' : invoice.status,
        paidAt: fullyPaid ? new Date() : invoice.paidAt,
      },
    })
    return { payment, invoice: updated }
  })

  return {
    paymentId: result.payment.id,
    invoiceStatus: result.invoice.status,
    balance: r2(result.invoice.total - result.invoice.amountPaid),
  }
}
