import { db } from '@/lib/db'
import { hashPassword } from '@/lib/password'
import {
  addCycle,
  computeInvoice,
  pickApplicableDiscounts,
  r2,
  PAYMENT_TERMS_DAYS,
  type Cycle,
  type PaymentTerms,
} from '@/lib/billing'

// ---------- deterministic RNG so the dataset is stable ----------
function mulberry32(seed: number) {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function startOfDay(d: Date): Date {
  const x = new Date(d)
  x.setHours(0, 0, 0, 0)
  return x
}

function daysAgo(n: number): Date {
  const d = startOfDay(new Date())
  d.setDate(d.getDate() - n)
  return d
}

function daysAhead(n: number): Date {
  return daysAgo(-n)
}

export type SeedSummary = {
  users: number
  customers: number
  products: number
  plans: number
  taxRules: number
  discounts: number
  templates: number
  subscriptions: number
  invoices: number
  payments: number
}

export async function runSeed(): Promise<SeedSummary> {
  const rng = mulberry32(20261031)
  const pick = <T,>(arr: T[]): T => arr[Math.floor(rng() * arr.length)]
  const ri = (min: number, max: number) => min + Math.floor(rng() * (max - min + 1))

  // ---------------- wipe ----------------
  await db.payment.deleteMany()
  await db.invoiceLine.deleteMany()
  await db.invoice.deleteMany()
  await db.subscriptionLine.deleteMany()
  await db.subscription.deleteMany()
  await db.templateLine.deleteMany()
  await db.quotationTemplate.deleteMany()
  await db.discountRule.deleteMany()
  await db.taxRule.deleteMany()
  await db.plan.deleteMany()
  await db.productVariant.deleteMany()
  await db.product.deleteMany()
  await db.customer.deleteMany()
  await db.passwordResetToken.deleteMany()
  await db.session.deleteMany()
  await db.user.deleteMany()
  await db.counter.deleteMany()

  const today = startOfDay(new Date())

  // ---------------- users ----------------
  const admin = await db.user.create({
    data: {
      email: 'admin@brightloop.com',
      name: 'Aarti Menon',
      role: 'ADMIN',
      passwordHash: hashPassword('Admin@123!'),
    },
  })
  await db.user.create({
    data: {
      email: 'maya@brightloop.com',
      name: 'Maya Iyer',
      role: 'STAFF',
      passwordHash: hashPassword('Staff@123!'),
    },
  })
  await db.user.create({
    data: {
      email: 'liam@brightloop.com',
      name: "Liam D'Souza",
      role: 'STAFF',
      passwordHash: hashPassword('Staff@123!'),
    },
  })

  // ---------------- products & variants ----------------
  const productSeed = [
    { name: 'Brightloop CRM', type: 'SOFTWARE', salesPrice: 499, costPrice: 180, notes: 'Core sales CRM: pipelines, contacts, deal tracking and reporting.' },
    { name: 'Brightloop Desk', type: 'SOFTWARE', salesPrice: 299, costPrice: 95, notes: 'Customer support desk with shared inbox, SLAs and canned replies.' },
    { name: 'Inventory Hub', type: 'SOFTWARE', salesPrice: 399, costPrice: 140, notes: 'Multi-warehouse stock management with reorder automation.' },
    { name: 'Analytics Suite', type: 'SOFTWARE', salesPrice: 599, costPrice: 210, notes: 'Dashboards, revenue analytics and scheduled export reports.' },
    { name: 'Email Conversations Add-on', type: 'ADDON', salesPrice: 49, costPrice: 12, notes: 'Per-seat add-on that syncs customer email threads into the CRM.' },
    { name: 'Extra Storage Pack', type: 'ADDON', salesPrice: 79, costPrice: 20, notes: 'Adds 250 GB of document storage to the workspace.' },
    { name: 'Priority Support', type: 'SERVICE', salesPrice: 99, costPrice: 30, notes: '4-hour response SLA with a named support engineer.' },
  ]
  const products: Record<string, { id: string; salesPrice: number }> = {}
  for (const p of productSeed) {
    const created = await db.product.create({ data: { ...p } })
    products[p.name] = { id: created.id, salesPrice: p.salesPrice }
  }

  // Choosing the Odoo brand adds 560 to the price (from the brief)
  await db.productVariant.createMany({
    data: [
      { productId: products['Brightloop CRM'].id, name: 'Brand', value: 'Brightloop', priceDelta: 0 },
      { productId: products['Brightloop CRM'].id, name: 'Brand', value: 'Odoo', priceDelta: 560 },
      { productId: products['Brightloop CRM'].id, name: 'Brand', value: 'Custom White-label', priceDelta: 1200 },
      { productId: products['Analytics Suite'].id, name: 'Edition', value: 'Standard', priceDelta: 0 },
      { productId: products['Analytics Suite'].id, name: 'Edition', value: 'Enterprise', priceDelta: 300 },
    ],
  })
  const variants = await db.productVariant.findMany()
  const crmVariants = variants.filter((v) => v.productId === products['Brightloop CRM'].id)
  const analyticsVariants = variants.filter((v) => v.productId === products['Analytics Suite'].id)

  // ---------------- tax rules ----------------
  const taxRules = await Promise.all(
    [
      { name: 'GST 18%', rate: 18 },
      { name: 'GST 12%', rate: 12 },
      { name: 'GST 5%', rate: 5 },
      { name: 'Export Zero Rate', rate: 0 },
    ].map((t) => db.taxRule.create({ data: t }))
  )

  // ---------------- plans ----------------
  async function makePlan(p: {
    name: string
    description: string
    productName: string
    price: number
    billingCycle: Cycle
    minQuantity: number
    availableFrom: Date
    availableTo?: Date | null
    autoClose: boolean
    canCloseEarly: boolean
    canPause: boolean
    canRenew: boolean
  }) {
    return db.plan.create({
      data: {
        name: p.name,
        description: p.description,
        productId: products[p.productName].id,
        price: p.price,
        billingCycle: p.billingCycle,
        minQuantity: p.minQuantity,
        availableFrom: p.availableFrom,
        availableTo: p.availableTo ?? null,
        autoClose: p.autoClose,
        canCloseEarly: p.canCloseEarly,
        canPause: p.canPause,
        canRenew: p.canRenew,
      },
    })
  }

  const planCrmStarter = await makePlan({
    name: 'CRM Starter', description: 'Brightloop CRM billed monthly. Pause, renew or close early any time.',
    productName: 'Brightloop CRM', price: 499, billingCycle: 'MONTHLY', minQuantity: 1,
    availableFrom: daysAgo(320), autoClose: false, canCloseEarly: true, canPause: true, canRenew: true,
  })
  const planCrmGrowth = await makePlan({
    name: 'CRM Growth (Odoo Brand)', description: 'CRM on the Odoo brand (adds 560 per licence), minimum 3 seats.',
    productName: 'Brightloop CRM', price: 1059, billingCycle: 'MONTHLY', minQuantity: 3,
    availableFrom: daysAgo(260), autoClose: false, canCloseEarly: true, canPause: true, canRenew: true,
  })
  const planDeskTeam = await makePlan({
    name: 'Desk Team', description: 'Brightloop Desk for support teams, billed monthly. Can be paused.',
    productName: 'Brightloop Desk', price: 299, billingCycle: 'MONTHLY', minQuantity: 5,
    availableFrom: daysAgo(300), autoClose: false, canCloseEarly: true, canPause: true, canRenew: false,
  })
  const planAnalyticsAnnual = await makePlan({
    name: 'Analytics Annual', description: 'Analytics Suite on a yearly contract. Closes automatically at period end, renewable.',
    productName: 'Analytics Suite', price: 5990, billingCycle: 'YEARLY', minQuantity: 1,
    availableFrom: daysAgo(60), autoClose: true, canCloseEarly: false, canPause: false, canRenew: true,
  })
  const planInventoryWeekly = await makePlan({
    name: 'Inventory Weekly', description: 'Short-cycle stock management for seasonal sellers. Auto-closes when it ends.',
    productName: 'Inventory Hub', price: 99, billingCycle: 'WEEKLY', minQuantity: 2,
    availableFrom: daysAgo(220), availableTo: daysAhead(45), autoClose: true, canCloseEarly: false, canPause: false, canRenew: false,
  })
  const planDailyPass = await makePlan({
    name: 'Desk Daily Pass', description: 'Pay-as-you-go day pass for Desk. Closes automatically, no early close.',
    productName: 'Brightloop Desk', price: 19, billingCycle: 'DAILY', minQuantity: 1,
    availableFrom: daysAgo(90), autoClose: true, canCloseEarly: false, canPause: false, canRenew: false,
  })

  const allPlans = [planCrmStarter, planCrmGrowth, planDeskTeam, planAnalyticsAnnual, planInventoryWeekly, planDailyPass]

  // ---------------- discount rules (admin-only objects) ----------------
  const discVolume = await db.discountRule.create({
    data: {
      name: 'VOLUME10', type: 'PERCENTAGE', value: 10, scope: 'SUBSCRIPTION',
      minQuantity: 10, startDate: daysAgo(150), endDate: daysAhead(180), maxUses: 60,
    },
  })
  const discAnnual = await db.discountRule.create({
    data: {
      name: 'ANNUAL5', type: 'PERCENTAGE', value: 5, scope: 'SUBSCRIPTION',
      minPurchase: 5000, startDate: daysAgo(90), endDate: daysAhead(180), maxUses: 40,
    },
  })
  const discAddon = await db.discountRule.create({
    data: {
      name: 'ADDON15', type: 'PERCENTAGE', value: 15, scope: 'PRODUCT',
      productId: products['Email Conversations Add-on'].id,
      startDate: daysAgo(75), endDate: daysAhead(90), maxUses: 300,
    },
  })
  const discWelcome = await db.discountRule.create({
    data: {
      name: 'WELCOME200', type: 'FIXED', value: 200, scope: 'SUBSCRIPTION',
      startDate: daysAgo(365), endDate: daysAhead(180), maxUses: 500,
    },
  })

  // ---------------- quotation templates ----------------
  async function makeTemplate(name: string, description: string, planId: string | null, validDays: number, lines: { product: string; variantId?: string; qty: number; price: number; taxRate: number }[]) {
    return db.quotationTemplate.create({
      data: {
        name, description, planId, validDays,
        lines: {
          create: lines.map((l, i) => ({
            productId: products[l.product].id,
            variantId: l.variantId ?? null,
            quantity: l.qty,
            unitPrice: l.price,
            taxRate: l.taxRate,
            sortOrder: i,
          })),
        },
      },
    })
  }

  await makeTemplate('Enterprise Suite', 'Full analytics rollout for larger teams, quoted on the annual plan.', planAnalyticsAnnual.id, 30, [
    { product: 'Analytics Suite', variantId: analyticsVariants[1].id, qty: 10, price: 599 + 300, taxRate: 18 },
    { product: 'Email Conversations Add-on', qty: 10, price: 49, taxRate: 18 },
    { product: 'Priority Support', qty: 1, price: 99, taxRate: 18 },
  ])
  await makeTemplate('SMB Starter', 'Standard starter bundle for small shops moving off spreadsheets.', planCrmStarter.id, 15, [
    { product: 'Brightloop CRM', variantId: crmVariants[0].id, qty: 3, price: 499, taxRate: 18 },
    { product: 'Email Conversations Add-on', qty: 3, price: 49, taxRate: 18 },
  ])
  await makeTemplate('Support Upsell', 'Desk team topped up with storage and priority support.', planDeskTeam.id, 7, [
    { product: 'Brightloop Desk', qty: 5, price: 299, taxRate: 18 },
    { product: 'Extra Storage Pack', qty: 2, price: 79, taxRate: 18 },
    { product: 'Priority Support', qty: 1, price: 99, taxRate: 18 },
  ])

  // ---------------- customers + portal users ----------------
  const customerSeed = [
    { name: 'Kaveri Textiles', email: 'accounts@kaveritextiles.in', city: 'Coimbatore', country: 'India', phone: '+91 98400 11223' },
    { name: 'Nimbus Retail', email: 'finance@nimbusretail.com', city: 'Mumbai', country: 'India', phone: '+91 98201 44556' },
    { name: 'GlowCart', email: 'billing@glowcart.shop', city: 'Bengaluru', country: 'India', phone: '+91 99860 77441' },
    { name: 'Orbit Logistics', email: 'ap@orbitlogistics.co', city: 'Singapore', country: 'Singapore', phone: '+65 8123 4455' },
    { name: 'Zenko Labs', email: 'pay@zenkolabs.io', city: 'Pune', country: 'India', phone: '+91 97650 32210' },
    { name: 'Blue Fern Boutique', email: 'hello@bluefern.nz', city: 'Auckland', country: 'New Zealand', phone: '+64 21 555 0192' },
    { name: 'Marigold Sweets', email: 'owner@marigoldsweets.in', city: 'Jaipur', country: 'India', phone: '+91 94140 88776' },
    { name: 'Crestline Realty', email: 'accounts@crestline.re', city: 'Hyderabad', country: 'India', phone: '+91 90000 22119' },
    { name: 'Pinewood Interiors', email: 'billing@pinewood.design', city: 'Chennai', country: 'India', phone: '+91 98410 66334' },
    { name: 'Quill & Press', email: 'subs@quillandpress.com', city: 'Kochi', country: 'India', phone: '+91 90480 11975' },
    { name: 'Terrace Farms', email: 'office@terracefarms.in', city: 'Nashik', country: 'India', phone: '+91 91450 77028' },
    { name: 'Halcyon Clinics', email: 'finance@halcyon.care', city: 'Delhi', country: 'India', phone: '+91 98110 30247' },
    { name: 'Verve Fitness', email: 'ap@vervefitness.in', city: 'Ahmedabad', country: 'India', phone: '+91 99250 51183' },
    { name: 'Lantern House Cafe', email: 'cafe@lanternhouse.in', city: 'Goa', country: 'India', phone: '+91 90190 44221' },
    { name: 'Sable Motors', email: 'accounts@sablemotors.co', city: 'Dubai', country: 'UAE', phone: '+971 50 220 8871' },
    { name: 'Aster Academy', email: 'bursar@asteracademy.edu', city: 'Lucknow', country: 'India', phone: '+91 93350 66017' },
    { name: 'Fjord Analytics', email: 'invoices@fjordanalytics.no', city: 'Bergen', country: 'Norway', phone: '+47 55 21 44 08' },
    { name: 'Copper Kettle Foods', email: 'ap@copperkettle.in', city: 'Indore', country: 'India', phone: '+91 93020 91544' },
    { name: 'Willow & Weave', email: 'hello@willowandweave.in', city: 'Surat', country: 'India', phone: '+91 98790 33412' },
    { name: 'Northwind Traders', email: 'finance@northwindtraders.com', city: 'Kolkata', country: 'India', phone: '+91 98300 77156' },
    { name: 'Lumen Dental', email: 'billing@lumendental.clinic', city: 'Navi Mumbai', country: 'India', phone: '+91 91670 40058' },
    { name: 'Harbour Books', email: 'shop@harbourbooks.in', city: 'Visakhapatnam', country: 'India', phone: '+91 89780 22466' },
  ]
  const customers: { id: string; name: string; email: string }[] = []
  const contactFirst = ['Priya', 'Rahul', 'Sana', 'Vikram', 'Anita', 'Joseph', 'Meera', 'Karan', 'Divya', 'Arjun', 'Leela', 'Farhan', 'Nisha', 'Rohit', 'Tara', 'Sanjay', 'Pooja', 'Aditya', 'Kavya', 'Naveen', 'Ritu', 'Sameer']
  const contactLast = ['Sharma', 'Patel', 'Khan', 'Reddy', 'Nair', 'Fernandes', 'Gupta', 'Mehta', 'Iyer', 'Bose', 'Rao', 'Sheikh']
  for (let i = 0; i < customerSeed.length; i++) {
    const c = customerSeed[i]
    const contact = `${contactFirst[i % contactFirst.length]} ${contactLast[(i * 3) % contactLast.length]}`
    const created = await db.customer.create({
      data: {
        name: c.name,
        email: c.email,
        phone: c.phone,
        company: c.name,
        address: `${ri(2, 98)} ${pick(['MG Road', 'Ring Road', 'Station Road', 'Marine Drive', 'Park Lane', 'Hill Street'])}`,
        city: c.city,
        country: c.country,
        taxId: c.country === 'India' ? `29ABCDE${1000 + i}F1Z${ri(1, 9)}` : null,
        notes: rng() < 0.2 ? 'Key account — handled directly by the finance lead.' : null,
      },
    })
    customers.push({ id: created.id, name: created.name, email: created.email })
    // portal login for the first 10 customers
    if (i < 10) {
      await db.user.create({
        data: {
          email: c.email,
          name: contact,
          role: 'CUSTOMER',
          passwordHash: hashPassword('Customer@123!'),
          customerId: created.id,
        },
      })
    }
  }

  // ---------------- subscriptions + billing history ----------------
  const usedCount: Record<string, number> = {}
  let invoiceCount = 0
  let paymentCount = 0
  let subCount = 0
  let cancelledUsed = false
  let currentDraftMade = 0

  async function nextNum(key: string, prefix: string): Promise<string> {
    const c = await db.counter.upsert({
      where: { key },
      update: { value: { increment: 1 } },
      create: { key, value: 1 },
    })
    return `${prefix}-${String(c.value).padStart(4, '0')}`
  }

  type LineSpec = { productId: string; variantId: string | null; description: string; quantity: number; unitPrice: number; taxRate: number }

  const planLine = (plan: typeof allPlans[number], qty: number, variantId: string | null, delta: number): LineSpec => ({
    productId: plan.productId!,
    variantId,
    description: delta > 0 ? `${plan.name} — ${qty} licence${qty > 1 ? 's' : ''}` : plan.name,
    quantity: qty,
    unitPrice: plan.price + delta,
    taxRate: 18,
  })

  const addonLine = (product: string, qty: number): LineSpec => ({
    productId: products[product].id,
    variantId: null,
    description: product,
    quantity: qty,
    unitPrice: products[product].salesPrice,
    taxRate: 18,
  })

  // One subscription "due for billing day" out of every ~5 active ones → the
  // billing-day scene has real work to do; the rest already have this cycle's invoice.
  let activeTally = 0

  async function createSubscription(opts: {
    customerId: string
    plan: typeof allPlans[number] | null
    start: Date
    status: 'DRAFT' | 'QUOTATION' | 'CONFIRMED' | 'ACTIVE' | 'PAUSED' | 'CLOSED'
    lines: LineSpec[]
    paymentTerms: PaymentTerms
    expiryDate?: Date | null
    leaveUnbilled?: boolean
    currentInvoiceStatus?: 'DRAFT' | 'CONFIRMED'
    closeInfo?: { closedAt: Date; reason: string }
    notes?: string | null
  }) {
    const number = await nextNum('SUB', 'SUB')
    subCount++
    const sub = await db.subscription.create({
      data: {
        number,
        customerId: opts.customerId,
        planId: opts.plan?.id ?? null,
        status: opts.status,
        startDate: opts.start,
        expiryDate: opts.expiryDate ?? null,
        paymentTerms: opts.paymentTerms,
        nextBillingDate: null,
        closedAt: opts.closeInfo?.closedAt ?? null,
        closeReason: opts.closeInfo?.reason ?? null,
        notes: opts.notes ?? null,
        lines: {
          create: opts.lines.map((l, i) => ({ ...l, sortOrder: i })),
        },
      },
      include: { lines: true, plan: true },
    })

    if (!['ACTIVE', 'PAUSED', 'CLOSED'].includes(sub.status)) {
      return sub
    }

    // ---- walk billing cycles from the start date ----
    const cycle = (sub.plan?.billingCycle ?? 'MONTHLY') as Cycle
    const terms = (sub.paymentTerms ?? 'DUE_ON_RECEIPT') as PaymentTerms
    let cursor = startOfDay(sub.startDate)
    let firstInvoice = true
    let openInvoiceCreated = false

    while (cursor.getTime() <= today.getTime()) {
      const cycleEnd = addCycle(cursor, cycle)
      const isCurrentCycle = cycleEnd.getTime() > today.getTime()
      if (opts.closeInfo && cursor.getTime() > opts.closeInfo.closedAt.getTime()) break
      if (opts.expiryDate && cursor.getTime() > opts.expiryDate.getTime()) break

      const leaveUnbilled = isCurrentCycle && opts.leaveUnbilled === true && !opts.closeInfo
      if (isCurrentCycle && !leaveUnbilled && opts.status === 'PAUSED') break
      if (isCurrentCycle && !leaveUnbilled && openInvoiceCreated) break

      if (!isCurrentCycle || !leaveUnbilled) {
        // discounts in force on the issue date
        const activeRules = [
          discVolume, discAnnual, discAddon,
          ...(firstInvoice ? [discWelcome] : []),
        ].map((r) => ({ ...r, usedCount: usedCount[r.id] ?? 0 }))
        const lineInputs = sub.lines.map((l) => ({
          productId: l.productId,
          description: l.description,
          quantity: l.quantity,
          unitPrice: l.unitPrice,
          taxRate: l.taxRate,
        }))
        const picked = pickApplicableDiscounts(activeRules, lineInputs, cursor)
        const computed = computeInvoice(lineInputs, picked)
        for (const id of computed.usedDiscountIds) usedCount[id] = (usedCount[id] ?? 0) + 1

        const dueDate = new Date(cursor)
        dueDate.setDate(dueDate.getDate() + PAYMENT_TERMS_DAYS[terms])

        let status: string
        let amountPaid = 0
        if (isCurrentCycle && dueDate.getTime() >= today.getTime() - 5 * 86400000) {
          // genuinely current paperwork — stays open for the team to work
          status = opts.currentInvoiceStatus ?? 'CONFIRMED'
          if (status === 'CONFIRMED' && currentDraftMade < 2) {
            status = 'DRAFT'
            currentDraftMade++
          }
        } else if (isCurrentCycle) {
          // an old open cycle (e.g. a yearly plan billed long ago) settles like history
          if (rng() < 0.12) {
            status = 'CONFIRMED'
          } else {
            status = 'PAID'
            amountPaid = computed.total
          }
        } else if (!cancelledUsed && rng() < 0.012 && !firstInvoice) {
          status = 'CANCELLED'
          cancelledUsed = true
        } else if (dueDate.getTime() < today.getTime() - 5 * 86400000) {
          status = 'PAID'
          amountPaid = computed.total
        } else if (rng() < 0.1) {
          status = 'PAID'
          amountPaid = computed.total
        } else {
          status = 'CONFIRMED'
        }

        const invNumber = await nextNum('INV', 'INV')
        invoiceCount++
        const invoice = await db.invoice.create({
          data: {
            number: invNumber,
            subscriptionId: sub.id,
            customerId: opts.customerId,
            status,
            issueDate: cursor,
            dueDate,
            subtotal: computed.subtotal,
            discountTotal: computed.discountTotal,
            discountNote: computed.discountNote || null,
            taxTotal: computed.taxTotal,
            total: computed.total,
            amountPaid,
            paidAt: null,
            sentAt: status === 'DRAFT' ? null : cursor,
            periodStart: cursor,
            periodEnd: new Date(cycleEnd.getTime() - 86400000),
            notes: `Generated from subscription ${sub.number}`,
            lines: {
              create: computed.lines.map((l, i) => ({
                productId: l.productId ?? null,
                description: l.description,
                quantity: l.quantity,
                unitPrice: l.unitPrice,
                discount: l.discount,
                taxRate: l.taxRate,
                taxAmount: l.taxAmount,
                netAmount: l.netAmount,
                total: l.total,
                sortOrder: i,
              })),
            },
          },
        })

        // payments
        if (status === 'PAID') {
          const payDate = new Date(cursor)
          payDate.setDate(payDate.getDate() + ri(1, 4))
          if (payDate.getTime() > today.getTime()) payDate.setTime(today.getTime())
          const methods = ['CARD', 'BANK_TRANSFER', 'UPI', 'CHEQUE', 'BANK_TRANSFER', 'UPI']
          const payment = await db.payment.create({
            data: {
              number: await nextNum('PAY', 'PAY'),
              invoiceId: invoice.id,
              customerId: opts.customerId,
              method: pick(methods),
              amount: computed.total,
              date: payDate,
              note: rng() < 0.3 ? 'Settled via bank portal' : null,
            },
          })
          paymentCount++
          await db.invoice.update({ where: { id: invoice.id }, data: { paidAt: payment.date } })
        }
        if (!isCurrentCycle) firstInvoice = false
        if (isCurrentCycle) openInvoiceCreated = true
      }

      if (leaveUnbilled) {
        await db.subscription.update({ where: { id: sub.id }, data: { nextBillingDate: cursor } })
        return sub
      }
      cursor = addCycle(cursor, cycle)
    }

    await db.subscription.update({
      where: { id: sub.id },
      data: { nextBillingDate: opts.closeInfo ? null : cursor },
    })
    return sub
  }

  // ---- populate subscriptions customer by customer ----
  let currencySeedIdx = 0
  let freshCount = 0
  for (const c of customers) {
    const nSubs = 1 + (rng() < 0.4 ? 1 : 0) + (rng() < 0.15 ? 1 : 0)
    const chosen = new Set<string>()
    for (let s = 0; s < nSubs; s++) {
      const plan = pick(allPlans)
      if (chosen.has(plan.id)) continue
      chosen.add(plan.id)
      currencySeedIdx++

      const fresh = rng() < 0.28
      const start = fresh ? daysAgo(ri(1, 16)) : daysAgo(ri(25, 280))
      const isOdoo = plan.id === planCrmGrowth.id || rng() < 0.25
      const variant = plan.productId === products['Brightloop CRM'].id && isOdoo ? crmVariants[1] : plan.productId === products['Brightloop CRM'].id ? crmVariants[0] : plan.productId === products['Analytics Suite'].id ? pick(analyticsVariants) : null
      const delta = variant?.priceDelta ?? 0
      const qty = Math.max(plan.minQuantity, ri(plan.minQuantity, plan.minQuantity + 9))

      const lines: LineSpec[] = [planLine(plan, qty, variant?.id ?? null, delta)]
      if (rng() < 0.45) lines.push(addonLine('Email Conversations Add-on', Math.max(1, Math.round(qty / 2))))
      if (rng() < 0.2) lines.push(addonLine('Extra Storage Pack', ri(1, 3)))
      if (rng() < 0.18) lines.push(addonLine('Priority Support', 1))

      const terms = pick(['DUE_ON_RECEIPT', 'NET_15', 'NET_15', 'NET_30'] as PaymentTerms[])

      let status: 'DRAFT' | 'QUOTATION' | 'CONFIRMED' | 'ACTIVE' | 'PAUSED' | 'CLOSED' = 'ACTIVE'
      let closeInfo: { closedAt: Date; reason: string } | undefined
      let expiry: Date | null = null

      if (fresh && rng() < 0.75) {
        // guarantee one DRAFT and one QUOTATION for demoing the quote flow
        freshCount++
        const r = freshCount === 1 ? 0.1 : freshCount === 2 ? 0.5 : freshCount === 3 ? 0.8 : rng()
        status = r < 0.35 ? 'DRAFT' : r < 0.7 ? 'QUOTATION' : 'CONFIRMED'
      } else if (rng() < 0.14) {
        status = 'CLOSED'
        const closedAt = daysAgo(ri(4, 45))
        closeInfo = {
          closedAt,
          reason: plan.canCloseEarly && rng() < 0.6 ? 'Closed early at customer request' : 'Plan period ended',
        }
        if (plan.billingCycle === 'YEARLY') expiry = new Date(start.getFullYear() + 1, start.getMonth(), start.getDate())
      } else if (plan.canPause && rng() < 0.1) {
        status = 'PAUSED'
      } else if (plan.billingCycle === 'YEARLY') {
        expiry = new Date(start.getFullYear() + 1, start.getMonth(), start.getDate())
      } else if (plan.billingCycle === 'WEEKLY' && plan.autoClose) {
        expiry = new Date(start.getTime() + ri(3, 10) * 7 * 86400000)
        if (expiry.getTime() < today.getTime()) {
          status = 'CLOSED'
          closeInfo = { closedAt: expiry, reason: 'Plan period ended' }
        }
      }

      // roughly one in four active subscriptions is still waiting for billing day
      const isBillingStatus = status === 'ACTIVE'
      if (isBillingStatus) activeTally++
      const leaveUnbilled = isBillingStatus && activeTally % 4 === 1
      const currentInvoiceStatus: 'DRAFT' | 'CONFIRMED' = currencySeedIdx % 7 === 0 ? 'DRAFT' : 'CONFIRMED'

      await createSubscription({
        customerId: c.id,
        plan,
        start,
        status,
        lines,
        paymentTerms: terms,
        expiryDate: expiry,
        leaveUnbilled,
        currentInvoiceStatus,
        closeInfo,
        notes: rng() < 0.15 ? 'Signed up via website; onboarding call completed.' : null,
      })
    }
  }

  // persist discount usage counters
  for (const [id, count] of Object.entries(usedCount)) {
    await db.discountRule.update({ where: { id }, data: { usedCount: count } })
  }

  // mark stale CONFIRMED invoices whose due date passed — they simply show as overdue
  const summary: SeedSummary = {
    users: await db.user.count(),
    customers: customers.length,
    products: productSeed.length,
    plans: allPlans.length,
    taxRules: taxRules.length,
    discounts: 4,
    templates: await db.quotationTemplate.count(),
    subscriptions: subCount,
    invoices: invoiceCount,
    payments: paymentCount,
  }
  return summary
}
