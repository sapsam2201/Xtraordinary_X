'use client'

import { statusClass, statusLabel } from './format'
import { cn } from '@/lib/utils'
import type { LucideIcon } from 'lucide-react'

export function Logo({ size = 36, dark = false }: { size?: number; dark?: boolean }) {
  return (
    <div className="flex items-center gap-2.5 select-none">
      <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
        <rect width="48" height="48" rx="13" className={dark ? 'fill-emerald-400/90' : 'fill-emerald-500'} />
        <path
          d="M14 30.5c0-8 6-8 10-8s10 0 10-8M14 15h17M14 33h17"
          stroke="white" strokeWidth="3.4" strokeLinecap="round"
        />
        <circle cx="33" cy="14.5" r="3" fill="white" />
        <circle cx="14" cy="33" r="3" fill="white" />
      </svg>
      <div className="leading-tight">
        <div className={cn('font-bold tracking-tight text-[15px]', dark ? 'text-white' : 'text-foreground')}>
          Brightloop
        </div>
        <div className={cn('text-[10.5px] font-medium uppercase tracking-widest', dark ? 'text-emerald-200/70' : 'text-muted-foreground')}>
          Subscriptions
        </div>
      </div>
    </div>
  )
}

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-semibold tracking-wide',
        statusClass(status),
        className
      )}
    >
      {statusLabel(status)}
    </span>
  )
}

export function StatCard({
  label, value, sub, icon: Icon, tone = 'default',
}: {
  label: string
  value: string
  sub?: React.ReactNode
  icon: LucideIcon
  tone?: 'default' | 'emerald' | 'amber' | 'rose' | 'teal'
}) {
  const tones: Record<string, string> = {
    default: 'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300',
    emerald: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
    amber: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
    rose: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300',
    teal: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300',
  }
  const bars: Record<string, string> = {
    default: 'from-zinc-300 to-zinc-200',
    emerald: 'from-emerald-400 to-teal-300',
    amber: 'from-amber-400 to-orange-300',
    rose: 'from-rose-400 to-pink-300',
    teal: 'from-teal-400 to-cyan-300',
  }
  return (
    <div className="group relative overflow-hidden rounded-2xl border bg-card p-5 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-emerald-900/5">
      <div className={cn('absolute inset-x-0 top-0 h-1 bg-gradient-to-r opacity-70', bars[tone])} aria-hidden="true" />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[13px] font-medium text-muted-foreground">{label}</p>
          <p className="mt-1.5 text-[26px] font-bold leading-none tracking-tight text-foreground">{value}</p>
          {sub ? <div className="mt-2 text-xs text-muted-foreground">{sub}</div> : null}
        </div>
        <div className={cn('rounded-xl p-2.5 shrink-0 shadow-sm transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3', tones[tone])}>
          <Icon className="h-5 w-5" aria-hidden="true" />
        </div>
      </div>
    </div>
  )
}

export function EmptyState({ title, hint, icon: Icon }: { title: string; hint?: string; icon?: LucideIcon }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed bg-gradient-to-b from-muted/30 to-transparent py-14 text-center">
      {Icon ? (
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
          <Icon className="h-7 w-7" aria-hidden="true" />
        </div>
      ) : null}
      <div>
        <p className="font-semibold text-foreground">{title}</p>
        {hint ? <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">{hint}</p> : null}
      </div>
    </div>
  )
}

export function PageHeader({
  title, subtitle, actions,
}: {
  title: string
  subtitle?: string
  actions?: React.ReactNode
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        {subtitle ? <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  )
}

export function Spinner({ className }: { className?: string }) {
  return (
    <div className={cn('flex items-center justify-center py-16', className)} role="status" aria-label="Loading">
      <div className="h-7 w-7 animate-spin rounded-full border-[3px] border-primary/25 border-t-primary" />
    </div>
  )
}

export function ErrorNote({ message }: { message: string }) {
  return (
    <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
      {message}
    </div>
  )
}
