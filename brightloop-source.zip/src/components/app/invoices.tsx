'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { api } from './api-client'
import { fmtDate, fmtMoney, METHOD_LABEL, statusLabel, toDateInput } from './format'
import { EmptyState, ErrorNote, PageHeader, Spinner, StatusBadge } from './ui-bits'
import type { BillingPreview, Invoice, Payment } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { toast } from '@/hooks/use-toast'
import {
  Ban, CheckCircle2, CreditCard, Download, FileText, Loader2, Mail, PlayCircle,
  Printer, Search, Wallet, Zap,
} from 'lucide-react'

const STATUS_TABS = ['ALL', 'DRAFT', 'CONFIRMED', 'PAID', 'CANCELLED']

export function Invoices({
  openInvoiceId,
  onOpenInvoice,
  clearOpenInvoice,
  onChanged,
  authRole,
}: {
  openInvoiceId?: string | null
  onOpenInvoice?: (id: string | null) => void
  clearOpenInvoice?: () => void
  onChanged?: () => void
  authRole: string
}) {
  const [invoices, setInvoices] = useState<Invoice[] | null>(null)
  const [status, setStatus] = useState('ALL')
  const [q, setQ] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [error, setError] = useState('')
  const [detail, setDetail] = useState<Invoice | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [payOpen, setPayOpen] = useState(false)
  const [billingOpen, setBillingOpen] = useState(false)
  const [busyAction, setBusyAction] = useState('')

  const load = useCallback(async () => {
    setError('')
    try {
      const params = new URLSearchParams()
      if (from) params.set('from', from)
      if (to) params.set('to', to)
      const res = await api.get<{ invoices: Invoice[] }>(`/api/invoices?${params}`)
      setInvoices(res.invoices)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load invoices')
    }
  }, [from, to])

  useEffect(() => { load() }, [load])

  // open an invoice requested from another view (dashboard / billing run)
  useEffect(() => {
    if (openInvoiceId) {
      openDetail(openInvoiceId)
      clearOpenInvoice?.()
    }
  }, [openInvoiceId])

  async function openDetail(id: string) {
    setDetailLoading(true)
    try {
      const res = await api.get<{ invoice: Invoice }>(`/api/invoices/${id}`)
      setDetail(res.invoice)
    } catch (err) {
      toast({ title: 'Could not open invoice', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setDetailLoading(false)
    }
  }

  async function act(id: string, action: 'confirm' | 'send' | 'cancel') {
    setBusyAction(`${id}:${action}`)
    try {
      const res = await api.post<{ invoice: Invoice }>(`/api/invoices/${id}/action`, { action })
      setDetail(res.invoice)
      toast({
        title:
          action === 'confirm' ? 'Invoice confirmed'
          : action === 'send' ? 'Invoice sent'
          : 'Invoice cancelled',
        description: action === 'send' ? 'Email delivery is simulated in this demo.' : undefined,
      })
      await load()
      onChanged?.()
    } catch (err) {
      toast({ title: 'Action failed', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusyAction('')
    }
  }

  const filtered = useMemo(() => {
    if (!invoices) return []
    const today = new Date().toISOString().slice(0, 10)
    return invoices.filter((i) => {
      if (status !== 'ALL') {
        if (status === 'CONFIRMED' && i.status === 'CONFIRMED' && i.dueDate.slice(0, 10) < today) {
          // still listed under Confirmed; overdue badge highlights it
        } else if (i.status !== status) return false
      }
      if (q && !`${i.number} ${i.customer?.name ?? ''}`.toLowerCase().includes(q.toLowerCase())) return false
      return true
    })
  }, [invoices, status, q])

  const totals = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10)
    const sum = (list: Invoice[], f: (i: Invoice) => number) => list.reduce((s, i) => s + f(i), 0)
    const open = (invoices ?? []).filter((i) => i.status === 'CONFIRMED')
    const overdue = open.filter((i) => i.dueDate.slice(0, 10) < today)
    return {
      openCount: open.length,
      openAmount: sum(open, (i) => i.total - i.amountPaid),
      overdueCount: overdue.length,
      overdueAmount: sum(overdue, (i) => i.total - i.amountPaid),
    }
  }, [invoices])

  if (!invoices && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Invoices & billing"
        subtitle="Every invoice created from its subscription — confirm, send, print, chase, get paid."
        actions={
          authRole !== 'CUSTOMER' ? (
            <Button variant="secondary" onClick={() => setBillingOpen(true)}>
              <Zap className="mr-1.5 h-4 w-4" /> Billing day
            </Button>
          ) : undefined
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <SummaryChip label="Open invoices" value={String(totals.openCount)} tone="amber" />
        <SummaryChip label="Outstanding" value={fmtMoney(totals.openAmount, true)} tone="amber" />
        <SummaryChip label="Overdue" value={String(totals.overdueCount)} tone="rose" />
        <SummaryChip label="Overdue amount" value={fmtMoney(totals.overdueAmount, true)} tone="rose" />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap gap-1.5">
          {STATUS_TABS.map((s) => (
            <button key={s} onClick={() => setStatus(s)}
              className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                status === s ? 'border-primary bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:border-primary/40'
              }`}>
              {s === 'ALL' ? 'All' : statusLabel(s)}
            </button>
          ))}
        </div>
        <div className="relative ml-auto w-full sm:w-56">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search invoice or customer…" className="pl-8" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="flex items-center gap-1.5">
          <Input type="date" className="w-36" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" />
          <span className="text-xs text-muted-foreground">to</span>
          <Input type="date" className="w-36" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" />
        </div>
      </div>

      {error ? <ErrorNote message={error} /> : null}

      {filtered.length === 0 ? (
        <EmptyState icon={FileText} title="No invoices match" hint="Adjust the filters, or run billing day to create invoices from due subscriptions." />
      ) : (
        <div className="overflow-hidden rounded-xl border bg-card shadow-sm">
          <div className="overflow-x-auto scroll-slim">
            <table className="w-full min-w-[820px] text-sm">
              <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Invoice</th>
                  <th className="px-4 py-3 font-medium">Customer</th>
                  <th className="px-4 py-3 font-medium">Issued</th>
                  <th className="px-4 py-3 font-medium">Due</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium text-right">Total</th>
                  <th className="px-4 py-3 font-medium text-right">Balance</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 300).map((i) => {
                  const overdue = i.status === 'CONFIRMED' && i.dueDate.slice(0, 10) < new Date().toISOString().slice(0, 10)
                  return (
                    <tr key={i.id} className="cursor-pointer border-t transition-colors hover:bg-muted/40" onClick={() => openDetail(i.id)}>
                      <td className="px-4 py-3 font-semibold">{i.number}</td>
                      <td className="px-4 py-3">{i.customer?.name}</td>
                      <td className="px-4 py-3 text-xs">{fmtDate(i.issueDate)}</td>
                      <td className="px-4 py-3 text-xs">{fmtDate(i.dueDate)}</td>
                      <td className="px-4 py-3"><StatusBadge status={overdue ? 'OVERDUE' : i.status} /></td>
                      <td className="px-4 py-3 text-right font-medium">{fmtMoney(i.total)}</td>
                      <td className={`px-4 py-3 text-right font-medium ${i.total - i.amountPaid > 0.005 && i.status !== 'CANCELLED' ? 'text-rose-600' : 'text-muted-foreground'}`}>
                        {i.status === 'CANCELLED' ? '—' : fmtMoney(i.total - i.amountPaid)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); openDetail(i.id) }}>View</Button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          {filtered.length > 300 ? (
            <p className="border-t px-4 py-2 text-center text-xs text-muted-foreground">Showing the newest 300 of {filtered.length} invoices — refine your filters.</p>
          ) : null}
        </div>
      )}

      {/* Billing day dialog */}
      <BillingRunDialog open={billingOpen} onClose={() => setBillingOpen(false)} onRan={load} />

      {/* Detail dialog */}
      <Dialog open={!!detail || detailLoading} onOpenChange={(open) => { if (!open) setDetail(null) }}>
        <DialogContent
          className="max-h-[94vh] max-w-3xl overflow-y-auto scroll-slim print-doc-container"
          onInteractOutside={(e) => { if (detailLoading) e.preventDefault() }}
          onFocusOutside={(e) => e.preventDefault()}
        >
          {detail ? (
            <>
              <DialogHeader className="print-hide">
                <DialogTitle className="flex flex-wrap items-center gap-3">
                  <span>{detail.number}</span>
                  <StatusBadge status={detail.status} />
                </DialogTitle>
                <DialogDescription>
                  {detail.subscription ? `From subscription ${detail.subscription.number}` : 'Ad-hoc invoice'} · issued {fmtDate(detail.issueDate)} · due {fmtDate(detail.dueDate)}
                </DialogDescription>
              </DialogHeader>

              <PrintableInvoice invoice={detail} />

              <div className="print-hide space-y-3">
                <Separator />
                {detail.payments && detail.payments.length > 0 ? (
                  <div>
                    <p className="mb-2 text-[13px] font-semibold">Payments</p>
                    <div className="space-y-1">
                      {detail.payments.map((p) => (
                        <div key={p.id} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm">
                          <Wallet className="h-4 w-4 text-emerald-600" />
                          <span className="font-medium">{p.number}</span>
                          <span className="text-xs text-muted-foreground">{fmtDate(p.date)} · {METHOD_LABEL[p.method] ?? p.method}</span>
                          {p.note ? <span className="hidden text-xs text-muted-foreground sm:inline">· {p.note}</span> : null}
                          <span className="ml-auto font-semibold text-emerald-700">{fmtMoney(p.amount)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : null}

                <div className="flex flex-wrap gap-2">
                  {detail.status === 'DRAFT' ? (
                    <Button onClick={() => act(detail.id, 'confirm')} disabled={busyAction !== ''}>
                      {busyAction === `${detail.id}:confirm` ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <CheckCircle2 className="mr-1.5 h-4 w-4" />}
                      Confirm
                    </Button>
                  ) : null}
                  {detail.status !== 'DRAFT' && detail.status !== 'CANCELLED' ? (
                    <Button variant="outline" onClick={() => act(detail.id, 'send')} disabled={busyAction !== ''}>
                      <Mail className="mr-1.5 h-4 w-4" /> Send to customer
                    </Button>
                  ) : null}
                  {authRole !== 'CUSTOMER' && ['CONFIRMED', 'PAID'].includes(detail.status) && detail.total - detail.amountPaid > 0.005 ? (
                    <Button onClick={() => setPayOpen(true)}>
                      <CreditCard className="mr-1.5 h-4 w-4" /> Record payment
                    </Button>
                  ) : null}
                  {authRole === 'CUSTOMER' && detail.status === 'CONFIRMED' ? (
                    <Button onClick={() => setPayOpen(true)}>
                      <CreditCard className="mr-1.5 h-4 w-4" /> Pay now
                    </Button>
                  ) : null}
                  <Button variant="outline" onClick={() => printInvoice()}>
                    <Printer className="mr-1.5 h-4 w-4" /> Print / PDF
                  </Button>
                  {['DRAFT', 'CONFIRMED'].includes(detail.status) && detail.amountPaid === 0 ? (
                    <Button variant="destructive" onClick={() => act(detail.id, 'cancel')} disabled={busyAction !== ''}>
                      <Ban className="mr-1.5 h-4 w-4" /> Cancel
                    </Button>
                  ) : null}
                </div>
              </div>

              {payOpen ? (
                <PayDialog
                  invoice={detail}
                  role={authRole}
                  onClose={() => setPayOpen(false)}
                  onPaid={async () => {
                    setPayOpen(false)
                    await openDetail(detail.id)
                    await load()
                    onChanged?.()
                  }}
                />
              ) : null}
            </>
          ) : (
            <>
              <DialogTitle className="sr-only">Invoice details</DialogTitle>
              <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

export function printInvoice() {
  document.body.classList.add('printing')
  window.print()
  window.setTimeout(() => document.body.classList.remove('printing'), 400)
}

function SummaryChip({ label, value, tone }: { label: string; value: string; tone: 'amber' | 'rose' }) {
  const tones = {
    amber: 'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-200',
    rose: 'border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-200',
  }
  return (
    <div className={`rounded-xl border px-4 py-3 ${tones[tone]}`}>
      <p className="text-xs font-medium uppercase tracking-wide opacity-70">{label}</p>
      <p className="mt-0.5 text-lg font-bold">{value}</p>
    </div>
  )
}

/** Print-ready invoice document (also used on screen). */
export function PrintableInvoice({ invoice }: { invoice: Invoice }) {
  const balance = invoice.total - invoice.amountPaid
  return (
    <div className="print-doc rounded-xl border bg-white p-6 text-slate-900">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xl font-black tracking-tight text-emerald-700">Brightloop Software</p>
          <p className="text-xs text-slate-500">Subscriptions, software &amp; support</p>
          <p className="mt-1 text-xs text-slate-500">hello@brightloop.com · GSTIN 29ABCDE1234F1Z5</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-black tracking-tight">INVOICE</p>
          <p className="text-sm font-semibold">{invoice.number}</p>
          <p className="mt-1 text-xs text-slate-500">
            Issued {fmtDate(invoice.issueDate)} · Due {fmtDate(invoice.dueDate)}
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-4 text-sm sm:grid-cols-2">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">Billed to</p>
          <p className="mt-1 font-bold">{invoice.customer?.name}</p>
          {invoice.customer?.company ? <p className="text-slate-600">{invoice.customer.company}</p> : null}
          <p className="text-slate-600">{invoice.customer?.email}</p>
          {invoice.customer?.address ? <p className="text-slate-600">{invoice.customer.address}</p> : null}
          <p className="text-slate-600">{[invoice.customer?.city, invoice.customer?.country].filter(Boolean).join(', ')}</p>
          {invoice.customer?.taxId ? <p className="text-slate-500">GSTIN: {invoice.customer.taxId}</p> : null}
        </div>
        <div className="sm:text-right">
          <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">Billing period</p>
          <p className="mt-1 text-slate-700">
            {invoice.periodStart ? fmtDate(invoice.periodStart) : '—'} → {invoice.periodEnd ? fmtDate(invoice.periodEnd) : '—'}
          </p>
          <p className="mt-2 text-[11px] font-bold uppercase tracking-wide text-slate-400">Status</p>
          <p className="font-bold">{statusLabel(invoice.status)}</p>
        </div>
      </div>

      <table className="mt-6 w-full text-sm">
        <thead>
          <tr className="border-b-2 border-slate-900 text-left text-[11px] uppercase tracking-wide text-slate-500">
            <th className="py-2 font-bold">Description</th>
            <th className="py-2 text-right font-bold">Qty</th>
            <th className="py-2 text-right font-bold">Unit</th>
            <th className="py-2 text-right font-bold">Discount</th>
            <th className="py-2 text-right font-bold">Tax</th>
            <th className="py-2 text-right font-bold">Amount</th>
          </tr>
        </thead>
        <tbody>
          {(invoice.lines ?? []).map((l) => (
            <tr key={l.id} className="border-b border-slate-100">
              <td className="py-2 font-medium">{l.description}</td>
              <td className="py-2 text-right">{l.quantity}</td>
              <td className="py-2 text-right">{fmtMoney(l.unitPrice)}</td>
              <td className="py-2 text-right text-rose-600">{l.discount > 0 ? `−${fmtMoney(l.discount)}` : '—'}</td>
              <td className="py-2 text-right text-slate-500">{l.taxRate}%</td>
              <td className="py-2 text-right font-semibold">{fmtMoney(l.total)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-4 flex justify-end">
        <div className="w-full max-w-xs space-y-1.5 text-sm">
          <Row label="Subtotal" value={fmtMoney(invoice.subtotal)} />
          {invoice.discountTotal > 0 ? (
            <Row label={`Discounts${invoice.discountNote ? ` (${invoice.discountNote})` : ''}`} value={`−${fmtMoney(invoice.discountTotal)}`} tone="rose" />
          ) : null}
          <Row label="Tax" value={fmtMoney(invoice.taxTotal)} />
          <Separator className="bg-slate-200" />
          <Row label="Total" value={fmtMoney(invoice.total)} bold />
          {invoice.amountPaid > 0 ? <Row label="Paid" value={`−${fmtMoney(invoice.amountPaid)}`} tone="emerald" /> : null}
          {invoice.status !== 'CANCELLED' && invoice.amountPaid > 0 ? (
            <Row label="Balance due" value={fmtMoney(balance)} bold tone={balance > 0.005 ? 'rose' : 'emerald'} />
          ) : null}
        </div>
      </div>

      <p className="mt-6 border-t border-dashed pt-3 text-[11px] text-slate-400">
        {invoice.notes ?? ''} {invoice.notes ? '· ' : ''}Payments are due per the agreed terms. Generated by Brightloop Subscription Management.
      </p>
    </div>
  )
}

function Row({ label, value, bold, tone }: { label: string; value: string; bold?: boolean; tone?: 'rose' | 'emerald' }) {
  return (
    <div className={`flex items-center justify-between ${bold ? 'text-[15px] font-black' : ''}`}>
      <span className="text-slate-500">{label}</span>
      <span className={tone === 'rose' ? 'text-rose-600' : tone === 'emerald' ? 'text-emerald-600' : ''}>{value}</span>
    </div>
  )
}

/** Record a payment against an invoice. */
export function PayDialog({
  invoice, role, onClose, onPaid,
}: {
  invoice: Invoice
  role: string
  onClose: () => void
  onPaid: () => void
}) {
  const balance = Math.max(0, Math.round((invoice.total - invoice.amountPaid) * 100) / 100)
  const [method, setMethod] = useState('BANK_TRANSFER')
  const [amount, setAmount] = useState(String(balance))
  const [date, setDate] = useState(toDateInput(new Date()))
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit() {
    setBusy(true)
    try {
      await api.post<{ invoiceStatus: string }>('/api/payments', {
        invoiceId: invoice.id, method, amount: Number(amount), date, note,
      })
      toast({ title: 'Payment recorded', description: role === 'CUSTOMER' ? 'Thank you — your payment is recorded.' : 'The invoice was updated.' })
      onPaid()
    } catch (err) {
      toast({ title: 'Payment failed', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="rounded-lg border bg-muted/30 p-4 print-hide">
      <p className="mb-3 flex items-center gap-2 text-sm font-bold"><Download className="h-4 w-4" /> Record a payment against {invoice.number}</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>Method</Label>
          <Select value={method} onValueChange={setMethod}>
            <SelectTrigger aria-label="Payment method"><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(METHOD_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Amount (balance {fmtMoney(balance)})</Label>
          <Input type="number" min={0.01} step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Date</Label>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Note (optional)</Label>
          <Input placeholder="e.g. UTR reference" value={note} onChange={(e) => setNote(e.target.value)} />
        </div>
      </div>
      <div className="mt-3 flex gap-2">
        <Button onClick={submit} disabled={busy || !Number(amount)}>
          {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <PlayCircle className="mr-1.5 h-4 w-4" />}
          Record {fmtMoney(Number(amount) || 0)}
        </Button>
        <Button variant="ghost" onClick={onClose}>Not now</Button>
      </div>
    </div>
  )
}

/** Billing day: preview due subscriptions, then run. */
function BillingRunDialog({ open, onClose, onRan }: { open: boolean; onClose: () => void; onRan: () => void }) {
  const [preview, setPreview] = useState<BillingPreview | null>(null)
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState<{ invoicesCreated: number; subscriptionsClosed: number; created: { number: string; invoice: string; total: number }[] } | null>(null)

  useEffect(() => {
    if (open) {
      setResult(null)
      api.get<BillingPreview>('/api/billing').then(setPreview).catch(() => setPreview(null))
    }
  }, [open])

  async function run() {
    setBusy(true)
    try {
      const res = await api.post<{ invoicesCreated: number; subscriptionsClosed: number; created: { number: string; invoice: string; total: number }[] }>('/api/billing')
      setResult(res)
      toast({ title: 'Billing day complete', description: `${res.invoicesCreated} invoice(s) created.` })
      onRan()
    } catch (err) {
      toast({ title: 'Billing run failed', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose() }}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto scroll-slim">
        <DialogHeader>
          <DialogTitle>Billing day</DialogTitle>
          <DialogDescription>
            Every due subscription gets an invoice with customer details, lines, taxes and totals already filled in. Nothing is billed twice — subscriptions with an open invoice are skipped.
          </DialogDescription>
        </DialogHeader>

        {result ? (
          <div className="space-y-3">
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm dark:border-emerald-900 dark:bg-emerald-950/40">
              <p className="font-bold text-emerald-800 dark:text-emerald-300">{result.invoicesCreated} invoices created · {result.subscriptionsClosed} subscriptions closed</p>
              <p className="mt-1 text-emerald-700/80 dark:text-emerald-200/80">Drafts are ready to confirm. Discounts were applied where rules allow.</p>
            </div>
            <div className="space-y-1">
              {result.created.map((c) => (
                <div key={c.invoice} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">{c.invoice}</span>
                  <span className="text-muted-foreground">from {c.number}</span>
                  <span className="ml-auto font-semibold">{fmtMoney(c.total)}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <>
            <div className="rounded-lg border p-3 text-sm">
              {preview ? (
                preview.dueCount > 0 ? (
                  <p><b className="text-emerald-600">{preview.dueCount}</b> subscription{preview.dueCount === 1 ? '' : 's'} due
                    {preview.autoCloseCount > 0 ? <> · <b>{preview.autoCloseCount}</b> finished plan{preview.autoCloseCount === 1 ? '' : 's'} will auto-close</> : null}
                  </p>
                ) : (
                  <p className="text-muted-foreground">No subscriptions are due right now — everyone has been billed.</p>
                )
              ) : 'Checking what is due…'}
            </div>
            {preview && preview.due.length > 0 ? (
              <div className="max-h-64 space-y-1 overflow-y-auto scroll-slim">
                {preview.due.map((d) => (
                  <div key={d.id} className="flex flex-wrap items-center gap-2 rounded-lg border px-3 py-2 text-sm">
                    <span className="font-medium">{d.number}</span>
                    <span className="text-muted-foreground">{d.customer} · {d.plan}</span>
                    {d.overdueDays > 0 ? (
                      <span className="rounded-full bg-rose-100 px-2 py-0.5 text-[11px] font-semibold text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                        {d.overdueDays}d overdue
                      </span>
                    ) : null}
                    <span className="ml-auto font-semibold">{fmtMoney(d.estimatedAmount)}</span>
                    <span className="text-[11px] text-muted-foreground">/ {d.billingCycle.toLowerCase()}</span>
                  </div>
                ))}
              </div>
            ) : null}
          </>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>{result ? 'Done' : 'Cancel'}</Button>
          {!result ? (
            <Button onClick={run} disabled={busy || !preview || preview.dueCount === 0}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Zap className="mr-1.5 h-4 w-4" />}
              Create {preview?.dueCount ?? 0} invoice{preview?.dueCount === 1 ? '' : 's'}
            </Button>
          ) : null}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
