'use client'

import { useState } from 'react'
import { Logo } from './ui-bits'
import type { SessionUser } from './types'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTitle } from '@/components/ui/sheet'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Activity, BadgePercent, BarChart3, CalendarClock, CreditCard, FileStack, FileText, LayoutDashboard,
  Layers, LogOut, Moon, Package, Receipt, RefreshCw, Settings, Sun, UserCog, Users,
} from 'lucide-react'

export type ViewKey =
  | 'dashboard' | 'subscriptions' | 'invoices' | 'payments' | 'billingruns'
  | 'customers' | 'products' | 'plans' | 'templates' | 'discounts' | 'taxes'
  | 'reports' | 'activity' | 'staff' | 'settings'

const NAV: { key: ViewKey; label: string; icon: typeof LayoutDashboard; adminOnly?: boolean; group: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, group: 'Overview' },
  { key: 'subscriptions', label: 'Subscriptions', icon: RefreshCw, group: 'Overview' },
  { key: 'invoices', label: 'Invoices & Billing', icon: FileText, group: 'Overview' },
  { key: 'payments', label: 'Payments', icon: CreditCard, group: 'Overview' },
  { key: 'billingruns', label: 'Billing runs', icon: CalendarClock, group: 'Operations' },
  { key: 'customers', label: 'Customers', icon: Users, group: 'Manage' },
  { key: 'products', label: 'Products', icon: Package, group: 'Catalog' },
  { key: 'plans', label: 'Plans', icon: Layers, group: 'Catalog' },
  { key: 'templates', label: 'Quotation templates', icon: FileStack, group: 'Catalog' },
  { key: 'discounts', label: 'Discounts', icon: BadgePercent, group: 'Finance setup' },
  { key: 'taxes', label: 'Tax rules', icon: Receipt, group: 'Finance setup' },
  { key: 'reports', label: 'Reports & analytics', icon: BarChart3, group: 'Insights' },
  { key: 'activity', label: 'Activity feed', icon: Activity, group: 'Insights' },
  { key: 'staff', label: 'Staff & roles', icon: UserCog, group: 'Admin', adminOnly: true },
  { key: 'settings', label: 'Settings', icon: Settings, group: 'Admin' },
]

export function Shell({
  user, view, onView, onLogout, children,
}: {
  user: SessionUser
  view: ViewKey
  onView: (v: ViewKey) => void
  onLogout: () => void
  children: React.ReactNode
}) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [dark, setDark] = useState(false)
  const items = NAV.filter((n) => !n.adminOnly || user.role === 'ADMIN')
  const groups = [...new Set(items.map((i) => i.group))]
  const current = NAV.find((n) => n.key === view)

  function toggleTheme() {
    const next = !dark
    setDark(next)
    document.documentElement.classList.toggle('dark', next)
  }

  const navList = (
    <nav className="flex-1 space-y-5 overflow-y-auto px-3 py-4 scroll-slim" aria-label="Main navigation">
      {groups.map((group) => (
        <div key={group}>
          <p className="mb-1.5 px-2 text-[10.5px] font-semibold uppercase tracking-widest text-emerald-100/40">
            {group}
          </p>
          <div className="space-y-0.5">
            {items.filter((i) => i.group === group).map((item) => (
              <button
                key={item.key}
                onClick={() => { onView(item.key); setMobileOpen(false) }}
                aria-current={view === item.key ? 'page' : undefined}
                className={cn(
                  'group relative flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-[13.5px] font-medium transition-all duration-200',
                  view === item.key
                    ? 'bg-gradient-to-r from-emerald-400/20 via-emerald-400/10 to-transparent text-white shadow-[inset_0_0_0_1px_rgba(52,211,153,0.3)]'
                    : 'text-emerald-50/65 hover:translate-x-0.5 hover:bg-white/5 hover:text-white'
                )}
              >
                {view === item.key ? (
                  <span className="absolute left-0 top-1/2 h-5 w-1 -translate-y-1/2 rounded-r-full bg-emerald-300 shadow-[0_0_8px_2px_rgba(110,231,183,0.5)]" aria-hidden="true" />
                ) : null}
                <item.icon className={cn('h-4.5 w-4.5 shrink-0 transition-colors', view === item.key ? 'text-emerald-300' : 'text-emerald-100/50 group-hover:text-emerald-200')} />
                {item.label}
              </button>
            ))}
          </div>
        </div>
      ))}
    </nav>
  )

  const userCard = (
    <div className="border-t border-white/10 p-3">
      <div className="flex items-center gap-3 rounded-xl bg-white/5 px-3 py-2.5 ring-1 ring-white/10 transition-colors hover:bg-white/10">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-300 to-teal-500 text-sm font-bold text-emerald-950 shadow-md">
          {user.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold text-white">{user.name}</p>
          <p className="text-[11px] text-emerald-100/60">
            {user.role === 'ADMIN' ? 'Administrator' : 'Internal staff'}
          </p>
        </div>
        <button onClick={onLogout} aria-label="Sign out"
          className="rounded-md p-1.5 text-emerald-100/60 transition-colors hover:bg-white/10 hover:text-white">
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  )

  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="brand-gradient sticky top-0 hidden h-screen w-64 shrink-0 flex-col lg:flex print-hide">
        <div className="px-5 pb-2 pt-5">
          <Logo size={34} dark />
        </div>
        {navList}
        {userCard}
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="brand-gradient w-72 border-0 p-0 text-white">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          <div className="flex h-full flex-col">
            <div className="px-5 pb-2 pt-5"><Logo size={34} dark /></div>
            {navList}
            {userCard}
          </div>
        </SheetContent>
      </Sheet>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur print-hide">
          <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
            <Button variant="outline" size="icon" className="lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </Button>
            <div className="min-w-0 flex-1">
              <h2 className="truncate text-[15px] font-semibold leading-tight">{current?.label ?? 'Brightloop'}</h2>
              <p className="hidden text-xs text-muted-foreground sm:block">
                {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
            </div>
            <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Toggle dark mode">
              {dark ? <Sun className="h-4.5 w-4.5" /> : <Moon className="h-4.5 w-4.5" />}
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/15 text-[13px] font-bold text-primary transition-colors hover:bg-primary/25" aria-label="Account menu">
                  {user.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuLabel>
                  <div className="text-sm font-semibold">{user.name}</div>
                  <div className="text-xs font-normal text-muted-foreground">{user.email}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => onView('settings')}>Settings</DropdownMenuItem>
                <DropdownMenuItem onClick={onLogout} className="text-destructive focus:text-destructive">Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl view-enter">{children}</div>
        </main>
        <footer className="border-t py-4 text-center text-xs text-muted-foreground print-hide mt-auto">
          Brightloop Software — plans, subscriptions &amp; recurring billing in one place
        </footer>
      </div>
    </div>
  )
}
