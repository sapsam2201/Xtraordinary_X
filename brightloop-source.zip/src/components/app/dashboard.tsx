'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { fmtDate, fmtMoney, statusLabel } from './format'
import { ErrorNote, PageHeader, Spinner, StatCard, StatusBadge } from './ui-bits'
import type { BillingPreview, DashboardData } from './types'
import { Button } from '@/components/ui/button'
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, BarChart, Bar, Legend,
} from 'recharts'
import {
  AlertTriangle, BadgeIndianRupee, CalendarClock, FileText, Loader2, PlayCircle,
  RefreshCw, TrendingDown, TrendingUp, Users, Wallet, Zap,
} from 'lucide-react'
import { toast } from '@/hooks/use-toast'

const PIE_COLORS = ['#10b981', '#f59e0b', '#14b8a6', '#f43f5e', '#a78bfa', '#8b93a7']
const PERIODS = [
  { key: 'this_month', label: 'This month' },
  { key: 'last_month', label: 'Last month' },
  { key: 'quarter', label: 'This quarter' },
  { key: 'year', label: 'This year' },
  { key: 'all', label: 'All time' },
]

export function Dashboard({ onOpenInvoice, onOpenBilling }: { onOpenInvoice: (id: string) => void; onOpenBilling: () => void }) {
  const [data, setData] = useState<DashboardData | null>(null)
  const [preview, setPreview] = useState<BillingPreview | null>(null)
  const [period, setPeriod] = useState('this_month')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [running, setRunning] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [d, p] = await Promise.all([
        api.get<DashboardData>(`/api/dashboard?period=${period}`),
        api.get<BillingPreview>('/api/billing'),
      ])
      setData(d)
      setPreview(p)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard')
    } finally {
      setLoading(false)
    }
  }, [period])

  useEffect(() => { load() }, [load])

  async function runBilling() {
    setRunning(true)
    try {
      const res = await api.post<{ invoicesCreated: number; subscriptionsClosed: number }>('/api/billing')
      toast({
        title: 'Billing day complete',
        description: `${res.invoicesCreated} invoice(s) created, ${res.subscriptionsClosed} finished plan(s) closed.`,
      })
      await load()
      onOpenBilling()
    } catch (err) {
      toast({ title: 'Billing run failed', description: err instanceof Error ? err.message : 'Try again', variant: 'destructive' })
    } finally {
      setRunning(false)
    }
  }

  if (loading) return <Spinner />
  if (error || !data) {
    return (
      <div className="space-y-3">
        <ErrorNote message={error || 'No data'} />
        <Button variant="outline" size="sm" onClick={load}>
          <RefreshCw className="h-4 w-4" /> Try again
        </Button>
      </div>
    )
  }

  const k = data.kpis
  const revDelta = k.revenueThisMonth - k.revenuePrevMonth
  const deltaPct = k.revenuePrevMonth > 0 ? Math.round((revDelta / k.revenuePrevMonth) * 100) : null
  const invoicePie = data.invoicesByStatus.filter((s) => s.count > 0)

  return (
    <div className="space-y-6">
      <PageHeader
        title="Finance overview"
        subtitle="Active subscriptions, revenue, payments and overdue — the whole month in one view."
        actions={
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-40" aria-label="Reporting period">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PERIODS.map((p) => <SelectItem key={p.key} value={p.key}>{p.label}</SelectItem>)}
            </SelectContent>
          </Select>
        }
      />

      {/* Billing day hero */}
      <Card className="brand-gradient relative border-0 text-white overflow-hidden">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0">
          <div className="absolute -right-16 -top-24 h-64 w-64 rounded-full bg-emerald-300/15 blur-2xl" />
          <div className="absolute -bottom-28 left-1/3 h-56 w-56 rounded-full bg-amber-200/10 blur-2xl" />
          <svg className="absolute right-6 top-0 h-full opacity-[0.07]" viewBox="0 0 200 120" fill="none" preserveAspectRatio="xMaxYMid slice">
            <path d="M0 90c40 0 40-60 80-60s40 60 80 60 40-60 80-60" stroke="white" strokeWidth="3" strokeLinecap="round" />
          </svg>
        </div>
        <CardContent className="relative flex flex-wrap items-center justify-between gap-4 p-6">
          <div className="flex items-start gap-4">
            <div className="rounded-xl bg-emerald-400/20 p-3 shadow-[0_0_24px_-4px_rgba(52,211,153,0.5)]">
              <Zap className="h-6 w-6 text-emerald-300" />
            </div>
            <div>
              <p className="text-lg font-bold">Billing day</p>
              <p className="mt-0.5 text-sm text-emerald-50/80">
                {preview && preview.dueCount > 0
                  ? `${preview.dueCount} subscription${preview.dueCount === 1 ? '' : 's'} due for invoicing right now${preview.autoCloseCount ? ` · ${preview.autoCloseCount} finished plan${preview.autoCloseCount === 1 ? '' : 's'} will close` : ''}.`
                  : 'Everything is billed — no subscriptions are waiting.'}
              </p>
              {preview && preview.dueCount > 0 ? (
                <p className="mt-1 text-xs text-emerald-100/60">
                  Next up: {preview.due.slice(0, 3).map((d) => `${d.number} (${d.customer})`).join(', ')}{preview.dueCount > 3 ? ` +${preview.dueCount - 3} more` : ''}
                </p>
              ) : null}
            </div>
          </div>
          <Button size="lg" className="bg-white text-emerald-900 hover:bg-emerald-50" onClick={runBilling}
            disabled={running || !preview || preview.dueCount === 0}>
            {running ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlayCircle className="mr-2 h-4.5 w-4.5" />}
            Run billing day
          </Button>
        </CardContent>
      </Card>

      {/* KPI cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Active subscriptions" value={String(k.activeSubscriptions)}
          sub={`${k.customers} customers on the books`}
          icon={RefreshCw} tone="emerald"
        />
        <StatCard
          label="Monthly recurring revenue" value={fmtMoney(k.mrr, true)}
          sub="Normalised from live subscription lines"
          icon={BadgeIndianRupee} tone="teal"
        />
        <StatCard
          label={PERIODS.find((p) => p.key === period)?.label === 'This month' ? 'Revenue this month' : 'Revenue in period'}
          value={fmtMoney(k.revenueInPeriod, true)}
          sub={
            <span className="inline-flex items-center gap-1">
              {revDelta >= 0 ? <TrendingUp className="h-3.5 w-3.5 text-emerald-600" /> : <TrendingDown className="h-3.5 w-3.5 text-rose-600" />}
              {deltaPct === null ? `Prev month ${fmtMoney(k.revenuePrevMonth, true)}` : `${revDelta >= 0 ? '+' : ''}${deltaPct}% vs last month`}
            </span>
          }
          icon={Wallet} tone="default"
        />
        <StatCard
          label="Outstanding" value={fmtMoney(k.outstandingTotal, true)}
          sub={`${k.openInvoices} open invoice${k.openInvoices === 1 ? '' : 's'}`}
          icon={FileText} tone="amber"
        />
      </div>

      {/* Overdue banner */}
      {k.overdueCount > 0 ? (
        <div className="flex flex-wrap items-center gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 dark:border-rose-900 dark:bg-rose-950/40">
          <AlertTriangle className="h-5 w-5 shrink-0 text-rose-600 dark:text-rose-400" />
          <p className="flex-1 text-sm text-rose-800 dark:text-rose-200">
            <span className="font-bold">{k.overdueCount} overdue invoice{k.overdueCount === 1 ? '' : 's'}</span> worth{' '}
            <span className="font-bold">{fmtMoney(k.overdueAmount)}</span> — chase these before they turn into lost revenue.
          </p>
        </div>
      ) : null}

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Revenue collected</CardTitle>
            <CardDescription>Payments received over the last 6 months</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.revenueByMonth} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} vertical={false} />
                <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} />
                <YAxis tickLine={false} axisLine={false} fontSize={12} tickFormatter={(v: number) => fmtMoney(v, true)} width={62} />
                <Tooltip
                  formatter={(v) => [fmtMoney(Number(v)), 'Collected']}
                  contentStyle={{ borderRadius: 10, border: '1px solid rgba(0,0,0,0.08)' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={2.5} fill="url(#revGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Invoices by status</CardTitle>
            <CardDescription>Where every invoice stands</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={invoicePie} dataKey="count" nameKey="status" innerRadius={52} outerRadius={82} paddingAngle={3} strokeWidth={0}>
                  {invoicePie.map((entry, i) => (
                    <Cell key={entry.status} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(v, n) => [v, statusLabel(String(n))]} contentStyle={{ borderRadius: 10 }} />
                <Legend formatter={(v) => statusLabel(String(v))} iconType="circle" iconSize={8} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Active subscriptions by plan</CardTitle>
          </CardHeader>
          <CardContent className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.subsByPlan} layout="vertical" margin={{ left: 8, right: 16 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} horizontal={false} />
                <XAxis type="number" tickLine={false} axisLine={false} fontSize={12} allowDecimals={false} />
                <YAxis type="category" dataKey="plan" tickLine={false} axisLine={false} fontSize={11} width={130} />
                <Tooltip contentStyle={{ borderRadius: 10 }} />
                <Bar dataKey="count" fill="#14b8a6" radius={[0, 6, 6, 0]} barSize={16} name="Active subs" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Overdue table */}
        <Card className="xl:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-base">Overdue invoices</CardTitle>
              <CardDescription>Oldest first — follow up today</CardDescription>
            </div>
            <AlertTriangle className="h-4.5 w-4.5 text-rose-500" />
          </CardHeader>
          <CardContent>
            {data.overdueList.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">Nothing overdue. Enjoy the quiet.</p>
            ) : (
              <div className="overflow-hidden rounded-lg border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2 font-medium">Invoice</th>
                      <th className="px-3 py-2 font-medium">Customer</th>
                      <th className="px-3 py-2 font-medium text-right">Balance</th>
                      <th className="px-3 py-2 font-medium text-right">Due</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.overdueList.map((i) => (
                      <tr key={i.id} className="cursor-pointer border-t transition-colors hover:bg-muted/40"
                        onClick={() => onOpenInvoice(i.id)}>
                        <td className="px-3 py-2 font-medium">{i.number}</td>
                        <td className="px-3 py-2">{i.customer}</td>
                        <td className="px-3 py-2 text-right font-semibold text-rose-600">
                          {fmtMoney(i.total - i.amountPaid)}
                        </td>
                        <td className="px-3 py-2 text-right">
                          <span className="rounded-full bg-rose-100 px-2 py-0.5 text-xs font-semibold text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                            {i.daysOverdue}d late
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent + renewals */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Latest invoices</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            {data.recentInvoices.map((i) => (
              <button key={i.id} onClick={() => onOpenInvoice(i.id)}
                className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition-colors hover:bg-muted/50">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                  <FileText className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13.5px] font-medium">{i.number} · {i.customer}</p>
                  <p className="text-xs text-muted-foreground">Issued {fmtDate(i.issueDate)} · due {fmtDate(i.dueDate)}</p>
                </div>
                <div className="text-right">
                  <p className="text-[13.5px] font-semibold">{fmtMoney(i.total)}</p>
                  <StatusBadge status={i.status} className="mt-0.5" />
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Renewals in the next 30 days</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            {data.upcomingRenewals.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">No plans ending soon.</p>
            ) : (
              data.upcomingRenewals.map((s) => (
                <div key={s.id} className="flex items-center gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-muted/50">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                    <CalendarClock className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-medium">{s.customer}</p>
                    <p className="text-xs text-muted-foreground">{s.number} · {s.plan}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[13px] font-medium">{fmtDate(s.expiryDate)}</p>
                    {s.canRenew ? <p className="text-[11px] text-emerald-600">renewable</p> : <p className="text-[11px] text-muted-foreground">auto-close</p>}
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Subscription status strip */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Users className="h-4 w-4" /> Subscription pipeline</CardTitle>
          <CardDescription>Every subscription by lifecycle stage</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          {data.subscriptionsByStatus.map((s) => (
            <div key={s.status} className="flex items-center gap-2 rounded-lg border px-3 py-2">
              <StatusBadge status={s.status} />
              <span className="text-lg font-bold">{s.count}</span>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
