'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { api } from './api-client'
import { CYCLE_LABEL, fmtDate, fmtMoney, METHOD_LABEL, statusLabel, TERMS_LABEL } from './format'
import { Logo, Spinner, StatusBadge } from './ui-bits'
import { PrintableInvoice, PayDialog, printInvoice } from './invoices'
import type { Invoice, Payment, SessionUser, Subscription } from './types'
import type { LucideIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Switch } from '@/components/ui/switch'
import { Input } from '@/components/ui/input'
import { toast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import {
  ArrowRight, BadgeCheck, Banknote, Bell, CalendarClock, ChevronLeft, ChevronRight, Compass,
  CreditCard, FileText, Globe, Info, Landmark, Layers, LifeBuoy, LogOut, Mail, Moon, Package,
  Phone, Printer, RefreshCw, ScrollText, Search, Settings, Smartphone, Sparkles, Sun, Wallet, Zap,
} from 'lucide-react'

/* ------------------------------------------------------------------ */
/* helpers & static config                                             */
/* ------------------------------------------------------------------ */

type CatalogPlan = {
  id: string
  name: string
  description: string | null
  product?: { name: string } | null
  price: number
  billingCycle: string
}

const CYCLE_SHORT: Record<string, string> = { DAILY: 'day', WEEKLY: 'week', MONTHLY: 'month', YEARLY: 'year' }
const CYCLE_DAYS: Record<string, number> = { DAILY: 1, WEEKLY: 7, MONTHLY: 30, YEARLY: 365 }

const COVERS = [
  'from-emerald-500 via-teal-500 to-cyan-600',
  'from-teal-500 via-cyan-500 to-sky-600',
  'from-amber-500 via-orange-500 to-rose-500',
  'from-violet-500 via-purple-500 to-fuchsia-600',
  'from-rose-500 via-pink-500 to-orange-500',
  'from-sky-500 via-blue-500 to-indigo-600',
]
const COVER_ICONS: LucideIcon[] = [Layers, Sparkles, Globe, Package, Zap, Compass]

const METHOD_ICON: Record<string, LucideIcon> = {
  CARD: CreditCard,
  BANK_TRANSFER: Landmark,
  UPI: Smartphone,
  CASH: Banknote,
  CHEQUE: ScrollText,
}

type PortalTab = 'home' | 'plans' | 'browse' | 'billing' | 'support'

const TABS: { key: PortalTab; label: string }[] = [
  { key: 'home', label: 'Home' },
  { key: 'plans', label: 'My plans' },
  { key: 'browse', label: 'Browse' },
  { key: 'billing', label: 'Billing' },
  { key: 'support', label: 'Support' },
]

function hashIndex(id: string, mod: number) {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0
  return h % mod
}

function initialsOf(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase()
}

function cycleProgress(s: Subscription) {
  if (!s.nextBillingDate) return null
  const len = CYCLE_DAYS[s.plan?.billingCycle ?? ''] ?? 30
  const daysLeft = Math.ceil((new Date(s.nextBillingDate).getTime() - Date.now()) / 86400000)
  if (daysLeft < 0 || daysLeft > len) return null
  const elapsed = len - daysLeft
  const pct = Math.max(5, Math.min(100, Math.round((elapsed / len) * 100)))
  return { elapsed, len, daysLeft, pct }
}

function subTotal(s: Subscription) {
  return s.lines.reduce((sum, l) => sum + l.quantity * l.unitPrice * (1 + l.taxRate / 100), 0)
}

function monthlyOf(s: Subscription) {
  const cycle = s.plan?.billingCycle ?? 'MONTHLY'
  const t = subTotal(s)
  if (cycle === 'DAILY') return t * 30
  if (cycle === 'WEEKLY') return (t * 30) / 7
  if (cycle === 'YEARLY') return t / 12
  return t
}

function relTime(d: string) {
  const diff = Date.now() - new Date(d).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const days = Math.floor(h / 24)
  if (days < 7) return `${days}d ago`
  return fmtDate(d)
}

type FeedItem = {
  id: string
  kind: 'invoice' | 'payment' | 'renewal' | 'paid' | 'overdue'
  when: string
  title: string
  body: string
}

function buildFeed(invoices: Invoice[], payments: Payment[], subs: Subscription[]): FeedItem[] {
  const today = new Date().toISOString().slice(0, 10)
  const items: FeedItem[] = []
  for (const i of invoices) {
    if (i.status === 'PAID' && i.paidAt) {
      items.push({ id: `paid-${i.id}`, kind: 'paid', when: i.paidAt, title: 'Payment received', body: `${i.number} is fully settled — thank you!` })
    } else if (i.status === 'CONFIRMED' && i.dueDate.slice(0, 10) < today) {
      items.push({ id: `overdue-${i.id}`, kind: 'overdue', when: i.dueDate, title: `Invoice ${i.number} is overdue`, body: `${fmtMoney(i.total - i.amountPaid)} was due on ${fmtDate(i.dueDate)}. Pay now to stay in good standing.` })
    } else if (i.status === 'CONFIRMED') {
      items.push({ id: `inv-${i.id}`, kind: 'invoice', when: i.issueDate, title: `Invoice ${i.number} issued`, body: `${fmtMoney(i.total)} due ${fmtDate(i.dueDate)}${i.subscription?.plan?.name ? ` · ${i.subscription.plan.name}` : ''}` })
    }
  }
  for (const p of payments) {
    items.push({ id: `pay-${p.id}`, kind: 'payment', when: p.date, title: `Payment of ${fmtMoney(p.amount)} received`, body: `${p.number} · ${METHOD_LABEL[p.method] ?? p.method}${p.invoice?.number ? ` · against ${p.invoice.number}` : ''}` })
  }
  for (const s of subs) {
    if (s.status !== 'ACTIVE' || !s.nextBillingDate) continue
    const days = Math.ceil((new Date(s.nextBillingDate).getTime() - Date.now()) / 86400000)
    if (days >= 0 && days <= 7) {
      items.push({ id: `ren-${s.id}`, kind: 'renewal', when: s.nextBillingDate, title: 'Renewal coming up', body: `${s.plan?.name ?? s.number} renews on ${fmtDate(s.nextBillingDate)} — no action needed.` })
    }
  }
  return items.sort((a, b) => new Date(b.when).getTime() - new Date(a.when).getTime())
}

const FEED_STYLE: Record<FeedItem['kind'], { icon: LucideIcon; tone: string }> = {
  invoice: { icon: FileText, tone: 'bg-primary/10 text-primary' },
  payment: { icon: CreditCard, tone: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' },
  paid: { icon: BadgeCheck, tone: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' },
  overdue: { icon: Wallet, tone: 'bg-rose-100 text-rose-600 dark:bg-rose-950 dark:text-rose-300' },
  renewal: { icon: CalendarClock, tone: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300' },
}

const FAQ: { q: string; a: string }[] = [
  {
    q: 'How do I pay an invoice?',
    a: 'Open the Billing tab, click any open invoice and press "Pay now". You can pay by card, UPI or bank transfer. Paid invoices are stamped immediately and a receipt stays available in your history.',
  },
  {
    q: 'When am I charged for my plans?',
    a: 'Each plan bills on its own cycle — daily, weekly, monthly or yearly. Every plan card shows a progress bar with the exact day of the cycle you are in and the next billing date.',
  },
  {
    q: 'Can I pause or cancel a plan?',
    a: 'Pause and early-close options depend on the plan terms your company signed. Ask your account manager — they can pause, renew or close any plan from their side the same day.',
  },
  {
    q: 'How do I add another plan or add-on?',
    a: 'Browse the catalog in the Browse tab, open the plan you like and send the request. Your account manager confirms pricing and activates it — it then appears under My plans.',
  },
  {
    q: 'Where are my GST details?',
    a: 'Every invoice PDF carries the full tax breakdown per line, your GSTIN and Brightloop\'s tax registration. Open any invoice in the Billing tab and use "Print / PDF" to download it.',
  },
  {
    q: 'How do I update our billing contact or address?',
    a: 'Billing details are managed by your account team to keep invoices compliant. Contact your account manager and they will update the records used on the next invoice.',
  },
  {
    q: 'What do the plan statuses mean?',
    a: 'Active — running and billing normally. Paused — temporarily stopped, no invoices raised. Pending — requested or quoted, not yet started. Ended — the plan period finished.',
  },
]

/* ------------------------------------------------------------------ */
/* main component                                                      */
/* ------------------------------------------------------------------ */

export function CustomerPortal({ user, onLogout }: { user: SessionUser; onLogout: () => void }) {
  const [subs, setSubs] = useState<Subscription[] | null>(null)
  const [invoices, setInvoices] = useState<Invoice[] | null>(null)
  const [payments, setPayments] = useState<Payment[] | null>(null)
  const [catalog, setCatalog] = useState<CatalogPlan[] | null>(null)
  const [tab, setTab] = useState<PortalTab>('home')
  const [detail, setDetail] = useState<Invoice | null>(null)
  const [payOpen, setPayOpen] = useState(false)
  const [subDetail, setSubDetail] = useState<Subscription | null>(null)
  const [subInvoices, setSubInvoices] = useState<Invoice[]>([])
  const [browseDetail, setBrowseDetail] = useState<CatalogPlan | null>(null)
  const [accountOpen, setAccountOpen] = useState(false)
  const [dark, setDark] = useState(false)
  const [seenAt, setSeenAt] = useState<string>('1970-01-01T00:00:00.000Z')
  const railRef = useRef<HTMLDivElement>(null)

  const load = useCallback(async () => {
    const [s, i, p] = await Promise.all([
      api.get<{ subscriptions: Subscription[] }>('/api/subscriptions'),
      api.get<{ invoices: Invoice[] }>('/api/invoices'),
      api.get<{ payments: Payment[] }>('/api/payments').catch(() => ({ payments: [] as Payment[] })),
    ])
    setSubs(s.subscriptions)
    setInvoices(i.invoices)
    setPayments(p.payments)
  }, [])

  useEffect(() => {
    let cancelled = false
    queueMicrotask(() => {
      if (window.localStorage.getItem('bl_portal_theme') === 'dark') {
        setDark(true)
        document.documentElement.classList.add('dark')
      }
      const storedSeen = window.localStorage.getItem('bl_portal_seen')
      if (storedSeen) setSeenAt(storedSeen)
    })
    ;(async () => {
      try {
        const [s, i, p, pl] = await Promise.all([
          api.get<{ subscriptions: Subscription[] }>('/api/subscriptions'),
          api.get<{ invoices: Invoice[] }>('/api/invoices'),
          api.get<{ payments: Payment[] }>('/api/payments').catch(() => ({ payments: [] as Payment[] })),
          api.get<{ plans: CatalogPlan[] }>('/api/plans').catch(() => ({ plans: [] as CatalogPlan[] })),
        ])
        if (!cancelled) {
          setSubs(s.subscriptions)
          setInvoices(i.invoices)
          setPayments(p.payments)
          setCatalog(pl.plans)
        }
      } catch (err) {
        if (!cancelled) {
          toast({ title: 'Could not load your data', description: err instanceof Error ? err.message : '', variant: 'destructive' })
        }
      }
    })()
    return () => { cancelled = true }
  }, [load])

  const stats = useMemo(() => {
    const active = (subs ?? []).filter((s) => s.status === 'ACTIVE')
    const paused = (subs ?? []).filter((s) => s.status === 'PAUSED')
    const running = [...active, ...paused]
    const open = (invoices ?? []).filter((i) => i.status === 'CONFIRMED')
    const outstanding = open.reduce((sum, i) => sum + (i.total - i.amountPaid), 0)
    const overdue = open.filter((i) => i.dueDate.slice(0, 10) < new Date().toISOString().slice(0, 10))
    const today = new Date().toISOString().slice(0, 10)
    const nextBill = active
      .map((s) => s.nextBillingDate)
      .filter((d): d is string => !!d && d.slice(0, 10) >= today)
      .sort()[0]
    const nextSub = active.find((s) => s.nextBillingDate === nextBill)
    const paidLifetime = (payments ?? []).reduce((sum, p) => sum + p.amount, 0)
    const monthlyValue = running.reduce((sum, s) => sum + monthlyOf(s), 0)
    return { active, paused, running, open, outstanding, overdue: overdue.length, nextBill, nextSub, openCount: open.length, paidLifetime, monthlyValue }
  }, [subs, invoices, payments])

  const feed = useMemo(() => buildFeed(invoices ?? [], payments ?? [], subs ?? []), [invoices, payments, subs])
  const unread = useMemo(() => feed.filter((f) => f.when > seenAt && f.when <= new Date().toISOString()).length, [feed, seenAt])
  const subPlanIds = useMemo(() => new Set((subs ?? []).map((s) => s.planId).filter(Boolean)), [subs])
  const recommended = useMemo(() => (catalog ?? []).filter((p) => !subPlanIds.has(p.id)).slice(0, 3), [catalog, subPlanIds])

  const hour = new Date().getHours()
  const greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
  const firstName = user.name.split(' ')[0]

  function goTab(t: PortalTab) {
    setTab(t)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function toggleTheme() {
    const next = !dark
    setDark(next)
    document.documentElement.classList.toggle('dark', next)
    window.localStorage.setItem('bl_portal_theme', next ? 'dark' : 'light')
  }

  function markSeen() {
    const now = new Date().toISOString()
    setSeenAt(now)
    window.localStorage.setItem('bl_portal_seen', now)
  }

  async function openInvoice(inv: Invoice) {
    try {
      const res = await api.get<{ invoice: Invoice }>(`/api/invoices/${inv.id}`)
      setDetail(res.invoice)
    } catch (err) {
      toast({ title: 'Could not open invoice', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  function openSub(s: Subscription) {
    setSubInvoices((invoices ?? []).filter((i) => i.subscriptionId === s.id))
    setSubDetail(s)
  }

  function scrollRail(dir: number) {
    railRef.current?.scrollBy({ left: dir * 320, behavior: 'smooth' })
  }

  if (!subs || !invoices) return <Spinner />

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-emerald-50/70 via-background to-background dark:from-emerald-950/10">
      {/* ------------------------- header ------------------------- */}
      <header className="sticky top-0 z-30 border-b bg-background/90 backdrop-blur print-hide">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-2.5 sm:px-6">
          <button onClick={() => goTab('home')} aria-label="Brightloop home" className="shrink-0">
            <Logo size={34} />
          </button>
          <div className="ml-auto flex items-center gap-1.5">
            <Popover onOpenChange={(open) => { if (open) markSeen() }}>
              <PopoverTrigger asChild>
                <button className="relative rounded-full p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`}>
                  <Bell className="h-5 w-5" />
                  {unread > 0 ? (
                    <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[9.5px] font-bold text-white">
                      {unread > 9 ? '9+' : unread}
                    </span>
                  ) : null}
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-80 p-0">
                <p className="border-b px-4 py-3 text-sm font-bold">Notifications</p>
                <div className="max-h-80 overflow-y-auto scroll-slim">
                  {feed.length === 0 ? (
                    <p className="px-4 py-8 text-center text-sm text-muted-foreground">Nothing yet — billing updates will land here.</p>
                  ) : (
                    feed.slice(0, 10).map((f) => <FeedRow key={f.id} item={f} />)
                  )}
                </div>
              </PopoverContent>
            </Popover>
            <button onClick={toggleTheme} className="rounded-full p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" aria-label="Toggle dark mode">
              {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="ml-1 flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 text-[13px] font-bold text-white shadow-md transition-transform hover:scale-105" aria-label="Account menu">
                  {initialsOf(user.name)}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="text-sm font-semibold">{user.name}</div>
                  <div className="text-xs font-normal text-muted-foreground">{user.customerName ?? user.email}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setAccountOpen(true)}>
                  <Settings className="mr-2 h-4 w-4" /> Account settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onLogout} className="text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        {/* Udemy-style tab bar */}
        <nav className="mx-auto flex max-w-6xl items-center gap-1 overflow-x-auto px-2 sm:justify-center scroll-slim" aria-label="Portal sections">
          {TABS.map((t) => (
            <button key={t.key} onClick={() => goTab(t.key)} aria-current={tab === t.key ? 'page' : undefined}
              className={cn(
                'whitespace-nowrap border-b-2 px-3.5 py-2.5 text-[13.5px] font-medium transition-colors',
                tab === t.key
                  ? 'border-primary font-semibold text-foreground'
                  : 'border-transparent text-muted-foreground hover:border-border hover:text-foreground'
              )}>
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-12 sm:px-6">
        {/* ============================ HOME ============================ */}
        {tab === 'home' ? (
          <div className="view-enter">
            <section className="relative mt-6 overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700 p-7 text-white shadow-xl sm:p-9">
              <div aria-hidden="true" className="pointer-events-none absolute inset-0">
                <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full bg-white/10 blur-2xl" />
                <div className="absolute -bottom-28 left-1/4 h-64 w-64 rounded-full bg-cyan-300/15 blur-2xl" />
                <div className="absolute right-10 top-8 h-24 w-24 rounded-full border-[10px] border-white/10" />
                <div className="absolute bottom-6 right-40 h-12 w-12 rounded-full bg-amber-300/30 blur-sm" />
              </div>
              <div className="relative flex flex-wrap items-center justify-between gap-6">
                <div className="max-w-xl">
                  <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-[10.5px] font-bold uppercase tracking-[0.16em] text-emerald-50 ring-1 ring-white/25">
                    <Sparkles className="h-3 w-3" /> Customer portal
                  </span>
                  <h1 className="mt-4 text-3xl font-black leading-tight tracking-tight sm:text-4xl">
                    {greet}, {firstName}.
                  </h1>
                  <p className="mt-2 text-[15px] leading-relaxed text-emerald-50/90">
                    {stats.active.length > 0
                      ? <>You have <b className="font-bold text-white">{stats.active.length} active plan{stats.active.length === 1 ? '' : 's'}</b> running
                        {stats.paused.length > 0 ? <> plus <b className="font-bold text-white">{stats.paused.length} paused</b></> : null}
                        {stats.nextBill ? <> and your next payment lands on <b className="font-bold text-white">{fmtDate(stats.nextBill)}</b></> : null}.
                        Everything about your billing lives here — no emails needed.</>
                      : stats.paused.length > 0
                      ? <>Your plan{stats.paused.length === 1 ? ' is' : 's are'} paused right now. Your account manager can resume it whenever you're ready — meanwhile every invoice and payment stays available here.</>
                      : <>Welcome aboard. When your account team adds a plan, it will appear here together with every invoice and payment.</>}
                  </p>
                  <div className="mt-5 flex flex-wrap items-center gap-3">
                    {stats.outstanding > 0.005 ? (
                      <Button size="lg" className="bg-white text-emerald-800 shadow-lg hover:bg-emerald-50" onClick={() => goTab('billing')}>
                        <Wallet className="mr-2 h-4.5 w-4.5" /> Pay {fmtMoney(stats.outstanding)} now
                      </Button>
                    ) : (
                      <Button size="lg" className="bg-white text-emerald-800 shadow-lg hover:bg-emerald-50" onClick={() => goTab('plans')}>
                        <Layers className="mr-2 h-4.5 w-4.5" /> View my plans
                      </Button>
                    )}
                    <Button size="lg" variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20 hover:text-white" onClick={() => goTab('browse')}>
                      <Compass className="mr-2 h-4.5 w-4.5" /> Browse catalog
                    </Button>
                    {stats.overdue > 0 ? (
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-rose-500/90 px-3 py-1.5 text-xs font-bold text-white">
                        {stats.overdue} overdue invoice{stats.overdue === 1 ? '' : 's'}
                      </span>
                    ) : null}
                  </div>
                </div>
                {/* membership snapshot card */}
                <div className="hidden w-56 shrink-0 rounded-2xl bg-white/10 p-5 ring-1 ring-white/25 backdrop-blur-md lg:block">
                  <p className="text-[10.5px] font-bold uppercase tracking-[0.16em] text-emerald-100/80">Your membership</p>
                  <p className="mt-2 text-3xl font-black leading-none">{stats.active.length}</p>
                  <p className="text-xs text-emerald-100/80">active plan{stats.active.length === 1 ? '' : 's'}</p>
                  {stats.paused.length > 0 ? <p className="mt-0.5 text-[11px] text-amber-200">+ {stats.paused.length} paused</p> : null}
                  <div className="my-3 h-px bg-white/20" />
                  <p className="text-[11px] text-emerald-100/70">Next payment</p>
                  <p className="text-sm font-bold">{stats.nextBill ? fmtDate(stats.nextBill) : '—'}</p>
                  <div className="my-3 h-px bg-white/20" />
                  <p className="text-[11px] text-emerald-100/70">Approx. monthly value</p>
                  <p className="text-sm font-bold">{fmtMoney(stats.monthlyValue)}</p>
                </div>
              </div>
            </section>

            {/* quick stats */}
            <section className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Tile icon={Layers} tone="emerald" label="Active plans" value={String(stats.active.length)} sub={stats.paused.length > 0 ? `+${stats.paused.length} paused` : 'running right now'} />
              <Tile
                icon={CalendarClock} tone="teal" label="Next payment"
                value={stats.nextBill ? fmtDate(stats.nextBill) : '—'}
                sub={stats.nextSub?.plan ? `${stats.nextSub.plan.name} · ${CYCLE_LABEL[stats.nextSub.plan.billingCycle]}` : 'No scheduled billing'}
              />
              <Tile
                icon={Wallet} tone={stats.overdue > 0 ? 'rose' : stats.outstanding > 0.005 ? 'amber' : 'emerald'}
                label="Outstanding balance" value={fmtMoney(stats.outstanding)}
                sub={stats.overdue > 0 ? `${stats.overdue} invoice${stats.overdue === 1 ? '' : 's'} overdue` : stats.outstanding > 0.005 ? `${stats.openCount} open invoice${stats.openCount === 1 ? '' : 's'}` : 'Nothing pending'}
              />
            </section>

            {/* continue where you left off */}
            {stats.running.length > 0 ? (
              <section className="mt-10">
                <div className="mb-4 flex items-end justify-between gap-2">
                  <div>
                    <h2 className="text-xl font-bold tracking-tight">Continue where you left off</h2>
                    <p className="mt-0.5 text-sm text-muted-foreground">Your running plans and where each one stands in its cycle</p>
                  </div>
                  <div className="hidden gap-1.5 sm:flex">
                    <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={() => scrollRail(-1)} aria-label="Scroll left">
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={() => scrollRail(1)} aria-label="Scroll right">
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div ref={railRef} className="-mx-1 flex snap-x snap-mandatory gap-4 overflow-x-auto px-1 pb-2 scroll-slim">
                  {stats.running.map((s) => (
                    <div key={s.id} className="w-[290px] shrink-0 snap-start">
                      <PlanCard sub={s} onClick={() => openSub(s)} />
                    </div>
                  ))}
                </div>
              </section>
            ) : null}

            {/* recommended */}
            {recommended.length > 0 ? (
              <section className="mt-10">
                <SectionHead title="Recommended for you" hint="Popular with businesses like yours — ask your account manager to add any of these" />
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
                  {recommended.map((p) => (
                    <CatalogCard key={p.id} plan={p} onOpen={() => setBrowseDetail(p)} compact />
                  ))}
                </div>
              </section>
            ) : null}

            {/* activity + tips */}
            <section className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-5">
              <div className="lg:col-span-3">
                <SectionHead title="Recent activity" hint="The latest updates on your account" />
                <div className="overflow-hidden rounded-2xl border bg-card shadow-sm">
                  {feed.length === 0 ? (
                    <p className="px-4 py-10 text-center text-sm text-muted-foreground">No activity yet — your invoices and payments will show up here.</p>
                  ) : (
                    <div className="divide-y">
                      {feed.slice(0, 5).map((f) => <FeedRow key={f.id} item={f} />)}
                    </div>
                  )}
                  {feed.length > 5 ? (
                    <button onClick={() => goTab('billing')} className="flex w-full items-center justify-center gap-1.5 py-3 text-[13px] font-semibold text-primary transition-colors hover:bg-muted/50">
                      See all billing activity <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  ) : null}
                </div>
              </div>
              <div className="lg:col-span-2">
                <SectionHead title="Get more from Brightloop" hint="Quick tips from the team" />
                <div className="space-y-3">
                  {[
                    { icon: Compass, title: 'Explore the catalog', body: 'Add-ons and new plans are one request away.', tab: 'browse' as PortalTab },
                    { icon: Wallet, title: 'Clear open invoices', body: 'Pay card, UPI or bank transfer in two clicks.', tab: 'billing' as PortalTab },
                    { icon: LifeBuoy, title: 'Need a hand?', body: 'Answers to the most common billing questions.', tab: 'support' as PortalTab },
                  ].map((tip) => (
                    <button key={tip.title} onClick={() => goTab(tip.tab)}
                      className="group flex w-full items-start gap-3.5 rounded-2xl border bg-card p-4 text-left shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary transition-transform group-hover:scale-110">
                        <tip.icon className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="flex items-center gap-1.5 text-sm font-bold">{tip.title} <ChevronRight className="h-3.5 w-3.5 text-muted-foreground transition-transform group-hover:translate-x-0.5" /></p>
                        <p className="mt-0.5 text-[13px] text-muted-foreground">{tip.body}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </section>
          </div>
        ) : null}

        {/* ============================ MY PLANS ============================ */}
        {tab === 'plans' ? (
          <PlansTab subs={subs} onOpenSub={openSub} />
        ) : null}

        {/* ============================ BROWSE ============================ */}
        {tab === 'browse' ? (
          <BrowseTab catalog={catalog ?? []} subs={subs} onOpen={setBrowseDetail} />
        ) : null}

        {/* ============================ BILLING ============================ */}
        {tab === 'billing' ? (
          <BillingTab
            invoices={invoices} payments={payments ?? []} stats={stats}
            onOpenInvoice={openInvoice}
          />
        ) : null}

        {/* ============================ SUPPORT ============================ */}
        {tab === 'support' ? (
          <SupportTab goTab={goTab} customerName={user.customerName ?? user.name} />
        ) : null}
      </main>

      <footer className="border-t bg-card/50 py-4 text-center text-xs text-muted-foreground print-hide">
        Brightloop Software · customer portal — plans, invoices and payments in one friendly place
      </footer>

      {/* ------------------------- dialogs ------------------------- */}
      <Dialog open={!!detail} onOpenChange={(open) => { if (!open) setDetail(null) }}>
        <DialogContent className="max-h-[94vh] max-w-2xl overflow-y-auto scroll-slim">
          {detail ? (
            <>
              <DialogHeader className="print-hide">
                <DialogTitle className="flex items-center gap-3">{detail.number} <StatusBadge status={detail.status} /></DialogTitle>
                <DialogDescription>Issued {fmtDate(detail.issueDate)} · due {fmtDate(detail.dueDate)}</DialogDescription>
              </DialogHeader>
              <PrintableInvoice invoice={detail} />
              <div className="print-hide flex flex-wrap gap-2">
                {detail.status === 'CONFIRMED' && detail.total - detail.amountPaid > 0.005 ? (
                  <Button onClick={() => setPayOpen(true)}>
                    <CreditCard className="mr-1.5 h-4 w-4" /> Pay {fmtMoney(detail.total - detail.amountPaid)} now
                  </Button>
                ) : null}
                <Button variant="outline" onClick={() => printInvoice()}>
                  <Printer className="mr-1.5 h-4 w-4" /> Print / PDF
                </Button>
              </div>
              {payOpen ? (
                <PayDialog
                  invoice={detail}
                  role="CUSTOMER"
                  onClose={() => setPayOpen(false)}
                  onPaid={async () => {
                    setPayOpen(false)
                    setDetail(null)
                    await load()
                    toast({ title: 'Payment recorded', description: 'Thank you!' })
                  }}
                />
              ) : null}
            </>
          ) : null}
        </DialogContent>
      </Dialog>

      <Dialog open={!!subDetail} onOpenChange={(open) => { if (!open) setSubDetail(null) }}>
        <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto scroll-slim">
          {subDetail ? (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">{subDetail.plan?.name ?? 'Custom subscription'} <StatusBadge status={subDetail.status} /></DialogTitle>
                <DialogDescription>
                  {subDetail.number} · {subDetail.plan ? `${CYCLE_LABEL[subDetail.plan.billingCycle]} billing` : 'ad-hoc'} · {TERMS_LABEL[subDetail.paymentTerms]}
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-3 gap-3 text-sm">
                <PortalInfo label="Start" value={fmtDate(subDetail.startDate)} />
                <PortalInfo label="Expiry" value={subDetail.expiryDate ? fmtDate(subDetail.expiryDate) : 'Open ended'} />
                <PortalInfo label="Next bill" value={subDetail.nextBillingDate ? fmtDate(subDetail.nextBillingDate) : '—'} />
              </div>
              <div className="overflow-hidden rounded-lg border">
                <table className="w-full text-sm">
                  <tbody>
                    {subDetail.lines.map((l) => (
                      <tr key={l.id} className="border-b last:border-0">
                        <td className="px-3 py-2">{l.product?.name ?? l.description} <span className="text-muted-foreground">×{l.quantity}</span></td>
                        <td className="px-3 py-2 text-right text-muted-foreground">{l.taxRate}% tax</td>
                        <td className="px-3 py-2 text-right font-medium">{fmtMoney(l.quantity * l.unitPrice * (1 + l.taxRate / 100))}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {subInvoices.length > 0 ? (
                <div>
                  <p className="mb-2 flex items-center gap-1.5 text-[13px] font-semibold"><FileText className="h-4 w-4" /> Invoices for this plan</p>
                  <div className="max-h-52 space-y-1 overflow-y-auto scroll-slim">
                    {subInvoices.map((inv) => (
                      <button key={inv.id} className="flex w-full items-center gap-2 rounded-lg border px-3 py-2 text-sm transition-colors hover:bg-muted/50"
                        onClick={() => { setSubDetail(null); openInvoice(inv) }}>
                        <span className="font-medium">{inv.number}</span>
                        <span className="text-xs text-muted-foreground">{fmtDate(inv.issueDate)}</span>
                        <span className="ml-auto font-semibold">{fmtMoney(inv.total)}</span>
                        <StatusBadge status={inv.status} />
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}
            </>
          ) : null}
        </DialogContent>
      </Dialog>

      <Dialog open={!!browseDetail} onOpenChange={(open) => { if (!open) setBrowseDetail(null) }}>
        <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto scroll-slim">
          {browseDetail ? (
            <>
              <div className={cn('relative -mx-2 -mt-2 mb-4 flex h-28 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br', COVERS[hashIndex(browseDetail.id, COVERS.length)])}>
                <div aria-hidden="true" className="absolute -right-8 -top-10 h-28 w-28 rounded-full bg-white/15" />
                <span className="relative text-3xl font-black tracking-tight text-white drop-shadow-md">{initialsOf(browseDetail.name)}</span>
              </div>
              <DialogHeader>
                <DialogTitle>{browseDetail.name}</DialogTitle>
                <DialogDescription>
                  {browseDetail.product?.name ? `${browseDetail.product.name} · ` : ''}
                  {fmtMoney(browseDetail.price)} / {CYCLE_SHORT[browseDetail.billingCycle] ?? 'cycle'}
                </DialogDescription>
              </DialogHeader>
              <p className="text-sm leading-relaxed text-muted-foreground">{browseDetail.description ?? 'Tailored for your business needs.'}</p>
              <div>
                <p className="mb-2 text-[13px] font-bold">What&apos;s included</p>
                <ul className="space-y-2">
                  {planFeatures(browseDetail).map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <BadgeCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" /> {f}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl bg-muted/60 p-3.5 text-[13px] leading-relaxed text-muted-foreground">
                <span className="font-semibold text-foreground">How to get it:</span> send the request and your account manager will confirm
                pricing, quantity and start date. The plan appears under <b className="text-foreground">My plans</b> once activated.
              </div>
              <div className="flex flex-wrap gap-2">
                <Button asChild>
                  <a href={requestMailto(browseDetail, user)}>
                    <Mail className="mr-1.5 h-4 w-4" /> Request this plan
                  </a>
                </Button>
                {subPlanIds.has(browseDetail.id) ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-2 text-xs font-bold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                    <BadgeCheck className="h-4 w-4" /> Already on this plan
                  </span>
                ) : null}
              </div>
            </>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* account settings */}
      <Dialog open={accountOpen} onOpenChange={setAccountOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Account settings</DialogTitle>
            <DialogDescription>Your profile and portal preferences</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <PortalInfo label="Name" value={user.name} />
              <PortalInfo label="Email" value={user.email} />
              <PortalInfo label="Company" value={user.customerName ?? '—'} />
              <PortalInfo label="Role" value="Customer" />
            </div>
            <div className="flex items-center justify-between rounded-xl border p-3.5">
              <div>
                <p className="text-sm font-semibold">Dark appearance</p>
                <p className="text-xs text-muted-foreground">Easier on the eyes at night</p>
              </div>
              <Switch checked={dark} onCheckedChange={toggleTheme} aria-label="Toggle dark appearance" />
            </div>
            <p className="rounded-xl bg-muted/60 p-3.5 text-[13px] leading-relaxed text-muted-foreground">
              Billing details (address, GSTIN, payment terms) are managed by your account team.
              Raise a request from the <button className="font-semibold text-primary underline-offset-2 hover:underline" onClick={() => { setAccountOpen(false); goTab('support') }}>Support</button> tab to change them.
            </p>
            <Button variant="destructive" className="w-full" onClick={onLogout}>
              <LogOut className="mr-1.5 h-4 w-4" /> Sign out
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* tab: my plans                                                       */
/* ------------------------------------------------------------------ */

function PlansTab({ subs, onOpenSub }: { subs: Subscription[]; onOpenSub: (s: Subscription) => void }) {
  const [filter, setFilter] = useState<'ALL' | 'ACTIVE' | 'PENDING' | 'PAUSED' | 'ENDED'>('ALL')

  const groups = useMemo(() => ({
    ACTIVE: subs.filter((s) => s.status === 'ACTIVE'),
    PENDING: subs.filter((s) => ['DRAFT', 'QUOTATION', 'CONFIRMED'].includes(s.status)),
    PAUSED: subs.filter((s) => s.status === 'PAUSED'),
    ENDED: subs.filter((s) => s.status === 'CLOSED' || s.status === 'CANCELLED'),
  }), [subs])

  const shown = filter === 'ALL' ? subs : groups[filter]
  const CHIPS: { key: typeof filter; label: string }[] = [
    { key: 'ALL', label: `All (${subs.length})` },
    { key: 'ACTIVE', label: `Active (${groups.ACTIVE.length})` },
    { key: 'PENDING', label: `Pending (${groups.PENDING.length})` },
    { key: 'PAUSED', label: `Paused (${groups.PAUSED.length})` },
    { key: 'ENDED', label: `Ended (${groups.ENDED.length})` },
  ]

  return (
    <div className="view-enter mt-8">
      <SectionHead title="My plans" hint="Everything you're subscribed to, with live billing progress" />
      <div className="mb-5 flex gap-2 overflow-x-auto pb-1 scroll-slim">
        {CHIPS.map((c) => (
          <button key={c.key} onClick={() => setFilter(c.key)}
            className={cn(
              'whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition-colors',
              filter === c.key
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground'
            )}>
            {c.label}
          </button>
        ))}
      </div>
      {shown.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed bg-card py-14 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Layers className="h-7 w-7" />
          </div>
          <p className="font-semibold">Nothing here yet</p>
          <p className="max-w-sm text-sm text-muted-foreground">
            {filter === 'ALL'
              ? 'Your account team will set you up — browse the catalog to see what\'s available.'
              : 'Try another filter to see your other plans.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {shown.map((s) => <PlanCard key={s.id} sub={s} onClick={() => onOpenSub(s)} />)}
        </div>
      )}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* tab: browse                                                         */
/* ------------------------------------------------------------------ */

function BrowseTab({ catalog, subs, onOpen }: { catalog: CatalogPlan[]; subs: Subscription[]; onOpen: (p: CatalogPlan) => void }) {
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('All')
  const [sort, setSort] = useState<'featured' | 'priceAsc' | 'priceDesc' | 'name'>('featured')
  const subPlanIds = useMemo(() => new Set(subs.map((s) => s.planId).filter(Boolean)), [subs])
  const categories = useMemo(() => ['All', ...[...new Set(catalog.map((p) => p.product?.name ?? 'Other'))]], [catalog])

  const shown = useMemo(() => {
    let list = catalog.filter((p) => cat === 'All' || (p.product?.name ?? 'Other') === cat)
    if (q.trim()) {
      const needle = q.trim().toLowerCase()
      list = list.filter((p) => `${p.name} ${p.description ?? ''} ${p.product?.name ?? ''}`.toLowerCase().includes(needle))
    }
    if (sort === 'priceAsc') list = [...list].sort((a, b) => a.price - b.price)
    if (sort === 'priceDesc') list = [...list].sort((a, b) => b.price - a.price)
    if (sort === 'name') list = [...list].sort((a, b) => a.name.localeCompare(b.name))
    return list
  }, [catalog, cat, q, sort])

  return (
    <div className="view-enter mt-8">
      <SectionHead title="Browse the catalog" hint="Plans and add-ons available from Brightloop — request any of them from your account manager" />
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="relative min-w-56 flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search plans…" className="pl-9" aria-label="Search plans" />
        </div>
        <Select2 sort={sort} onSort={setSort} />
      </div>
      <div className="mb-6 flex gap-2 overflow-x-auto pb-1 scroll-slim">
        {categories.map((c) => (
          <button key={c} onClick={() => setCat(c)}
            className={cn(
              'whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition-colors',
              cat === c
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground'
            )}>
            {c}
          </button>
        ))}
      </div>
      {shown.length === 0 ? (
        <div className="rounded-3xl border border-dashed bg-card py-14 text-center text-sm text-muted-foreground">
          No plans match your search — try a different keyword or category.
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {shown.map((p) => (
            <CatalogCard key={p.id} plan={p} onOpen={() => onOpen(p)} subscribed={subPlanIds.has(p.id)} />
          ))}
        </div>
      )}
    </div>
  )
}

function CatalogCard({ plan, onOpen, compact = false, subscribed }: { plan: CatalogPlan; onOpen: () => void; compact?: boolean; subscribed?: boolean }) {
  const idx = hashIndex(plan.id, COVERS.length)
  const Icon = COVER_ICONS[(idx + 3) % COVER_ICONS.length]
  const cycle = CYCLE_SHORT[plan.billingCycle] ?? 'cycle'
  return (
    <button onClick={onOpen}
      className="group overflow-hidden rounded-2xl border bg-card text-left shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
      <div className={cn('relative overflow-hidden bg-gradient-to-r text-white', compact ? 'flex h-20 items-center gap-3 px-5' : 'flex h-24 items-center gap-3 px-5', COVERS[idx])}>
        <div aria-hidden="true" className="absolute inset-0">
          <div className="absolute -right-6 -top-8 h-20 w-20 rounded-full bg-white/15" />
          <Icon className="absolute -bottom-3 right-3 h-14 w-14 text-white/20 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6" />
        </div>
        <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/20 ring-1 ring-white/30">
          <Icon className="h-5 w-5" />
        </div>
        <div className="relative min-w-0">
          <p className="truncate font-bold">{plan.name}</p>
          {plan.product?.name ? <p className="truncate text-[11px] text-white/80">{plan.product.name}</p> : null}
        </div>
      </div>
      <div className="p-4">
        <p className="line-clamp-2 min-h-[2.5rem] text-sm text-muted-foreground">
          {plan.description ?? plan.product?.name ?? 'Tailored for your business needs.'}
        </p>
        <div className="mt-3 flex items-center justify-between">
          <p className="font-bold">
            {fmtMoney(plan.price)} <span className="text-xs font-normal text-muted-foreground">/ {cycle}</span>
          </p>
          {subscribed ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10.5px] font-bold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
              <BadgeCheck className="h-3 w-3" /> On this plan
            </span>
          ) : (
            <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-primary opacity-0 transition-opacity group-hover:opacity-100">
              View details <ChevronRight className="h-3.5 w-3.5" />
            </span>
          )}
        </div>
      </div>
    </button>
  )
}

function planFeatures(p: CatalogPlan): string[] {
  const base = (p.description ?? '').split('. ').map((s) => s.trim().replace(/\.$/, '')).filter(Boolean)
  return [
    ...base.slice(0, 2),
    'GST-compliant invoice for every billing cycle',
    'Pay by card, UPI or bank transfer',
    'Pause, change or add plans via your account manager',
  ]
}

function requestMailto(p: CatalogPlan, user: SessionUser) {
  const subject = encodeURIComponent(`Plan request: ${p.name}`)
  const body = encodeURIComponent(
    `Hi team,\n\nI'd like to request the "${p.name}" plan (${fmtMoney(p.price)} / ${CYCLE_SHORT[p.billingCycle] ?? 'cycle'}) for ${user.customerName ?? 'our account'}.\n\nPlease confirm pricing, quantity and the start date.\n\n— ${user.name}`
  )
  return `mailto:accounts@brightloop.com?subject=${subject}&body=${body}`
}

/* ------------------------------------------------------------------ */
/* tab: billing                                                        */
/* ------------------------------------------------------------------ */

function BillingTab({
  invoices, payments, stats, onOpenInvoice,
}: {
  invoices: Invoice[]
  payments: Payment[]
  stats: { outstanding: number; paidLifetime: number; nextBill: string | null; openCount: number }
  onOpenInvoice: (i: Invoice) => void
}) {
  const [filter, setFilter] = useState<'ALL' | 'OPEN' | 'OVERDUE' | 'PAID'>('ALL')
  const today = new Date().toISOString().slice(0, 10)

  const shown = useMemo(() => {
    if (filter === 'OPEN') return invoices.filter((i) => i.status === 'CONFIRMED')
    if (filter === 'OVERDUE') return invoices.filter((i) => i.status === 'CONFIRMED' && i.dueDate.slice(0, 10) < today)
    if (filter === 'PAID') return invoices.filter((i) => i.status === 'PAID')
    return invoices
  }, [invoices, filter, today])

  const CHIPS: { key: typeof filter; label: string }[] = [
    { key: 'ALL', label: `All (${invoices.length})` },
    { key: 'OPEN', label: `Open (${invoices.filter((i) => i.status === 'CONFIRMED').length})` },
    { key: 'OVERDUE', label: `Overdue (${invoices.filter((i) => i.status === 'CONFIRMED' && i.dueDate.slice(0, 10) < today).length})` },
    { key: 'PAID', label: `Paid (${invoices.filter((i) => i.status === 'PAID').length})` },
  ]

  return (
    <div className="view-enter mt-8">
      <SectionHead title="Billing & payments" hint="Invoices, receipts and everything you've paid" />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Tile icon={Wallet} tone={stats.outstanding > 0.005 ? 'amber' : 'emerald'} label="Outstanding" value={fmtMoney(stats.outstanding)} sub={`${stats.openCount} open invoice${stats.openCount === 1 ? '' : 's'}`} />
        <Tile icon={BadgeCheck} tone="emerald" label="Paid lifetime" value={fmtMoney(stats.paidLifetime)} sub={`${payments.length} payment${payments.length === 1 ? '' : 's'} received`} />
        <Tile icon={CalendarClock} tone="teal" label="Next payment" value={stats.nextBill ? fmtDate(stats.nextBill) : '—'} sub={stats.nextBill ? 'from your active plans' : 'nothing scheduled'} />
        <Tile icon={FileText} tone="default" label="Invoices" value={String(invoices.length)} sub="across all plans" />
      </div>

      <div className="mt-8 mb-4 flex gap-2 overflow-x-auto pb-1 scroll-slim">
        {CHIPS.map((c) => (
          <button key={c.key} onClick={() => setFilter(c.key)}
            className={cn(
              'whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition-colors',
              filter === c.key
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground'
            )}>
            {c.label}
          </button>
        ))}
      </div>

      {shown.length === 0 ? (
        <div className="rounded-3xl border border-dashed bg-card py-12 text-center text-sm text-muted-foreground">
          Nothing here — try another filter.
        </div>
      ) : (
        <div className="divide-y overflow-hidden rounded-2xl border bg-card shadow-sm">
          {shown.map((i) => {
            const overdue = i.status === 'CONFIRMED' && i.dueDate.slice(0, 10) < today
            const balance = i.total - i.amountPaid
            const chipTone =
              i.status === 'PAID' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
              : overdue ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
              : i.status === 'CONFIRMED' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
              : 'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300'
            const iconTone =
              i.status === 'PAID' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-300'
              : overdue ? 'bg-rose-100 text-rose-600 dark:bg-rose-950 dark:text-rose-300'
              : 'bg-primary/10 text-primary'
            return (
              <button key={i.id} onClick={() => onOpenInvoice(i)}
                className="flex w-full flex-wrap items-center gap-3 px-4 py-3.5 text-left transition-colors hover:bg-muted/40 sm:px-5">
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${iconTone}`}>
                  <FileText className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold">
                    {i.number}
                    {i.subscription?.plan?.name ? <span className="ml-2 text-xs font-normal text-muted-foreground">{i.subscription.plan.name}</span> : null}
                  </p>
                  <p className="text-xs text-muted-foreground">Issued {fmtDate(i.issueDate)} · Due {fmtDate(i.dueDate)}</p>
                </div>
                <span className={`rounded-full px-2.5 py-0.5 text-[10.5px] font-bold uppercase tracking-wide ${chipTone}`}>
                  {overdue ? 'Overdue' : statusLabel(i.status)}
                </span>
                <div className="text-right">
                  <p className="text-sm font-bold">{fmtMoney(i.total)}</p>
                  {balance > 0.005 && i.status === 'CONFIRMED' ? (
                    <p className="text-[11px] font-semibold text-rose-600 dark:text-rose-400">{fmtMoney(balance)} due</p>
                  ) : null}
                </div>
                <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/50" />
              </button>
            )
          })}
        </div>
      )}

      <div className="mt-10">
        <SectionHead title="Payment receipts" hint="Every payment we've recorded against your account" />
        {payments.length === 0 ? (
          <div className="rounded-3xl border border-dashed bg-card py-12 text-center text-sm text-muted-foreground">
            No payments yet — receipts appear here as soon as your first payment is recorded.
          </div>
        ) : (
          <div className="divide-y overflow-hidden rounded-2xl border bg-card shadow-sm">
            {payments.map((p) => {
              const Icon = METHOD_ICON[p.method] ?? CreditCard
              return (
                <div key={p.id} className="flex flex-wrap items-center gap-3 px-4 py-3.5 sm:px-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold">{p.number} · {METHOD_LABEL[p.method] ?? p.method}</p>
                    <p className="text-xs text-muted-foreground">
                      {fmtDate(p.date)}{p.invoice?.number ? ` · against ${p.invoice.number}` : ''}
                    </p>
                  </div>
                  <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">+{fmtMoney(p.amount)}</p>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* tab: support                                                        */
/* ------------------------------------------------------------------ */

function SupportTab({ goTab, customerName }: { goTab: (t: PortalTab) => void; customerName: string }) {
  const [q, setQ] = useState('')
  const shown = FAQ.filter((f) => `${f.q} ${f.a}`.toLowerCase().includes(q.trim().toLowerCase()))
  return (
    <div className="view-enter mt-8">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-600 via-emerald-600 to-emerald-700 p-7 text-white shadow-xl sm:p-9">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0">
          <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -bottom-24 left-1/3 h-48 w-48 rounded-full bg-emerald-300/15 blur-2xl" />
        </div>
        <div className="relative max-w-xl">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-[10.5px] font-bold uppercase tracking-[0.16em] ring-1 ring-white/25">
            <LifeBuoy className="h-3 w-3" /> Help center
          </span>
          <h1 className="mt-3 text-2xl font-black tracking-tight sm:text-3xl">Hi {firstName(customerName)} — how can we help?</h1>
          <p className="mt-1.5 text-sm text-emerald-50/90">Answers to the questions we hear most, plus direct lines to the team.</p>
          <div className="relative mt-4 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-900/50" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search help articles…"
              aria-label="Search help articles"
              className="w-full rounded-full border-0 bg-white py-2.5 pl-9 pr-4 text-sm text-emerald-950 shadow-lg placeholder:text-emerald-900/40 focus:outline-none focus:ring-2 focus:ring-white/60"
            />
          </div>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><Mail className="h-5 w-5" /></div>
          <p className="mt-3 font-bold">Accounts team</p>
          <p className="mt-1 text-[13px] text-muted-foreground">Plans, invoices and billing changes</p>
          <a href="mailto:accounts@brightloop.com" className="mt-2 inline-block text-[13px] font-semibold text-primary hover:underline">accounts@brightloop.com</a>
        </div>
        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300"><Phone className="h-5 w-5" /></div>
          <p className="mt-3 font-bold">Phone support</p>
          <p className="mt-1 text-[13px] text-muted-foreground">Mon–Fri, 9:30–18:00 IST</p>
          <p className="mt-2 text-[13px] font-semibold text-primary">Response within one business day</p>
        </div>
        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300"><Zap className="h-5 w-5" /></div>
          <p className="mt-3 font-bold">Raise a request</p>
          <p className="mt-1 text-[13px] text-muted-foreground">New plan, pause, renewal or address change</p>
          <a href={`mailto:accounts@brightloop.com?subject=${encodeURIComponent('Support request')}&body=${encodeURIComponent(`Hi team,\n\nAccount: ${customerName}\n\n`)}`}
            className="mt-2 inline-block text-[13px] font-semibold text-primary hover:underline">Write to us</a>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <h2 className="mb-3 text-lg font-bold tracking-tight">Frequently asked questions</h2>
          <Accordion type="single" collapsible className="rounded-2xl border bg-card px-4 shadow-sm">
            {shown.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">No articles match — try a shorter search term.</p>
            ) : (
              shown.map((f, i) => (
                <AccordionItem key={f.q} value={`faq-${i}`}>
                  <AccordionTrigger className="text-left text-sm font-semibold">{f.q}</AccordionTrigger>
                  <AccordionContent className="text-sm leading-relaxed text-muted-foreground">{f.a}</AccordionContent>
                </AccordionItem>
              ))
            )}
          </Accordion>
        </div>
        <div>
          <h2 className="mb-3 text-lg font-bold tracking-tight">Quick links</h2>
          <div className="space-y-3">
            {([
              { icon: Layers, label: 'My plans', desc: 'Progress, pricing and next bills', tab: 'plans' as PortalTab },
              { icon: Wallet, label: 'Billing & payments', desc: 'Invoices, receipts and balances', tab: 'billing' as PortalTab },
              { icon: Compass, label: 'Browse the catalog', desc: 'Available plans and add-ons', tab: 'browse' as PortalTab },
            ]).map((l) => (
              <button key={l.label} onClick={() => goTab(l.tab)}
                className="group flex w-full items-center gap-3.5 rounded-2xl border bg-card p-4 text-left shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <l.icon className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold">{l.label}</p>
                  <p className="truncate text-xs text-muted-foreground">{l.desc}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function firstName(name: string) {
  return name.split(' ')[0]
}

/* ------------------------------------------------------------------ */
/* shared bits                                                         */
/* ------------------------------------------------------------------ */

function FeedRow({ item }: { item: FeedItem }) {
  const style = FEED_STYLE[item.kind]
  const Icon = style.icon
  return (
    <div className="flex items-start gap-3 px-4 py-3">
      <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-xl', style.tone)}>
        <Icon className="h-4.5 w-4.5" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[13.5px] font-semibold">{item.title}</p>
        <p className="text-xs leading-snug text-muted-foreground">{item.body}</p>
      </div>
      <span className="shrink-0 text-[11px] text-muted-foreground">{relTime(item.when)}</span>
    </div>
  )
}

function PlanCard({ sub, onClick }: { sub: Subscription; onClick: () => void }) {
  const idx = hashIndex(sub.id, COVERS.length)
  const Icon = COVER_ICONS[idx]
  const prog = cycleProgress(sub)
  const cycle = sub.plan?.billingCycle
  return (
    <button onClick={onClick}
      className="group block w-full overflow-hidden rounded-2xl border bg-card text-left shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-emerald-900/10">
      <div className={`relative flex h-28 items-center justify-center overflow-hidden bg-gradient-to-br ${COVERS[idx]}`}>
        <div aria-hidden="true" className="absolute inset-0">
          <div className="absolute -right-8 -top-10 h-28 w-28 rounded-full bg-white/15" />
          <div className="absolute -bottom-12 left-6 h-24 w-24 rounded-full bg-black/10" />
          <Icon className="absolute bottom-3 right-4 h-14 w-14 text-white/25 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6" />
        </div>
        <span className="relative text-3xl font-black tracking-tight text-white drop-shadow-md">
          {initialsOf(sub.plan?.name ?? sub.number)}
        </span>
        <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-zinc-800 shadow">
          {statusLabel(sub.status)}
        </span>
        {cycle ? (
          <span className="absolute right-3 top-3 rounded-full bg-black/25 px-2 py-0.5 text-[10px] font-semibold text-white backdrop-blur-sm">
            {CYCLE_LABEL[cycle]}
          </span>
        ) : null}
      </div>
      <div className="p-4">
        <p className="truncate font-bold leading-snug">{sub.plan?.name ?? 'Custom subscription'}</p>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Since {fmtDate(sub.startDate)} · {sub._count?.invoices ?? 0} invoice{(sub._count?.invoices ?? 0) === 1 ? '' : 's'}
        </p>
        {prog ? (
          <div className="mt-3">
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-700"
                style={{ width: `${prog.pct}%` }} />
            </div>
            <p className="mt-1.5 text-[11px] font-medium text-muted-foreground">
              Day {prog.elapsed} of {prog.len} · next bill in {prog.daysLeft} day{prog.daysLeft === 1 ? '' : 's'}
            </p>
          </div>
        ) : null}
        <div className="mt-3 flex items-center justify-between border-t pt-3">
          <p className="font-bold">
            {fmtMoney(subTotal(sub))}
            {cycle ? <span className="text-xs font-normal text-muted-foreground"> / {CYCLE_SHORT[cycle] ?? 'cycle'}</span> : null}
          </p>
          <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-primary opacity-0 transition-opacity duration-200 group-hover:opacity-100">
            Details <ChevronRight className="h-3.5 w-3.5" />
          </span>
        </div>
      </div>
    </button>
  )
}

function SectionHead({ title, hint, action }: { title: string; hint?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
      <div>
        <h2 className="text-xl font-bold tracking-tight">{title}</h2>
        {hint ? <p className="mt-0.5 text-sm text-muted-foreground">{hint}</p> : null}
      </div>
      {action}
    </div>
  )
}

function Tile({
  icon: Icon, label, value, sub, tone = 'emerald',
}: {
  icon: LucideIcon
  label: string
  value: string
  sub?: string
  tone?: 'emerald' | 'teal' | 'amber' | 'rose' | 'default'
}) {
  const tones: Record<string, string> = {
    emerald: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
    teal: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300',
    amber: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
    rose: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300',
    default: 'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300',
  }
  return (
    <div className="flex items-center gap-3.5 rounded-2xl border bg-card p-4 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-md">
      <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${tones[tone]}`}>
        <Icon className="h-5.5 w-5.5" aria-hidden="true" />
      </div>
      <div className="min-w-0">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <p className="truncate text-lg font-bold leading-tight">{value}</p>
        {sub ? <p className="truncate text-[11px] text-muted-foreground">{sub}</p> : null}
      </div>
    </div>
  )
}

function PortalInfo({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border p-3">
      <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-0.5 break-words font-medium">{value}</p>
    </div>
  )
}

function Select2({ sort, onSort }: { sort: string; onSort: (s: 'featured' | 'priceAsc' | 'priceDesc' | 'name') => void }) {
  return (
    <select
      value={sort}
      onChange={(e) => onSort(e.target.value as 'featured' | 'priceAsc' | 'priceDesc' | 'name')}
      aria-label="Sort plans"
      className="h-9 rounded-md border border-input bg-transparent px-3 text-sm shadow-xs outline-none transition-[color,box-shadow] focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
    >
      <option value="featured">Featured</option>
      <option value="priceAsc">Price: low to high</option>
      <option value="priceDesc">Price: high to low</option>
      <option value="name">Name A–Z</option>
    </select>
  )
}
