import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'

export async function GET() {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const templates = await db.quotationTemplate.findMany({
      include: {
        plan: { select: { name: true, billingCycle: true, price: true } },
        lines: { include: { product: { select: { name: true } } }, orderBy: { sortOrder: 'asc' } },
      },
      orderBy: { createdAt: 'asc' },
    })
    return ok({ templates })
  })
}

type LineInput = { productId: string; variantId?: string | null; quantity: number; unitPrice: number; taxRate: number }

export async function POST(req: Request) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    if (!name) throw new ApiError(400, 'Template name is required.')
    const validDays = Math.max(1, Math.floor(Number(body.validDays) || 30))
    const lines: LineInput[] = Array.isArray(body.lines) ? body.lines : []
    if (lines.length === 0) throw new ApiError(400, 'Add at least one product line to the template.')
    for (const l of lines) {
      const product = await db.product.findUnique({ where: { id: l.productId } })
      if (!product) throw new ApiError(400, 'One of the template lines points to a missing product.')
    }
    if (body.planId) {
      const plan = await db.plan.findUnique({ where: { id: body.planId } })
      if (!plan) throw new ApiError(400, 'Linked plan not found.')
    }
    const template = await db.quotationTemplate.create({
      data: {
        name,
        description: body.description || null,
        planId: body.planId || null,
        validDays,
        lines: {
          create: lines.map((l, i) => ({
            productId: l.productId,
            variantId: l.variantId || null,
            quantity: Math.max(1, Number(l.quantity) || 1),
            unitPrice: Math.max(0, Number(l.unitPrice) || 0),
            taxRate: Math.max(0, Number(l.taxRate) || 0),
            sortOrder: i,
          })),
        },
      },
      include: {
        plan: { select: { name: true, billingCycle: true, price: true } },
        lines: { include: { product: { select: { name: true } } }, orderBy: { sortOrder: 'asc' } },
      },
    })
    return ok({ template }, 201)
  })
}
