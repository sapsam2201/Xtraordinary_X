import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin, requireRole } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const template = await db.quotationTemplate.findUnique({
      where: { id },
      include: {
        plan: true,
        lines: { include: { product: { include: { variants: true } } }, orderBy: { sortOrder: 'asc' } },
      },
    })
    if (!template) throw new ApiError(404, 'Template not found.')
    return ok({ template })
  })
}

export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    await db.quotationTemplate.delete({ where: { id } })
    return ok({ success: true })
  })
}
