import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    const body = await req.json()
    const existing = await db.discountRule.findUnique({ where: { id } })
    if (!existing) throw new ApiError(404, 'Discount rule not found.')
    const data: Record<string, unknown> = {}
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
    if (typeof body.active === 'boolean') data.active = body.active
    if (body.value !== undefined) {
      const v = Number(body.value)
      if (!Number.isFinite(v) || v <= 0) throw new ApiError(400, 'Discount value must be positive.')
      data.value = v
    }
    if ('endDate' in body && body.endDate) {
      const d = new Date(String(body.endDate))
      if (Number.isNaN(d.getTime())) throw new ApiError(400, 'Invalid end date.')
      data.endDate = d
    }
    const discount = await db.discountRule.update({ where: { id }, data, include: { product: { select: { name: true } } } })
    return ok({ discount })
  })
}

export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    await db.discountRule.delete({ where: { id } })
    return ok({ success: true })
  })
}
