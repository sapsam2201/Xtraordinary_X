import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin, requireRole } from '@/lib/auth'

export async function GET() {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const discounts = await db.discountRule.findMany({
      include: { product: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
    })
    return ok({ discounts })
  })
}

export async function POST(req: Request) {
  return handle(async () => {
    // Only the admin can create discount rules
    await requireAdmin()
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    if (!name) throw new ApiError(400, 'Discount name is required.')
    const type = body.type === 'FIXED' ? 'FIXED' : 'PERCENTAGE'
    const value = Number(body.value)
    if (!Number.isFinite(value) || value <= 0) throw new ApiError(400, 'Discount value must be positive.')
    if (type === 'PERCENTAGE' && value > 100) throw new ApiError(400, 'A percentage discount cannot exceed 100%.')
    const scope = body.scope === 'PRODUCT' ? 'PRODUCT' : 'SUBSCRIPTION'
    if (scope === 'PRODUCT' && !body.productId) {
      throw new ApiError(400, 'Product-scope discounts need a product.')
    }
    if (scope === 'PRODUCT') {
      const product = await db.product.findUnique({ where: { id: body.productId } })
      if (!product) throw new ApiError(400, 'Selected product not found.')
    }
    const startDate = new Date(String(body.startDate))
    const endDate = new Date(String(body.endDate))
    if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) {
      throw new ApiError(400, 'Start and end dates are required.')
    }
    if (endDate < startDate) throw new ApiError(400, 'The discount cannot end before it starts.')

    const discount = await db.discountRule.create({
      data: {
        name,
        type,
        value,
        scope,
        productId: scope === 'PRODUCT' ? body.productId : null,
        minPurchase: body.minPurchase != null && body.minPurchase !== '' ? Number(body.minPurchase) : null,
        minQuantity: body.minQuantity != null && body.minQuantity !== '' ? Math.max(1, Math.floor(Number(body.minQuantity))) : null,
        startDate,
        endDate,
        maxUses: body.maxUses != null && body.maxUses !== '' ? Math.max(1, Math.floor(Number(body.maxUses))) : null,
      },
      include: { product: { select: { name: true } } },
    })
    return ok({ discount }, 201)
  })
}
