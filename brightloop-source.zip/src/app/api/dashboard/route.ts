import { db } from '@/lib/db'
import { handle, ok, requireRole } from '@/lib/auth'
import { monthlyNormalized, r2, type Cycle } from '@/lib/billing'
import { startOfDay } from '@/lib/invoice-service'

export async function GET(req: Request) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { searchParams } = new URL(req.url)
    const period = searchParams.get('period') ?? 'this_month'
    const today = startOfDay(new Date())

    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1)
    const prevStart = new Date(today.getFullYear(), today.getMonth() - 1, 1)
    const quarterStart = new Date(today.getFullYear(), Math.floor(today.getMonth() / 3) * 3, 1)
    const yearStart = new Date(today.getFullYear(), 0, 1)
    const rangeStart =
      period === 'this_month' ? monthStart
      : period === 'last_month' ? prevStart
      : period === 'quarter' ? quarterStart
      : period === 'year' ? yearStart
      : null
    const rangeEnd =
      period === 'this_month' ? today
      : period === 'last_month' ? new Date(today.getFullYear(), today.getMonth(), 0)
      : today

    const paymentDateFilter = rangeStart
      ? { date: { gte: rangeStart, lte: rangeEnd } }
      : {}

    const [activeSubs, customerCount, payments, invoicesAgg, invoiceStatuses, subStatuses, activeWithLines, recentInvoices, overdueInvoices, upcomingRenewals] = await Promise.all([
      db.subscription.count({ where: { status: 'ACTIVE' } }),
      db.customer.count(),
      db.payment.findMany({
        where: paymentDateFilter,
        select: { amount: true, date: true },
      }),
      db.invoice.aggregate({
        where: { status: 'CONFIRMED' },
        _sum: { total: true, amountPaid: true },
        _count: true,
      }),
      db.invoice.groupBy({ by: ['status'], _count: true, _sum: { total: true, amountPaid: true } }),
      db.subscription.groupBy({ by: ['status'], _count: true }),
      db.subscription.findMany({
        where: { status: 'ACTIVE' },
        select: { lines: { select: { quantity: true, unitPrice: true } }, plan: { select: { billingCycle: true } } },
      }),
      db.invoice.findMany({
        take: 8,
        orderBy: { createdAt: 'desc' },
        include: { customer: { select: { name: true } } },
      }),
      db.invoice.findMany({
        where: { status: 'CONFIRMED', dueDate: { lt: today } },
        orderBy: { dueDate: 'asc' },
        take: 8,
        include: { customer: { select: { name: true } } },
      }),
      db.subscription.findMany({
        where: {
          status: 'ACTIVE',
          expiryDate: { gte: today, lte: new Date(today.getTime() + 30 * 86400000) },
        },
        take: 8,
        include: { customer: { select: { name: true } }, plan: { select: { name: true, canRenew: true } } },
      }),
    ])

    const mrr = r2(
      activeWithLines.reduce((sum, sub) => {
        const cycle = (sub.plan?.billingCycle ?? 'MONTHLY') as Cycle
        return sum + sub.lines.reduce((s, l) => s + monthlyNormalized(l.quantity * l.unitPrice, cycle), 0)
      }, 0)
    )

    // revenue trend: last 6 complete months + current month
    const months: { key: string; label: string; start: Date; end: Date }[] = []
    for (let i = 5; i >= 0; i--) {
      const start = new Date(today.getFullYear(), today.getMonth() - i, 1)
      const end = new Date(today.getFullYear(), today.getMonth() - i + 1, 0)
      months.push({
        key: `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, '0')}`,
        label: start.toLocaleString('en', { month: 'short' }),
        start, end,
      })
    }
    const allPayments = await db.payment.findMany({ select: { amount: true, date: true } })
    const revenueByMonth = months.map((m) => ({
      month: m.label,
      revenue: r2(
        allPayments.filter((p) => p.date >= m.start && p.date <= m.end).reduce((s, p) => s + p.amount, 0)
      ),
    }))

    const revenueInPeriod = r2(payments.reduce((s, p) => s + p.amount, 0))
    const prevMonthPayments = await db.payment.aggregate({
      where: { date: { gte: prevStart, lt: monthStart } },
      _sum: { amount: true },
    })

    const outstandingTotal = r2((invoicesAgg._sum.total ?? 0) - (invoicesAgg._sum.amountPaid ?? 0))
    const overdueTotal = r2(overdueInvoices.reduce((s, i) => s + (i.total - i.amountPaid), 0))
    const overdueAll = await db.invoice.aggregate({
      where: { status: 'CONFIRMED', dueDate: { lt: today } },
      _count: true,
      _sum: { total: true, amountPaid: true },
    })

    const plans = await db.plan.findMany({
      select: { name: true, _count: { select: { subscriptions: { where: { status: 'ACTIVE' } } } } },
    })
    const subsByPlan = plans
      .map((p) => ({ plan: p.name, count: p._count.subscriptions }))
      .filter((p) => p.count > 0)
      .sort((a, b) => b.count - a.count)

    return ok({
      kpis: {
        activeSubscriptions: activeSubs,
        customers: customerCount,
        mrr,
        revenueInPeriod,
        revenueThisMonth: r2(allPayments.filter((p) => p.date >= monthStart).reduce((s, p) => s + p.amount, 0)),
        revenuePrevMonth: r2(prevMonthPayments._sum.amount ?? 0),
        outstandingTotal,
        openInvoices: invoicesAgg._count,
        overdueCount: overdueAll._count,
        overdueAmount: r2((overdueAll._sum.total ?? 0) - (overdueAll._sum.amountPaid ?? 0)),
      },
      invoicesByStatus: invoiceStatuses.map((s) => ({ status: s.status, count: s._count, total: r2(s._sum.total ?? 0) })),
      subscriptionsByStatus: subStatuses.map((s) => ({ status: s.status, count: s._count })),
      subsByPlan,
      revenueByMonth,
      recentInvoices: recentInvoices.map((i) => ({
        id: i.id, number: i.number, customer: i.customer.name, status: i.status,
        total: i.total, amountPaid: i.amountPaid, issueDate: i.issueDate, dueDate: i.dueDate,
      })),
      overdueList: overdueInvoices.map((i) => ({
        id: i.id, number: i.number, customer: i.customer.name, total: i.total,
        amountPaid: i.amountPaid, dueDate: i.dueDate,
        daysOverdue: Math.max(0, Math.floor((today.getTime() - i.dueDate.getTime()) / 86400000)),
      })),
      upcomingRenewals: upcomingRenewals.map((s) => ({
        id: s.id, number: s.number, customer: s.customer.name, plan: s.plan?.name ?? '—',
        expiryDate: s.expiryDate, canRenew: s.plan?.canRenew ?? false,
      })),
    })
  })
}
