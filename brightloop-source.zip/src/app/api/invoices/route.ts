import { db } from '@/lib/db'
import { handle, ok, requireRole } from '@/lib/auth'

export async function GET(req: Request) {
  return handle(async () => {
    const me = await requireRole('ADMIN', 'STAFF', 'CUSTOMER')
    const { searchParams } = new URL(req.url)
    const status = searchParams.get('status')
    const q = searchParams.get('q')?.trim()
    const customerId = searchParams.get('customerId')
    const from = searchParams.get('from')
    const to = searchParams.get('to')

    const where: Record<string, unknown> = {}
    if (me.role === 'CUSTOMER') {
      where.customerId = me.customerId
    } else if (customerId) {
      where.customerId = customerId
    }
    if (status && status !== 'ALL') where.status = status
    if (from || to) {
      where.issueDate = {
        ...(from ? { gte: new Date(String(from)) } : {}),
        ...(to ? { lte: new Date(String(to)) } : {}),
      }
    }
    if (q) {
      where.OR = [{ number: { contains: q } }, { customer: { is: { name: { contains: q } } } }]
    }

    const invoices = await db.invoice.findMany({
      where,
      include: {
        customer: { select: { id: true, name: true } },
        subscription: { select: { id: true, number: true } },
        _count: { select: { payments: true } },
      },
      orderBy: [{ issueDate: 'desc' }, { number: 'desc' }],
      take: 1000,
    })
    return ok({ invoices })
  })
}
