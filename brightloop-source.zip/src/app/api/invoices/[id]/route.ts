import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const me = await requireRole('ADMIN', 'STAFF', 'CUSTOMER')
    const { id } = await ctx.params
    const invoice = await db.invoice.findUnique({
      where: { id },
      include: {
        customer: true,
        subscription: { include: { plan: { select: { name: true } } } },
        lines: { orderBy: { sortOrder: 'asc' } },
        payments: { orderBy: { date: 'asc' } },
      },
    })
    if (!invoice) throw new ApiError(404, 'Invoice not found.')
    if (me.role === 'CUSTOMER' && invoice.customerId !== me.customerId) {
      throw new ApiError(403, 'You can only view your own invoices.')
    }
    return ok({ invoice })
  })
}
