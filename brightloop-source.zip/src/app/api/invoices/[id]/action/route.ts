import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }

/**
 * Invoice actions:
 *   confirm — DRAFT → CONFIRMED (numbers locked, becomes collectable)
 *   send    — mark as emailed to the customer (simulated delivery)
 *   cancel  — only possible while nothing has been paid
 */
export async function POST(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const body = await req.json()
    const action = String(body.action ?? '')

    const invoice = await db.invoice.findUnique({ where: { id } })
    if (!invoice) throw new ApiError(404, 'Invoice not found.')

    switch (action) {
      case 'confirm': {
        if (invoice.status !== 'DRAFT') throw new ApiError(400, 'Only draft invoices can be confirmed.')
        await db.invoice.update({ where: { id }, data: { status: 'CONFIRMED' } })
        break
      }
      case 'send': {
        if (invoice.status === 'CANCELLED') throw new ApiError(400, 'This invoice was cancelled.')
        if (invoice.status === 'DRAFT') throw new ApiError(400, 'Confirm the invoice before sending it.')
        await db.invoice.update({ where: { id }, data: { sentAt: new Date() } })
        break
      }
      case 'cancel': {
        if (invoice.status === 'PAID') throw new ApiError(400, 'A paid invoice cannot be cancelled.')
        if (invoice.status === 'CANCELLED') throw new ApiError(400, 'This invoice is already cancelled.')
        if (invoice.amountPaid > 0) throw new ApiError(400, 'Payments exist against this invoice; refund them first.')
        await db.invoice.update({ where: { id }, data: { status: 'CANCELLED' } })
        break
      }
      default:
        throw new ApiError(400, `Unknown action "${action}".`)
    }

    const updated = await db.invoice.findUnique({
      where: { id },
      include: {
        customer: true,
        lines: { orderBy: { sortOrder: 'asc' } },
        payments: { orderBy: { date: 'asc' } },
      },
    })
    return ok({ invoice: updated })
  })
}
