import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const customer = await db.customer.findUnique({
      where: { id },
      include: {
        subscriptions: { include: { plan: { select: { name: true, billingCycle: true } } }, orderBy: { createdAt: 'desc' } },
        invoices: { orderBy: { issueDate: 'desc' }, take: 20 },
        _count: { select: { subscriptions: true, invoices: true, payments: true } },
      },
    })
    if (!customer) throw new ApiError(404, 'Customer not found.')
    return ok({ customer })
  })
}

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const body = await req.json()
    const data: Record<string, string | null> = {}
    for (const key of ['name', 'email', 'phone', 'company', 'address', 'city', 'country', 'taxId', 'notes']) {
      if (key in body) data[key] = body[key] || null
    }
    if (data.email) {
      const dup = await db.customer.findFirst({ where: { email: data.email, id: { not: id } } })
      if (dup) throw new ApiError(409, 'Another customer already uses this email.')
    }
    const customer = await db.customer.update({ where: { id }, data })
    return ok({ customer })
  })
}

export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const count = await db.subscription.count({ where: { customerId: id } })
    if (count > 0) {
      throw new ApiError(400, 'This customer has subscriptions and cannot be deleted.')
    }
    await db.customer.delete({ where: { id } })
    return ok({ success: true })
  })
}
