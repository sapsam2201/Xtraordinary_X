import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'
import { validateEmail } from '@/lib/password'

export async function GET(req: Request) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { searchParams } = new URL(req.url)
    const q = searchParams.get('q')?.trim()
    const customers = await db.customer.findMany({
      where: q
        ? {
            OR: [
              { name: { contains: q } },
              { email: { contains: q } },
              { city: { contains: q } },
            ],
          }
        : undefined,
      include: { _count: { select: { subscriptions: true, invoices: true } } },
      orderBy: { name: 'asc' },
      take: 500,
    })
    return ok({ customers })
  })
}

export async function POST(req: Request) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    const email = String(body.email ?? '').trim().toLowerCase()
    if (!name) throw new ApiError(400, 'Customer name is required.')
    if (!validateEmail(email)) throw new ApiError(400, 'Please enter a valid email address.')
    const existing = await db.customer.findUnique({ where: { email } })
    if (existing) throw new ApiError(409, 'A customer with this email already exists.')
    const customer = await db.customer.create({
      data: {
        name,
        email,
        phone: body.phone || null,
        company: body.company || null,
        address: body.address || null,
        city: body.city || null,
        country: body.country || null,
        taxId: body.taxId || null,
        notes: body.notes || null,
      },
    })
    return ok({ customer }, 201)
  })
}
