import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin } from '@/lib/auth'

const CYCLES = ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']

type Ctx = { params: Promise<{ id: string }> }

function parseDate(v: unknown): Date | null {
  if (!v) return null
  const d = new Date(String(v))
  return Number.isNaN(d.getTime()) ? null : d
}

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    const body = await req.json()
    const plan = await db.plan.findUnique({ where: { id } })
    if (!plan) throw new ApiError(404, 'Plan not found.')

    const data: Record<string, unknown> = {}
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
    if ('description' in body) data.description = body.description || null
    if ('productId' in body) data.productId = body.productId || null
    if (body.price !== undefined) {
      const v = Number(body.price)
      if (!Number.isFinite(v) || v < 0) throw new ApiError(400, 'Plan price must be a positive number.')
      data.price = v
    }
    if (body.billingCycle && CYCLES.includes(body.billingCycle)) data.billingCycle = body.billingCycle
    if (body.minQuantity !== undefined) data.minQuantity = Math.max(1, Math.floor(Number(body.minQuantity) || 1))
    if ('availableFrom' in body) data.availableFrom = parseDate(body.availableFrom)
    if ('availableTo' in body) data.availableTo = parseDate(body.availableTo)
    for (const flag of ['autoClose', 'canCloseEarly', 'canPause', 'canRenew', 'active'] as const) {
      if (typeof body[flag] === 'boolean') data[flag] = body[flag]
    }
    const updated = await db.plan.update({ where: { id }, data, include: { product: { select: { name: true } } } })
    return ok({ plan: updated })
  })
}

export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    const used = await db.subscription.count({ where: { planId: id } })
    if (used > 0) {
      const plan = await db.plan.update({ where: { id }, data: { active: false } })
      return ok({ plan, archived: true })
    }
    await db.plan.delete({ where: { id } })
    return ok({ success: true })
  })
}
