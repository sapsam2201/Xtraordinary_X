import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin, requireRole } from '@/lib/auth'

const CYCLES = ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']

function parseDate(v: unknown): Date | null {
  if (!v) return null
  const d = new Date(String(v))
  return Number.isNaN(d.getTime()) ? null : d
}

export async function GET() {
  return handle(async () => {
    const user = await requireRole('ADMIN', 'STAFF', 'CUSTOMER')
    const plans = await db.plan.findMany({
      include: { product: { select: { name: true } }, _count: { select: { subscriptions: true } } },
      orderBy: { createdAt: 'asc' },
    })
    if (user.role === 'CUSTOMER') {
      // Catalog view for the customer portal: active plans only, public fields.
      return ok({
        plans: plans
          .filter((p) => p.active)
          .map((p) => ({
            id: p.id,
            name: p.name,
            description: p.description,
            product: p.product,
            price: p.price,
            billingCycle: p.billingCycle,
          })),
      })
    }
    return ok({ plans })
  })
}

export async function POST(req: Request) {
  return handle(async () => {
    await requireAdmin()
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    if (!name) throw new ApiError(400, 'Plan name is required.')
    const price = Number(body.price)
    if (!Number.isFinite(price) || price < 0) throw new ApiError(400, 'Plan price must be a positive number.')
    if (!CYCLES.includes(body.billingCycle)) throw new ApiError(400, 'Billing cycle must be daily, weekly, monthly or yearly.')
    const minQuantity = Math.max(1, Math.floor(Number(body.minQuantity) || 1))
    if (body.productId) {
      const product = await db.product.findUnique({ where: { id: body.productId } })
      if (!product) throw new ApiError(400, 'Linked product not found.')
    }
    const availableFrom = parseDate(body.availableFrom)
    const availableTo = parseDate(body.availableTo)
    if (availableFrom && availableTo && availableTo < availableFrom) {
      throw new ApiError(400, 'The plan cannot end before it starts.')
    }
    const plan = await db.plan.create({
      data: {
        name,
        description: body.description || null,
        productId: body.productId || null,
        price,
        billingCycle: body.billingCycle,
        minQuantity,
        availableFrom,
        availableTo,
        autoClose: !!body.autoClose,
        canCloseEarly: !!body.canCloseEarly,
        canPause: !!body.canPause,
        canRenew: !!body.canRenew,
      },
      include: { product: { select: { name: true } } },
    })
    return ok({ plan }, 201)
  })
}
