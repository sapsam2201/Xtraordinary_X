import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin, requireRole } from '@/lib/auth'
import { validateEmail, validatePasswordPolicy } from '@/lib/password'
import { hashPassword } from '@/lib/password'

export async function GET() {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const users = await db.user.findMany({
      select: {
        id: true, email: true, name: true, role: true, isActive: true,
        createdAt: true, customerId: true,
        customer: { select: { name: true } },
      },
      orderBy: { createdAt: 'desc' },
    })
    return ok({ users })
  })
}

export async function POST(req: Request) {
  return handle(async () => {
    // Only the admin can add a new member of staff
    await requireAdmin()
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    const email = String(body.email ?? '').trim().toLowerCase()
    const password = String(body.password ?? '')
    const role = body.role === 'ADMIN' ? 'ADMIN' : 'STAFF'

    if (!name) throw new ApiError(400, 'Name is required.')
    if (!validateEmail(email)) throw new ApiError(400, 'Please enter a valid email address.')
    const pwError = validatePasswordPolicy(password)
    if (pwError) throw new ApiError(400, pwError)

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) throw new ApiError(409, 'This email already belongs to an account.')

    const user = await db.user.create({
      data: { name, email, role, passwordHash: hashPassword(password) },
      select: { id: true, email: true, name: true, role: true, isActive: true, createdAt: true },
    })
    return ok({ user }, 201)
  })
}
