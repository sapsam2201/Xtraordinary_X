import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    const body = await req.json()
    const user = await db.user.findUnique({ where: { id } })
    if (!user) throw new ApiError(404, 'User not found.')

    const data: { isActive?: boolean; name?: string } = {}
    if (typeof body.isActive === 'boolean') {
      if (user.id === body.requesterId && !body.isActive) {
        throw new ApiError(400, 'You cannot deactivate your own account.')
      }
      data.isActive = body.isActive
    }
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()

    const updated = await db.user.update({
      where: { id },
      data,
      select: { id: true, email: true, name: true, role: true, isActive: true, createdAt: true },
    })
    return ok({ user: updated })
  })
}

export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const admin = await requireAdmin()
    const { id } = await ctx.params
    if (id === admin.id) throw new ApiError(400, 'You cannot remove your own account.')
    const user = await db.user.findUnique({ where: { id } })
    if (!user) throw new ApiError(404, 'User not found.')
    await db.user.delete({ where: { id } })
    return ok({ success: true })
  })
}
