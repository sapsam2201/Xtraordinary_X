import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    const body = await req.json()
    const data: Record<string, unknown> = {}
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
    if (body.rate !== undefined) {
      const v = Number(body.rate)
      if (!Number.isFinite(v) || v < 0 || v > 100) throw new ApiError(400, 'Rate must be between 0 and 100.')
      data.rate = v
    }
    if (typeof body.active === 'boolean') data.active = body.active
    const taxRule = await db.taxRule.update({ where: { id }, data })
    return ok({ taxRule })
  })
}

export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    await db.taxRule.delete({ where: { id } })
    return ok({ success: true })
  })
}
