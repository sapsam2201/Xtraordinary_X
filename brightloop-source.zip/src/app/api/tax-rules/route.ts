import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin, requireRole } from '@/lib/auth'

export async function GET() {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const taxRules = await db.taxRule.findMany({ orderBy: { rate: 'desc' } })
    return ok({ taxRules })
  })
}

export async function POST(req: Request) {
  return handle(async () => {
    await requireAdmin()
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    if (!name) throw new ApiError(400, 'Tax rule name is required.')
    const rate = Number(body.rate)
    if (!Number.isFinite(rate) || rate < 0 || rate > 100) throw new ApiError(400, 'Rate must be between 0 and 100.')
    const taxRule = await db.taxRule.create({ data: { name, rate } })
    return ok({ taxRule }, 201)
  })
}
