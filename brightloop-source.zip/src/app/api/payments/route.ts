import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'
import { recordPayment } from '@/lib/invoice-service'

const METHODS = ['CARD', 'BANK_TRANSFER', 'UPI', 'CASH', 'CHEQUE']

export async function GET(req: Request) {
  return handle(async () => {
    const me = await requireRole('ADMIN', 'STAFF', 'CUSTOMER')
    const { searchParams } = new URL(req.url)
    const method = searchParams.get('method')
    const q = searchParams.get('q')?.trim()
    const from = searchParams.get('from')
    const to = searchParams.get('to')

    const where: Record<string, unknown> = {}
    if (me.role === 'CUSTOMER') {
      where.customerId = me.customerId
    }
    if (method && method !== 'ALL') where.method = method
    if (from || to) {
      where.date = {
        ...(from ? { gte: new Date(String(from)) } : {}),
        ...(to ? { lte: new Date(String(to)) } : {}),
      }
    }
    if (q) {
      where.OR = [
        { number: { contains: q } },
        { invoice: { is: { number: { contains: q } } } },
        { customer: { is: { name: { contains: q } } } },
      ]
    }

    const payments = await db.payment.findMany({
      where,
      include: {
        invoice: { select: { id: true, number: true, total: true } },
        customer: { select: { id: true, name: true } },
      },
      orderBy: { date: 'desc' },
      take: 1000,
    })
    return ok({ payments })
  })
}

export async function POST(req: Request) {
  return handle(async () => {
    const me = await requireRole('ADMIN', 'STAFF', 'CUSTOMER')
    const body = await req.json()
    const invoiceId = String(body.invoiceId ?? '')
    const method = METHODS.includes(body.method) ? body.method : null
    const amount = Number(body.amount)
    if (!invoiceId) throw new ApiError(400, 'Choose the invoice this payment belongs to.')
    if (!method) throw new ApiError(400, 'Choose a payment method.')
    if (!Number.isFinite(amount) || amount <= 0) throw new ApiError(400, 'Payment amount must be a positive number.')

    if (me.role === 'CUSTOMER') {
      const invoice = await db.invoice.findUnique({ where: { id: invoiceId } })
      if (!invoice || invoice.customerId !== me.customerId) {
        throw new ApiError(403, 'You can only pay your own invoices.')
      }
    }

    const result = await recordPayment({
      invoiceId,
      method,
      amount,
      date: body.date ? new Date(String(body.date)) : undefined,
      note: body.note || null,
    })
    return ok(result, 201)
  })
}
