import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'
import { PAYMENT_TERMS_DAYS, type PaymentTerms } from '@/lib/billing'
import { nextNumber } from '@/lib/invoice-service'

function parseDate(v: unknown, fallback?: Date): Date {
  if (v) {
    const d = new Date(String(v))
    if (!Number.isNaN(d.getTime())) return d
  }
  if (fallback) return fallback
  throw new ApiError(400, 'A valid date is required.')
}

export async function GET(req: Request) {
  return handle(async () => {
    const me = await requireRole('ADMIN', 'STAFF', 'CUSTOMER')
    const { searchParams } = new URL(req.url)
    const status = searchParams.get('status')
    const q = searchParams.get('q')?.trim()
    const customerId = searchParams.get('customerId')

    const where: Record<string, unknown> = {}
    if (me.role === 'CUSTOMER') {
      where.customerId = me.customerId
    } else if (customerId) {
      where.customerId = customerId
    }
    if (status && status !== 'ALL') where.status = status
    if (q) {
      where.OR = [{ number: { contains: q } }, { customer: { is: { name: { contains: q } } } }]
    }

    const subscriptions = await db.subscription.findMany({
      where,
      include: {
        customer: { select: { id: true, name: true, email: true } },
        plan: { select: { id: true, name: true, billingCycle: true, canPause: true, canRenew: true, canCloseEarly: true, autoClose: true } },
        lines: { orderBy: { sortOrder: 'asc' } },
        _count: { select: { invoices: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 1000,
    })
    return ok({ subscriptions })
  })
}

export async function POST(req: Request) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const body = await req.json()

    const customerId = String(body.customerId ?? '')
    const customer = await db.customer.findUnique({ where: { id: customerId } })
    if (!customer) throw new ApiError(400, 'Please choose a customer.')

    let plan = null
    if (body.planId) {
      plan = await db.plan.findUnique({ where: { id: body.planId } })
      if (!plan) throw new ApiError(400, 'Selected plan not found.')
      if (!plan.active) throw new ApiError(400, 'This plan is no longer available.')
      const now = new Date()
      if (plan.availableFrom && now < plan.availableFrom) throw new ApiError(400, 'This plan is not available yet.')
      if (plan.availableTo && now > plan.availableTo) throw new ApiError(400, 'This plan is no longer available.')
    }

    const lines = Array.isArray(body.lines) ? body.lines : []
    if (lines.length === 0) throw new ApiError(400, 'Add at least one product line.')
    if (plan && lines.length > 0) {
      const totalQty = lines.reduce((s: number, l: { quantity: unknown }) => s + (Number(l.quantity) || 0), 0)
      if (totalQty < plan.minQuantity) {
        throw new ApiError(400, `The ${plan.name} plan requires at least ${plan.minQuantity} unit(s) in total.`)
      }
    }

    const paymentTerms: PaymentTerms = PAYMENT_TERMS_DAYS[body.paymentTerms as PaymentTerms] !== undefined
      ? body.paymentTerms
      : 'DUE_ON_RECEIPT'
    const startDate = parseDate(body.startDate, new Date())
    const expiryDate = body.expiryDate ? parseDate(body.expiryDate) : null
    if (expiryDate && expiryDate < startDate) throw new ApiError(400, 'Expiry date cannot be before the start date.')

    for (const l of lines as { productId: string }[]) {
      const product = await db.product.findUnique({ where: { id: l.productId } })
      if (!product) throw new ApiError(400, 'One of the lines points to a missing product.')
    }

    const sub = await db.$transaction(async (tx) => {
      const subNumber = await nextNumber(tx, 'SUB', 'SUB')
      return tx.subscription.create({
        data: {
          number: subNumber,
          customerId,
          planId: body.planId || null,
          status: 'DRAFT',
          startDate,
          expiryDate,
          paymentTerms,
          nextBillingDate: null,
          notes: body.notes || null,
          lines: {
            create: lines.map((l: { productId: string; variantId?: string | null; description?: string; quantity: number; unitPrice: number; taxRate: number }, i: number) => ({
              productId: l.productId,
              variantId: l.variantId || null,
              description: l.description || null,
              quantity: Math.max(1, Number(l.quantity) || 1),
              unitPrice: Math.max(0, Number(l.unitPrice) || 0),
              taxRate: Math.max(0, Number(l.taxRate) || 0),
              sortOrder: i,
            })),
          },
        },
        include: {
          customer: { select: { id: true, name: true, email: true } },
          plan: true,
          lines: { orderBy: { sortOrder: 'asc' } },
        },
      })
    })
    return ok({ subscription: sub }, 201)
  })
}
