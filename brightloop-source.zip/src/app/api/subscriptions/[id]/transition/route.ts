import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'
import { addCycle, type Cycle } from '@/lib/billing'
import { startOfDay } from '@/lib/invoice-service'

type Ctx = { params: Promise<{ id: string }> }

const FLOW: Record<string, string[]> = {
  DRAFT: ['QUOTATION'],
  QUOTATION: ['CONFIRMED'],
  CONFIRMED: ['ACTIVE'],
}

/**
 * Lifecycle actions on a subscription:
 *   send_quote  DRAFT → QUOTATION
 *   confirm     QUOTATION → CONFIRMED
 *   activate    CONFIRMED → ACTIVE   (starts billing)
 *   close       → CLOSED             (respects the plan's canCloseEarly)
 *   pause       ACTIVE → PAUSED      (respects the plan's canPause)
 *   resume      PAUSED → ACTIVE
 *   renew       CLOSED/ACTIVE → new subscription (respects the plan's canRenew)
 */
export async function POST(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const body = await req.json()
    const action = String(body.action ?? '')

    const sub = await db.subscription.findUnique({
      where: { id },
      include: { plan: true, lines: true },
    })
    if (!sub) throw new ApiError(404, 'Subscription not found.')
    const today = startOfDay(new Date())

    switch (action) {
      case 'send_quote': {
        if (!FLOW.DRAFT.includes('QUOTATION') || sub.status !== 'DRAFT') {
          throw new ApiError(400, 'Only draft subscriptions can be sent as a quotation.')
        }
        await db.subscription.update({ where: { id }, data: { status: 'QUOTATION' } })
        break
      }
      case 'confirm': {
        if (sub.status !== 'QUOTATION') throw new ApiError(400, 'Only quotations can be confirmed.')
        await db.subscription.update({ where: { id }, data: { status: 'CONFIRMED' } })
        break
      }
      case 'activate': {
        if (sub.status !== 'CONFIRMED') throw new ApiError(400, 'Confirm the quotation before activating.')
        const start = startOfDay(sub.startDate)
        const nextBilling = sub.plan ? addCycle(start < today ? today : start, sub.plan.billingCycle as Cycle) : null
        // first billing date: one cycle after activation
        const firstBilling = start < today ? nextBilling : start
        await db.subscription.update({
          where: { id },
          data: { status: 'ACTIVE', nextBillingDate: firstBilling },
        })
        break
      }
      case 'close': {
        if (sub.status === 'CLOSED') throw new ApiError(400, 'This subscription is already closed.')
        if (sub.status === 'DRAFT' || sub.status === 'QUOTATION') {
          await db.subscription.update({
            where: { id },
            data: { status: 'CLOSED', closedAt: new Date(), closeReason: String(body.reason ?? 'Cancelled before activation') },
          })
          break
        }
        if (sub.plan && !sub.plan.canCloseEarly && sub.status === 'ACTIVE') {
          throw new ApiError(400, `The ${sub.plan.name} plan does not allow closing early.`)
        }
        await db.subscription.update({
          where: { id },
          data: { status: 'CLOSED', closedAt: new Date(), closeReason: String(body.reason ?? 'Closed by staff') },
        })
        break
      }
      case 'pause': {
        if (sub.status !== 'ACTIVE') throw new ApiError(400, 'Only active subscriptions can be paused.')
        if (sub.plan && !sub.plan.canPause) throw new ApiError(400, `The ${sub.plan.name} plan cannot be paused.`)
        await db.subscription.update({ where: { id }, data: { status: 'PAUSED' } })
        break
      }
      case 'resume': {
        if (sub.status !== 'PAUSED') throw new ApiError(400, 'This subscription is not paused.')
        // billing restarts from today: the paused period is not charged
        const nextBilling = sub.plan ? addCycle(today, sub.plan.billingCycle as Cycle) : null
        await db.subscription.update({ where: { id }, data: { status: 'ACTIVE', nextBillingDate: today < startOfDay(sub.startDate) ? sub.nextBillingDate : today } })
        void nextBilling
        break
      }
      case 'renew': {
        if (sub.plan && !sub.plan.canRenew) throw new ApiError(400, `The ${sub.plan.name} plan cannot be renewed.`)
        if (sub.status === 'DRAFT' || sub.status === 'QUOTATION') {
          throw new ApiError(400, 'Confirm this subscription before renewing it.')
        }
        const base = sub.expiryDate && sub.expiryDate > today ? sub.expiryDate : today
        const newStart = startOfDay(base)
        const expiry = sub.plan
          ? addCycle(newStart, sub.plan.billingCycle === 'YEARLY' ? 'YEARLY' : 'MONTHLY')
          : null
        const newSub = await db.$transaction(async (tx) => {
          const number = await tx.counter.upsert({
            where: { key: 'SUB' },
            update: { value: { increment: 1 } },
            create: { key: 'SUB', value: 1 },
          })
          return tx.subscription.create({
            data: {
              number: `SUB-${String(number.value).padStart(4, '0')}`,
              customerId: sub.customerId,
              planId: sub.planId,
              status: 'CONFIRMED',
              startDate: newStart,
              expiryDate: expiry,
              paymentTerms: sub.paymentTerms,
              notes: `Renewal of ${sub.number}`,
              lines: {
                create: sub.lines.map((l, i) => ({
                  productId: l.productId,
                  variantId: l.variantId,
                  description: l.description,
                  quantity: l.quantity,
                  unitPrice: l.unitPrice,
                  taxRate: l.taxRate,
                  sortOrder: i,
                })),
              },
            },
          })
        })
        // mark the old one closed if it was still open
        if (sub.status === 'ACTIVE' || sub.status === 'PAUSED') {
          await db.subscription.update({
            where: { id },
            data: { status: 'CLOSED', closedAt: new Date(), closeReason: `Renewed as ${newSub.number}` },
          })
        }
        return ok({ subscription: newSub, renewed: true }, 201)
      }
      default:
        throw new ApiError(400, `Unknown action "${action}".`)
    }

    const updated = await db.subscription.findUnique({
      where: { id },
      include: {
        customer: { select: { id: true, name: true, email: true } },
        plan: true,
        lines: { orderBy: { sortOrder: 'asc' } },
      },
    })
    return ok({ subscription: updated })
  })
}
