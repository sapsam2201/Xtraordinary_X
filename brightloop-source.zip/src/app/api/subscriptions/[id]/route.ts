import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const me = await requireRole('ADMIN', 'STAFF', 'CUSTOMER')
    const { id } = await ctx.params
    const subscription = await db.subscription.findUnique({
      where: { id },
      include: {
        customer: true,
        plan: true,
        lines: { include: { product: { include: { variants: true } } }, orderBy: { sortOrder: 'asc' } },
        invoices: { orderBy: { issueDate: 'desc' }, take: 12 },
      },
    })
    if (!subscription) throw new ApiError(404, 'Subscription not found.')
    if (me.role === 'CUSTOMER' && subscription.customerId !== me.customerId) {
      throw new ApiError(403, 'You can only view your own subscriptions.')
    }
    return ok({ subscription })
  })
}

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const body = await req.json()
    const sub = await db.subscription.findUnique({ where: { id }, include: { lines: true } })
    if (!sub) throw new ApiError(404, 'Subscription not found.')
    if (sub.status !== 'DRAFT') throw new ApiError(400, 'Only draft subscriptions can be edited.')

    const data: Record<string, unknown> = {}
    if (body.customerId) {
      const customer = await db.customer.findUnique({ where: { id: body.customerId } })
      if (!customer) throw new ApiError(400, 'Customer not found.')
      data.customerId = body.customerId
    }
    if ('planId' in body) data.planId = body.planId || null
    if ('paymentTerms' in body && body.paymentTerms) data.paymentTerms = body.paymentTerms
    if ('startDate' in body && body.startDate) data.startDate = new Date(String(body.startDate))
    if ('expiryDate' in body) data.expiryDate = body.expiryDate ? new Date(String(body.expiryDate)) : null
    if ('notes' in body) data.notes = body.notes || null

    if (Array.isArray(body.lines) && body.lines.length > 0) {
      await db.subscriptionLine.deleteMany({ where: { subscriptionId: id } })
      data.lines = {
        create: body.lines.map((l: { productId: string; variantId?: string | null; description?: string; quantity: number; unitPrice: number; taxRate: number }, i: number) => ({
          productId: l.productId,
          variantId: l.variantId || null,
          description: l.description || null,
          quantity: Math.max(1, Number(l.quantity) || 1),
          unitPrice: Math.max(0, Number(l.unitPrice) || 0),
          taxRate: Math.max(0, Number(l.taxRate) || 0),
          sortOrder: i,
        })),
      }
    }

    const updated = await db.subscription.update({
      where: { id },
      data,
      include: {
        customer: { select: { id: true, name: true, email: true } },
        plan: true,
        lines: { orderBy: { sortOrder: 'asc' } },
      },
    })
    return ok({ subscription: updated })
  })
}

export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const sub = await db.subscription.findUnique({ where: { id } })
    if (!sub) throw new ApiError(404, 'Subscription not found.')
    if (sub.status !== 'DRAFT') throw new ApiError(400, 'Only draft subscriptions can be deleted.')
    await db.subscription.delete({ where: { id } })
    return ok({ success: true })
  })
}
