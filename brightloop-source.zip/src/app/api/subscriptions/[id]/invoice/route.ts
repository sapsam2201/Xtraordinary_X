import { ApiError, handle, ok, requireRole } from '@/lib/auth'
import { generateInvoiceForSubscription } from '@/lib/invoice-service'

type Ctx = { params: Promise<{ id: string }> }

/** Bill now: create the next invoice for this subscription straight away. */
export async function POST(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const { id } = await ctx.params
    const result = await generateInvoiceForSubscription(id)
    return ok(result, 201)
  })
}
