import { db } from '@/lib/db'
import { ApiError, handle, ok, requireRole } from '@/lib/auth'
import { generateInvoiceForSubscription, startOfDay } from '@/lib/invoice-service'

/** Preview what billing day would do right now. */
export async function GET() {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const today = startOfDay(new Date())

    const due = await db.subscription.findMany({
      where: { status: 'ACTIVE', nextBillingDate: { lte: today } },
      include: {
        customer: { select: { name: true } },
        plan: { select: { name: true, billingCycle: true, autoClose: true } },
        lines: true,
      },
      orderBy: { nextBillingDate: 'asc' },
      take: 500,
    })

    const ready = []
    for (const sub of due) {
      const open = await db.invoice.findFirst({
        where: { subscriptionId: sub.id, status: { in: ['DRAFT', 'CONFIRMED'] } },
        select: { number: true },
      })
      if (!open) {
        const amount = sub.lines.reduce((s, l) => s + l.quantity * l.unitPrice, 0)
        ready.push({
          id: sub.id,
          number: sub.number,
          customer: sub.customer.name,
          plan: sub.plan?.name ?? '—',
          billingCycle: sub.plan?.billingCycle ?? 'MONTHLY',
          nextBillingDate: sub.nextBillingDate,
          estimatedAmount: Math.round(amount * 100) / 100,
          overdueDays: sub.nextBillingDate ? Math.floor((today.getTime() - sub.nextBillingDate.getTime()) / 86400000) : 0,
        })
      }
    }

    const expired = await db.subscription.findMany({
      where: { status: 'ACTIVE', expiryDate: { lt: today }, plan: { autoClose: true } },
      select: { id: true, number: true, customer: { select: { name: true } }, plan: { select: { name: true } }, expiryDate: true },
      take: 100,
    })

    return ok({ dueCount: ready.length, due: ready, autoCloseCount: expired.length, autoClose: expired })
  })
}

/** Run billing day: create every due invoice and close finished plans. */
export async function POST() {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const today = startOfDay(new Date())

    // 1) close subscriptions whose plan period has ended (auto-close plans)
    const expired = await db.subscription.findMany({
      where: { status: 'ACTIVE', expiryDate: { lt: today }, plan: { autoClose: true } },
      select: { id: true, number: true },
    })
    for (const sub of expired) {
      await db.subscription.update({
        where: { id: sub.id },
        data: { status: 'CLOSED', closedAt: new Date(), closeReason: 'Plan period ended' },
      })
    }

    // 2) bill every due subscription that has no open invoice
    const due = await db.subscription.findMany({
      where: { status: 'ACTIVE', nextBillingDate: { lte: today } },
      select: { id: true, number: true },
      take: 500,
    })

    const created: { number: string; invoice: string; total: number }[] = []
    const skipped: { number: string; reason: string }[] = []
    for (const sub of due) {
      const open = await db.invoice.findFirst({
        where: { subscriptionId: sub.id, status: { in: ['DRAFT', 'CONFIRMED'] } },
        select: { number: true },
      })
      if (open) {
        skipped.push({ number: sub.number, reason: `Invoice ${open.number} already open` })
        continue
      }
      try {
        const result = await generateInvoiceForSubscription(sub.id, { issueDate: today })
        created.push({ number: sub.number, invoice: result.invoice.number, total: result.invoice.total })
      } catch (err) {
        skipped.push({ number: sub.number, reason: err instanceof Error ? err.message : 'Failed' })
      }
    }

    return ok({
      invoicesCreated: created.length,
      subscriptionsClosed: expired.length,
      created,
      skipped,
      closed: expired.map((e) => e.number),
    })
  })
}

void ApiError
