import crypto from 'crypto'
import { db } from '@/lib/db'
import { ApiError, handle, ok, validateEmail } from '@/lib/auth'

/**
 * Simulated email delivery: the sandbox has no mail server, so the reset link
 * is returned in the response and shown to the user in the UI.
 */
export async function POST(req: Request) {
  return handle(async () => {
    const body = await req.json()
    const email = String(body.email ?? '').trim().toLowerCase()
    if (!validateEmail(email)) throw new ApiError(400, 'Please enter a valid email address.')

    const user = await db.user.findUnique({ where: { email } })
    // Do not reveal whether the account exists
    if (!user) {
      return ok({ sent: true, resetUrl: null })
    }
    const token = crypto.randomBytes(24).toString('hex')
    await db.passwordResetToken.create({
      data: {
        token,
        userId: user.id,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000),
      },
    })
    return ok({ sent: true, resetUrl: `/?reset=${token}`, simulated: true })
  })
}
