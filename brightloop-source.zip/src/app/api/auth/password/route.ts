import { db } from '@/lib/db'
import { ApiError, handle, ok, requireUser, validatePasswordPolicy } from '@/lib/auth'
import { hashPassword, verifyPassword } from '@/lib/password'

export async function PUT(req: Request) {
  return handle(async () => {
    const me = await requireUser()
    const body = await req.json()
    const current = String(body.current ?? '')
    const next = String(body.next ?? '')

    const user = await db.user.findUnique({ where: { id: me.id } })
    if (!user || !verifyPassword(current, user.passwordHash)) {
      throw new ApiError(400, 'Your current password is incorrect.')
    }
    const pwError = validatePasswordPolicy(next)
    if (pwError) throw new ApiError(400, pwError)

    await db.user.update({
      where: { id: me.id },
      data: { passwordHash: hashPassword(next) },
    })
    return ok({ success: true })
  })
}
