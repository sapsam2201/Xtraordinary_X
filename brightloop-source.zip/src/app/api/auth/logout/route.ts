import { destroySession, handle, ok } from '@/lib/auth'

export async function POST() {
  return handle(async () => {
    await destroySession()
    return ok({ success: true })
  })
}
