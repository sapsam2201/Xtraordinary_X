import { db } from '@/lib/db'
import { getSessionUser, handle, ok } from '@/lib/auth'

export async function GET() {
  return handle(async () => {
    const user = await getSessionUser()
    if (!user) return ok({ user: null })
    let customerName: string | null = null
    if (user.customerId) {
      const c = await db.customer.findUnique({ where: { id: user.customerId }, select: { name: true } })
      customerName = c?.name ?? null
    }
    return ok({ user: { ...user, customerName } })
  })
}
