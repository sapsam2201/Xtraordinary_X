import { db } from '@/lib/db'
import { ApiError, createSession, handle, ok } from '@/lib/auth'
import { verifyPassword } from '@/lib/password'
import { runSeed } from '@/lib/seed'

export async function POST(req: Request) {
  return handle(async () => {
    const body = await req.json()
    const email = String(body.email ?? '').trim().toLowerCase()
    const password = String(body.password ?? '')
    if (!email || !password) throw new ApiError(400, 'Email and password are required.')

    // Self-healing demo: if the dataset was wiped (fresh database), restore
    // it automatically so the demo accounts always work.
    if ((await db.user.count()) === 0) {
      await runSeed()
    }

    const user = await db.user.findUnique({ where: { email } })
    if (!user || !verifyPassword(password, user.passwordHash)) {
      throw new ApiError(401, 'Incorrect email or password.')
    }
    if (!user.isActive) throw new ApiError(403, 'This account has been deactivated. Contact your admin.')

    const token = await createSession(user.id)
    return ok({
      token,
      user: { id: user.id, email: user.email, name: user.name, role: user.role, customerId: user.customerId },
    })
  })
}
