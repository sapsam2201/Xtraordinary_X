import { db } from '@/lib/db'
import { ApiError, handle, ok, validatePasswordPolicy } from '@/lib/auth'
import { hashPassword } from '@/lib/password'

export async function POST(req: Request) {
  return handle(async () => {
    const body = await req.json()
    const token = String(body.token ?? '')
    const password = String(body.password ?? '')
    const pwError = validatePasswordPolicy(password)
    if (pwError) throw new ApiError(400, pwError)

    const record = await db.passwordResetToken.findUnique({ where: { token } })
    if (!record || record.usedAt || record.expiresAt.getTime() < Date.now()) {
      throw new ApiError(400, 'This reset link is invalid or has expired. Request a new one.')
    }
    await db.$transaction([
      db.user.update({ where: { id: record.userId }, data: { passwordHash: hashPassword(password) } }),
      db.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
      // force re-login everywhere after a reset
      db.session.deleteMany({ where: { userId: record.userId } }),
    ])
    return ok({ success: true })
  })
}
