import { db } from '@/lib/db'
import {
  ApiError,
  createSession,
  handle,
  ok,
  validateEmail,
  validatePasswordPolicy,
} from '@/lib/auth'
import { hashPassword } from '@/lib/password'

export async function POST(req: Request) {
  return handle(async () => {
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    const email = String(body.email ?? '').trim().toLowerCase()
    const password = String(body.password ?? '')

    if (!name) throw new ApiError(400, 'Please enter your name.')
    if (!validateEmail(email)) throw new ApiError(400, 'Please enter a valid email address.')
    const pwError = validatePasswordPolicy(password)
    if (pwError) throw new ApiError(400, pwError)

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) throw new ApiError(409, 'This email already belongs to an account.')

    const customer = await db.customer.create({
      data: { name, email },
    })
    const user = await db.user.create({
      data: {
        email,
        name,
        role: 'CUSTOMER',
        passwordHash: hashPassword(password),
        customerId: customer.id,
      },
    })
    const token = await createSession(user.id)
    return ok({
      token,
      user: { id: user.id, email: user.email, name: user.name, role: user.role, customerId: user.customerId },
    }, 201)
  })
}
