import { ApiError, handle, ok, requireAdmin } from '@/lib/auth'
import { runSeed } from '@/lib/seed'

/** Re-initialize the Brightloop demo dataset (admin only). */
export async function POST() {
  return handle(async () => {
    await requireAdmin()
    const summary = await runSeed()
    return ok({ summary })
  })
}

void ApiError
