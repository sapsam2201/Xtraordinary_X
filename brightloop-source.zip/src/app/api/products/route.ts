import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin, requireRole } from '@/lib/auth'

type VariantInput = { id?: string; name: string; value: string; priceDelta: number }

export async function GET() {
  return handle(async () => {
    await requireRole('ADMIN', 'STAFF')
    const products = await db.product.findMany({
      include: { variants: true, _count: { select: { subLines: true } } },
      orderBy: { createdAt: 'asc' },
    })
    return ok({ products })
  })
}

export async function POST(req: Request) {
  return handle(async () => {
    await requireAdmin()
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    if (!name) throw new ApiError(400, 'Product name is required.')
    const salesPrice = Number(body.salesPrice)
    const costPrice = Number(body.costPrice)
    if (!Number.isFinite(salesPrice) || salesPrice < 0) throw new ApiError(400, 'Sales price must be a positive number.')
    if (!Number.isFinite(costPrice) || costPrice < 0) throw new ApiError(400, 'Cost price must be a positive number.')
    const type = ['SOFTWARE', 'ADDON', 'SERVICE'].includes(body.type) ? body.type : 'SOFTWARE'

    const variants: VariantInput[] = Array.isArray(body.variants)
      ? body.variants.filter((v: VariantInput) => v && String(v.value ?? '').trim())
      : []

    const product = await db.product.create({
      data: {
        name,
        type,
        salesPrice,
        costPrice,
        notes: body.notes || null,
        variants: {
          create: variants.map((v) => ({
            name: String(v.name ?? 'Variant').trim() || 'Variant',
            value: String(v.value).trim(),
            priceDelta: Number(v.priceDelta) || 0,
          })),
        },
      },
      include: { variants: true },
    })
    return ok({ product }, 201)
  })
}
