import { db } from '@/lib/db'
import { ApiError, handle, ok, requireAdmin } from '@/lib/auth'

type Ctx = { params: Promise<{ id: string }> }
type VariantInput = { id?: string; name: string; value: string; priceDelta: number }

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    const body = await req.json()
    const product = await db.product.findUnique({ where: { id } })
    if (!product) throw new ApiError(404, 'Product not found.')

    const data: Record<string, unknown> = {}
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
    if (body.type && ['SOFTWARE', 'ADDON', 'SERVICE'].includes(body.type)) data.type = body.type
    if (body.salesPrice !== undefined) {
      const v = Number(body.salesPrice)
      if (!Number.isFinite(v) || v < 0) throw new ApiError(400, 'Sales price must be a positive number.')
      data.salesPrice = v
    }
    if (body.costPrice !== undefined) {
      const v = Number(body.costPrice)
      if (!Number.isFinite(v) || v < 0) throw new ApiError(400, 'Cost price must be a positive number.')
      data.costPrice = v
    }
    if ('notes' in body) data.notes = body.notes || null
    if (typeof body.active === 'boolean') data.active = body.active

    await db.product.update({ where: { id }, data })

    if (Array.isArray(body.variants)) {
      const incoming = body.variants.filter((v: VariantInput) => v && String(v.value ?? '').trim()) as VariantInput[]
      const keepIds = incoming.filter((v) => v.id).map((v) => v.id as string)
      await db.productVariant.deleteMany({ where: { productId: id, id: { notIn: keepIds } } })
      for (const v of incoming) {
        const delta = Number(v.priceDelta) || 0
        if (v.id) {
          await db.productVariant.update({
            where: { id: v.id },
            data: { name: String(v.name ?? 'Variant').trim() || 'Variant', value: String(v.value).trim(), priceDelta: delta },
          })
        } else {
          await db.productVariant.create({
            data: { productId: id, name: String(v.name ?? 'Variant').trim() || 'Variant', value: String(v.value).trim(), priceDelta: delta },
          })
        }
      }
    }

    const updated = await db.product.findUnique({ where: { id }, include: { variants: true } })
    return ok({ product: updated })
  })
}

export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    const used = await db.subscriptionLine.count({ where: { productId: id } })
    if (used > 0) {
      const product = await db.product.update({ where: { id }, data: { active: false }, include: { variants: true } })
      return ok({ product, archived: true })
    }
    await db.product.delete({ where: { id } })
    return ok({ success: true })
  })
}
