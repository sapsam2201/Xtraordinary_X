'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { api, clearSession, UNAUTHORIZED_EVENT } from '@/components/app/api-client'
import { AuthScreen } from '@/components/app/auth-screen'
import { Shell, type ViewKey } from '@/components/app/shell'
import { Dashboard } from '@/components/app/dashboard'
import { Subscriptions } from '@/components/app/subscriptions'
import { Invoices } from '@/components/app/invoices'
import { Payments } from '@/components/app/payments'
import { Customers } from '@/components/app/customers'
import { Products } from '@/components/app/products'
import { Plans } from '@/components/app/plans'
import { Templates } from '@/components/app/templates'
import { Discounts } from '@/components/app/discounts'
import { Taxes } from '@/components/app/taxes'
import { Staff } from '@/components/app/staff'
import { Settings } from '@/components/app/settings'
import { CustomerPortal } from '@/components/app/portal'
import { Reports } from '@/components/app/reports'
import { BillingRuns } from '@/components/app/billing-runs'
import { Activity } from '@/components/app/activity'
import { Logo } from '@/components/app/ui-bits'
import type { SessionUser } from '@/components/app/types'
import { useToast } from '@/hooks/use-toast'

export default function Home() {
  const [booting, setBooting] = useState(true)
  const [user, setUser] = useState<SessionUser | null>(null)
  const [view, setView] = useState<ViewKey>('dashboard')
  const [resetToken, setResetToken] = useState<string | undefined>(undefined)
  const [openInvoiceId, setOpenInvoiceId] = useState<string | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)
  const { toast } = useToast()
  const signedIn = useRef(false)
  signedIn.current = !!user

  // If any API responds 401 while a session is on screen (e.g. the demo
  // dataset was re-initialized or the server restarted mid-session),
  // end the session silently — the login screen explains itself. Login
  // and register 401s are ignored so form errors stay inline in AuthScreen.
  useEffect(() => {
    const onUnauthorized = () => {
      if (!signedIn.current) return
      signedIn.current = false
      setUser(null)
      setView('dashboard')
    }
    window.addEventListener(UNAUTHORIZED_EVENT, onUnauthorized)
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, onUnauthorized)
  }, [])

  const bootstrap = useCallback(async () => {
    // password-reset links land here as /?reset=<token>
    const params = new URLSearchParams(window.location.search)
    const token = params.get('reset')
    if (token) {
      setResetToken(token)
      window.history.replaceState(null, '', '/')
    }
    try {
      const res = await api.get<{ user: SessionUser | null }>('/api/auth/me')
      setUser(res.user)
    } catch {
      setUser(null)
    } finally {
      setBooting(false)
    }
  }, [])

  useEffect(() => { bootstrap() }, [bootstrap])

  const handleLogout = useCallback(async () => {
    try {
      await api.post('/api/auth/logout')
    } finally {
      clearSession()
      setUser(null)
      setView('dashboard')
      toast({ title: 'Signed out' })
    }
  }, [toast])

  function refreshData() {
    setRefreshKey((k) => k + 1)
  }

  if (booting) {
    return (
      <div className="dark flex min-h-screen items-center justify-center bg-[oklch(0.155_0.018_172)]">
        <div className="animate-pulse"><Logo size={44} dark /></div>
      </div>
    )
  }

  if (!user) {
    return (
      <AuthScreen
        resetToken={resetToken}
        onResetConsumed={() => setResetToken(undefined)}
        onAuthed={(u) => {
          setUser(u)
          setView('dashboard')
        }}
      />
    )
  }

  if (user.role === 'CUSTOMER') {
    return <CustomerPortal user={user} onLogout={handleLogout} />
  }

  return (
    <Shell user={user} view={view} onView={setView} onLogout={handleLogout}>
      {view === 'dashboard' && (
        <Dashboard
          onOpenInvoice={(id) => { setOpenInvoiceId(id); setView('invoices') }}
          onOpenBilling={refreshData}
        />
      )}
      {view === 'subscriptions' && (
        <Subscriptions
          key={`subs-${refreshKey}`}
          onChanged={refreshData}
        />
      )}
      {view === 'invoices' && (
        <Invoices
          key={`inv-${refreshKey}`}
          openInvoiceId={openInvoiceId}
          onOpenInvoice={setOpenInvoiceId}
          clearOpenInvoice={() => setOpenInvoiceId(null)}
          onChanged={refreshData}
          authRole={user.role}
        />
      )}
      {view === 'payments' && <Payments />}
      {view === 'billingruns' && <BillingRuns onChanged={refreshData} />}
      {view === 'customers' && <Customers />}
      {view === 'products' && <Products isAdmin={user.role === 'ADMIN'} />}
      {view === 'plans' && <Plans isAdmin={user.role === 'ADMIN'} />}
      {view === 'templates' && <Templates />}
      {view === 'discounts' && <Discounts isAdmin={user.role === 'ADMIN'} />}
      {view === 'taxes' && <Taxes isAdmin={user.role === 'ADMIN'} />}
      {view === 'reports' && <Reports />}
      {view === 'activity' && <Activity />}
      {view === 'staff' && user.role === 'ADMIN' && <Staff currentUserId={user.id} />}
      {view === 'settings' && <Settings user={user} />}
    </Shell>
  )
}
