'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Bot, Loader2, RotateCcw, Send, X } from 'lucide-react'
import { api } from '@/components/app/api-client'
import { cn } from '@/lib/utils'
import type { Role } from '@/components/app/types'

type Msg = { role: 'user' | 'assistant'; content: string; error?: boolean }

const SUGGESTIONS: Record<Role, string[]> = {
  CUSTOMER: [
    'Do I have any unpaid invoices?',
    'When is my next billing date?',
    'What plans do you offer?',
  ],
  STAFF: [
    'Which invoices are overdue?',
    'How many subscriptions are active?',
    'Any discounts running right now?',
  ],
  ADMIN: [
    'Give me this month’s numbers',
    'Which invoices are overdue?',
    'How much recurring revenue do we have?',
  ],
}

const GREETING: Record<Role, string> = {
  CUSTOMER: 'Hi! I can look up your subscriptions, invoices and payments.',
  STAFF: 'Hi! Ask me about customers, subscriptions, invoices, payments or overdue amounts.',
  ADMIN: 'Hi! Ask me about customers, subscriptions, invoices, payments or revenue.',
}

/**
 * Floating AI assistant. Rendered for any signed-in user; the backend decides what data each role may see.
 * The button stays hidden when the server has no GROQ_API_KEY.
 */
export function ChatWidget({ role }: { role: Role }) {
  const [enabled, setEnabled] = useState(false)
  const [open, setOpen] = useState(false)
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const endRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    api.get<{ enabled: boolean }>('/api/chat/status').then((r) => setEnabled(r.enabled)).catch(() => setEnabled(false))
  }, [])

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [msgs, busy, open])

  useEffect(() => {
    if (open) inputRef.current?.focus()
  }, [open])

  const send = useCallback(
    async (text: string) => {
      const q = text.trim()
      if (!q || busy) return
      const next: Msg[] = [...msgs, { role: 'user', content: q }]
      setMsgs(next)
      setInput('')
      setBusy(true)
      try {
        // errors are shown in the chat but never sent back to the model
        const history = next.filter((m) => !m.error).slice(-12).map(({ role: r, content }) => ({ role: r, content }))
        const res = await api.post<{ reply: string }>('/api/chat', { messages: history })
        setMsgs([...next, { role: 'assistant', content: res.reply }])
      } catch (e) {
        setMsgs([...next, { role: 'assistant', error: true, content: e instanceof Error ? e.message : 'Something went wrong.' }])
      } finally {
        setBusy(false)
      }
    },
    [msgs, busy],
  )

  if (!enabled) return null

  return (
    <div className="print:hidden">
      {open && (
        <div
          role="dialog"
          aria-label="Brightloop assistant"
          className="fixed inset-x-3 bottom-20 z-50 flex h-[min(34rem,calc(100vh-7rem))] flex-col overflow-hidden rounded-2xl border bg-background text-foreground shadow-2xl sm:inset-x-auto sm:right-5 sm:w-[24rem] md:bottom-20"
        >
          <div className="flex items-center gap-2 border-b bg-emerald-600 px-4 py-3 text-white">
            <Bot className="size-4" aria-hidden />
            <div className="flex-1 text-sm font-semibold">Brightloop assistant</div>
            <button
              type="button"
              onClick={() => setMsgs([])}
              disabled={!msgs.length || busy}
              className="rounded p-1 opacity-80 hover:bg-white/15 hover:opacity-100 disabled:opacity-30"
              aria-label="Clear conversation"
              title="Clear conversation"
            >
              <RotateCcw className="size-4" />
            </button>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded p-1 opacity-80 hover:bg-white/15 hover:opacity-100"
              aria-label="Close assistant"
            >
              <X className="size-4" />
            </button>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4 text-sm" aria-live="polite">
            <Bubble role="assistant">{GREETING[role]}</Bubble>
            {!msgs.length && (
              <div className="flex flex-wrap gap-2 pt-1">
                {SUGGESTIONS[role].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => send(s)}
                    className="rounded-full border px-3 py-1.5 text-left text-xs text-muted-foreground transition hover:border-emerald-500 hover:text-foreground"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
            {msgs.map((m, i) => (
              <Bubble key={i} role={m.role} error={m.error}>
                {m.content}
              </Bubble>
            ))}
            {busy && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="size-3.5 animate-spin" aria-hidden /> Looking that up…
              </div>
            )}
            <div ref={endRef} />
          </div>

          <form
            className="flex items-end gap-2 border-t p-3"
            onSubmit={(e) => {
              e.preventDefault()
              send(input)
            }}
          >
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  send(input)
                }
              }}
              rows={1}
              maxLength={2000}
              placeholder="Ask about billing…"
              aria-label="Message"
              className="max-h-28 min-h-9 flex-1 resize-none rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:border-emerald-500"
            />
            <button
              type="submit"
              disabled={busy || !input.trim()}
              className="grid size-9 place-items-center rounded-lg bg-emerald-600 text-white transition hover:bg-emerald-700 disabled:opacity-40"
              aria-label="Send"
            >
              <Send className="size-4" />
            </button>
          </form>
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? 'Close assistant' : 'Open assistant'}
        aria-expanded={open}
        className="fixed bottom-4 right-4 z-50 grid size-11 place-items-center rounded-full bg-emerald-600 text-white shadow-lg transition hover:scale-105 hover:bg-emerald-700"
      >
        {open ? <X className="size-5" /> : <Bot className="size-5" />}
      </button>
    </div>
  )
}

function Bubble({ role, error, children }: { role: 'user' | 'assistant'; error?: boolean; children: React.ReactNode }) {
  const mine = role === 'user'
  return (
    <div className={cn('flex', mine ? 'justify-end' : 'justify-start')}>
      <div
        className={cn(
          'max-w-[85%] whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2 leading-relaxed',
          mine ? 'rounded-br-sm bg-emerald-600 text-white' : 'rounded-bl-sm bg-muted text-foreground',
          error && 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200',
        )}
      >
        {children}
      </div>
    </div>
  )
}
