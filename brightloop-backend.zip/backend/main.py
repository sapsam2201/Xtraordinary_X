#!/usr/bin/env python3
"""Brightloop backend entry point.

    python main.py            start the API on http://127.0.0.1:8000  (Swagger UI at /docs)
    python main.py seed       create demo data   (add  --bulk 5000  to load-test)

The application itself lives in the `app/` package (see README.md for the layout).
"""
import os
import sys

from app.database import SessionLocal  # noqa: F401  (re-exported for smoke_test.py)
from app.main import app, init_db  # noqa: F401
from app.models import DiscountRule, Subscription  # noqa: F401
from app.seed import run_seed  # noqa: F401
from app.utils import add_months, today_utc  # noqa: F401

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "seed":
        init_db()
        n = int(sys.argv[sys.argv.index("--bulk") + 1]) if "--bulk" in sys.argv else 0
        with SessionLocal() as s:
            print(run_seed(s, bulk=n))
    else:
        import uvicorn
        uvicorn.run("main:app", host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "8000")), reload=False)
