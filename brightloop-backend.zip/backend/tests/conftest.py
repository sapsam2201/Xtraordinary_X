"""Shared fixtures: every test run gets a throw-away SQLite database seeded with demo data."""
import os
import sys
import tempfile

os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.mkdtemp(), "test.db")
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

import main  # noqa: E402


@pytest.fixture(scope="session")
def app_main():
    main.init_db()
    with main.SessionLocal() as s:
        main.run_seed(s)
    return main


@pytest.fixture(scope="session")
def client(app_main):
    return TestClient(app_main.app)


def _login(client, email, pw):
    r = client.post("/api/auth/login", json={"email": email, "password": pw})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


@pytest.fixture(scope="session")
def admin(client):
    return _login(client, "admin@brightloop.com", "Admin@123!")


@pytest.fixture(scope="session")
def staff(client):
    return _login(client, "maya@brightloop.com", "Staff@123!")


@pytest.fixture(scope="session")
def customer(client):
    return _login(client, "accounts@kaveritextiles.in", "Customer@123!")
