"""Core behaviours from the Brightloop brief. Run: pytest -q"""
import pytest
from sqlalchemy import update


# ---------------------------------------------------------------- accounts & roles
@pytest.mark.parametrize("pw", ["Sh0rt!a", "alllowercase1!", "ALLUPPERCASE1!", "NoSpecial1234", "Abcdef1!"])
def test_weak_passwords_rejected(client, pw):
    r = client.post("/api/auth/register", json={"name": "A", "email": "weak@x.com", "password": pw})
    assert r.status_code == 400


def test_register_and_duplicate_email(client):
    ok = client.post("/api/auth/register", json={"name": "New Co", "email": "newco@x.com", "password": "Strong#Pass1"})
    assert ok.status_code == 201
    dup = client.post("/api/auth/register", json={"name": "Other", "email": "NEWCO@x.com", "password": "Strong#Pass1"})
    assert dup.status_code == 409


def test_role_restrictions(client, admin, staff, customer):
    assert client.get("/api/invoices").status_code == 401
    assert client.get("/api/customers", headers=customer).status_code == 403
    assert client.post("/api/products", headers=staff, json={"name": "x", "salesPrice": 1, "costPrice": 1}).status_code == 403
    assert client.post("/api/discounts", headers=staff, json={}).status_code == 403
    new_staff = {"name": "Zed", "email": "zed@brightloop.com", "password": "Staff@4567!"}
    assert client.post("/api/users", headers=staff, json=new_staff).status_code == 403
    assert client.post("/api/users", headers=admin, json=new_staff).status_code == 201


def test_customer_sees_only_own_data(client, admin, customer):
    mine = client.get("/api/invoices", headers=customer).json()["invoices"]
    assert mine and all(i["customer"]["name"] == "Kaveri Textiles" for i in mine)
    other = next(i for i in client.get("/api/invoices", headers=admin).json()["invoices"]
                 if i["customer"]["name"] != "Kaveri Textiles")
    assert client.get(f"/api/invoices/{other['id']}", headers=customer).status_code == 403


# ---------------------------------------------------------------- billing, discounts, payments
@pytest.fixture(scope="module")
def billed(client, admin, staff, app_main):
    """A product, a plan, a product-level 20% discount capped at 2 uses and one subscription caught up over 4 cycles."""
    prod = client.post("/api/products", headers=admin, json={
        "name": "Test Connector", "type": "ADDON", "salesPrice": 1000, "costPrice": 300,
        "variants": [{"name": "Brand", "value": "Odoo", "priceDelta": 560}]}).json()["product"]
    assert prod["variants"][0]["priceDelta"] == 560
    plan = client.post("/api/plans", headers=admin, json={
        "name": "Test Monthly", "productId": prod["id"], "price": 1100, "billingCycle": "MONTHLY",
        "canPause": True, "canCloseEarly": True, "canRenew": True}).json()["plan"]
    client.post("/api/tax-rules", headers=admin, json={"name": "GST 18", "rate": 18})
    disc = client.post("/api/discounts", headers=admin, json={
        "name": "Seat discount", "type": "PERCENTAGE", "value": 20, "scope": "PRODUCT", "productId": prod["id"], "minQuantity": 4,
        "startDate": "2020-01-01", "endDate": "2099-12-31", "maxUses": 2}).json()["discount"]
    cust = client.get("/api/customers?q=Nimbus", headers=admin).json()["customers"][0]
    sub = client.post("/api/subscriptions", headers=staff, json={
        "customerId": cust["id"], "planId": plan["id"], "paymentTerms": "NET_15",
        "lines": [{"productId": prod["id"], "quantity": 5, "unitPrice": 1100, "taxRate": 18}]}).json()["subscription"]
    for a in ("send_quote", "confirm", "activate"):
        assert client.post(f"/api/subscriptions/{sub['id']}/transition", headers=staff, json={"action": a}).status_code == 200
    with app_main.SessionLocal() as db:  # pretend three billing days were missed
        db.execute(update(app_main.Subscription).where(app_main.Subscription.id == sub["id"]).values(
            next_billing_date=app_main.add_months(app_main.today_utc(), -3)))
        db.commit()
    first = client.post("/api/billing", headers=staff).json()
    second = client.post("/api/billing", headers=staff).json()
    return dict(cust=cust, sub=sub, disc=disc, first=first, second=second)


def test_billing_day_never_bills_twice(billed):
    assert billed["first"]["invoicesCreated"] >= 4
    assert billed["second"]["invoicesCreated"] == 0


def test_one_invoice_per_period(client, staff, billed):
    inv = [i for i in client.get(f"/api/invoices?customerId={billed['cust']['id']}&limit=1000", headers=staff).json()["invoices"]
           if i["subscription"] and i["subscription"]["id"] == billed["sub"]["id"]]
    assert len(inv) == 4
    assert len({i["periodStart"] for i in inv}) == 4


def test_discount_applied_automatically_and_usage_capped(client, staff, app_main, billed):
    d = _invoice(client, staff, billed, 0)
    assert d["discountTotal"] > 0 and "Seat discount" in d["discountNote"]
    assert abs(d["subtotal"] - d["discountTotal"] + d["taxTotal"] - d["total"]) < 0.02
    with app_main.SessionLocal() as db:
        assert db.get(app_main.DiscountRule, billed["disc"]["id"]).used_count == 2  # maxUses=2


def _invoice(client, staff, billed, n=0):
    inv = client.get(f"/api/invoices?customerId={billed['cust']['id']}&sort=number&dir=asc&limit=1000", headers=staff).json()["invoices"]
    inv = [i for i in inv if i["subscription"] and i["subscription"]["id"] == billed["sub"]["id"]]
    return client.get(f"/api/invoices/{inv[n]['id']}", headers=staff).json()["invoice"]


def test_payment_flow_and_overdue_with_partial_payment(client, staff, app_main, billed):
    inv = _invoice(client, staff, billed, 1)
    assert client.post("/api/payments", headers=staff, json={"invoiceId": inv["id"], "method": "UPI", "amount": 10}).status_code == 400  # draft
    assert client.post(f"/api/invoices/{inv['id']}/action", headers=staff, json={"action": "confirm"}).status_code == 200
    with app_main.SessionLocal() as db:  # make it overdue
        db.execute(update(app_main.Invoice).where(app_main.Invoice.id == inv["id"]).values(
            due_date=app_main.add_months(app_main.today_utc(), -1)))
        db.commit()
    half = round(inv["total"] / 2, 2)
    r = client.post("/api/payments", headers=staff, json={"invoiceId": inv["id"], "method": "CASH", "amount": half, "note": "part"})
    assert r.status_code == 201 and r.json()["invoiceStatus"] == "CONFIRMED"
    od = client.get("/api/dashboard", headers=staff).json()["kpis"]
    assert od["overdueCount"] >= 1
    listed = client.get("/api/invoices?status=CONFIRMED", headers=staff).json()
    assert listed["summary"]["overdueAmount"] >= round(inv["total"] - half, 2) - 0.01  # only the balance is owed
    assert client.post("/api/payments", headers=staff, json={"invoiceId": inv["id"], "method": "CASH", "amount": inv["total"]}).status_code == 400  # overpay
    done = client.post("/api/payments", headers=staff, json={"invoiceId": inv["id"], "method": "BANK_TRANSFER", "amount": round(inv["total"] - half, 2)})
    assert done.json()["invoiceStatus"] == "PAID" and done.json()["balance"] == 0


# ---------------------------------------------------------------- paging, filters, CSV
def test_invoice_paging_total_sort_and_summary(client, admin, billed):
    full = client.get("/api/invoices?limit=1000", headers=admin).json()
    page = client.get("/api/invoices?limit=2&offset=0&sort=total&dir=desc", headers=admin).json()
    assert page["total"] == full["total"] and len(page["invoices"]) == 2
    totals = [i["total"] for i in page["invoices"]]
    assert totals == sorted(totals, reverse=True)
    nxt = client.get("/api/invoices?limit=2&offset=2&sort=total&dir=desc", headers=admin).json()
    assert {i["id"] for i in nxt["invoices"]}.isdisjoint({i["id"] for i in page["invoices"]})
    assert set(page["summary"]) == {"openCount", "openAmount", "overdueCount", "overdueAmount"}
    assert client.get("/api/invoices?sort=__bogus__;drop", headers=admin).status_code == 200  # whitelist only


def test_subscription_paging_and_status_counts(client, admin):
    r = client.get("/api/subscriptions?limit=3&sort=customer&dir=asc", headers=admin).json()
    assert len(r["subscriptions"]) <= 3 and r["total"] >= len(r["subscriptions"])
    assert r["counts"]["ALL"] == sum(v for k, v in r["counts"].items() if k != "ALL")
    active = client.get("/api/subscriptions?status=ACTIVE", headers=admin).json()
    assert active["total"] == r["counts"].get("ACTIVE", 0)


def test_payment_paging_total_amount(client, admin):
    r = client.get("/api/payments?limit=1", headers=admin).json()
    assert r["total"] >= 1 and len(r["payments"]) == 1
    every = client.get("/api/payments?limit=1000", headers=admin).json()["payments"]
    assert abs(r["totalAmount"] - sum(p["amount"] for p in every)) < 0.02


@pytest.mark.parametrize("path,first", [("/api/invoices.csv", "Invoice"), ("/api/payments.csv", "Payment"),
                                         ("/api/subscriptions.csv", "Subscription")])
def test_csv_exports(client, admin, path, first):
    r = client.get(path, headers=admin)
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")
    lines = r.content.decode("utf-8-sig").strip().splitlines()
    assert lines[0].startswith(first) and len(lines) > 1


def test_csv_respects_customer_scope(client, customer):
    lines = client.get("/api/invoices.csv", headers=customer).content.decode("utf-8-sig").strip().splitlines()
    assert all("Kaveri Textiles" in l for l in lines[1:])
