"""Passwords, e-mail validation and in-memory rate limiting."""

import hashlib
import hmac
import re
import secrets
import time
from typing import Optional

from fastapi import Request

from app.utils import ApiError


def hash_password(pw: str) -> str:  # same format as the Node version: "salt:hash" (scrypt N=16384 r=8 p=1)
    salt = secrets.token_hex(16)
    h = hashlib.scrypt(pw.encode(), salt=salt.encode(), n=16384, r=8, p=1, dklen=64, maxmem=64 * 1024 * 1024)
    return f"{salt}:{h.hex()}"


def verify_password(pw: str, stored: str) -> bool:
    try:
        salt, h = stored.split(":")
        cand = hashlib.scrypt(pw.encode(), salt=salt.encode(), n=16384, r=8, p=1, dklen=64, maxmem=64 * 1024 * 1024)
        return hmac.compare_digest(cand, bytes.fromhex(h))
    except Exception:
        return False


def password_error(pw: str) -> Optional[str]:
    if not pw or len(pw) <= 8:
        return "Password must be more than 8 characters long."
    if not re.search(r"[A-Z]", pw):
        return "Password must contain an uppercase letter."
    if not re.search(r"[a-z]", pw):
        return "Password must contain a lowercase letter."
    if not re.search(r"[^A-Za-z0-9]", pw):
        return "Password must contain a special character."
    return None


def valid_email(e: str) -> bool:
    return bool(re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", e))


# simple in-memory brute-force guard for /login
_fails: dict = {}


_hits: dict = {}


def client_ip(req: Request) -> str:
    fwd = req.headers.get("x-forwarded-for", "")
    if fwd:
        return fwd.split(",")[0].strip()
    return req.client.host if req.client else "?"


def rate_limit(req: Request, bucket: str, limit: int, window: int = 600) -> None:
    """Tiny in-memory limiter (per process) for unauthenticated endpoints."""
    key = f"{bucket}|{client_ip(req)}"
    now = time.time()
    hits = [t for t in _hits.get(key, []) if t > now - window]
    if len(hits) >= limit:
        raise ApiError(429, "Too many requests. Please try again in a few minutes.")
    _hits[key] = hits + [now]


def _throttle_key(req: Request, email: str) -> str:
    return f"{req.client.host if req.client else '?'}|{email}"
