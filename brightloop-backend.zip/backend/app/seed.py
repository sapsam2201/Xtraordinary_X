"""Demo data (python main.py seed [--bulk N])."""

import random
from datetime import timedelta

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.config import METHODS, PAYMENT_TERMS_DAYS
from app.models import Base, Counter, Customer, DiscountRule, Invoice, Payment, Plan, Product, ProductVariant, QuotationTemplate, Subscription, SubscriptionLine, TaxRule, TemplateLine, User
from app.security import hash_password
from app.services.billing import create_invoice_row, next_number
from app.utils import add_cycle, today_utc


def run_seed(db: Session, bulk: int = 0) -> dict:
    rng = random.Random(20261031)
    today = today_utc()
    for t in reversed(Base.metadata.sorted_tables):
        db.execute(delete(t))
    for k in ("INV", "SUB", "PAY"):
        db.add(Counter(key=k, value=0))
    db.flush()

    admin_pw, staff_pw, cust_pw = hash_password("Admin@123!"), hash_password("Staff@123!"), hash_password("Customer@123!")
    db.add_all([User(email="admin@brightloop.com", name="Aarav Mehta", role="ADMIN", password_hash=admin_pw),
                User(email="maya@brightloop.com", name="Maya Iyer", role="STAFF", password_hash=staff_pw),
                User(email="liam@brightloop.com", name="Liam Fernandes", role="STAFF", password_hash=staff_pw)])

    taxes = [TaxRule(name="GST 18%", rate=18), TaxRule(name="GST 12%", rate=12), TaxRule(name="GST 5%", rate=5),
             TaxRule(name="Zero rated", rate=0)]
    db.add_all(taxes)

    def prod(name, typ, sale, cost, notes=None, variants=()):
        p = Product(name=name, type=typ, sales_price=sale, cost_price=cost, notes=notes,
                    variants=[ProductVariant(name=n, value=v, price_delta=d) for n, v, d in variants])
        db.add(p)
        return p
    crm = prod("Brightloop CRM", "SOFTWARE", 1200, 380, "Per-seat CRM suite", [("Brand", "Odoo", 560), ("Brand", "Zoho", 300), ("Brand", "Native", 0)])
    desk = prod("Brightloop Helpdesk", "SOFTWARE", 900, 300, "Ticketing and SLAs", [("Edition", "Pro", 250), ("Edition", "Standard", 0)])
    seat = prod("Extra Seat", "ADDON", 150, 40)
    supp = prod("Priority Support", "ADDON", 500, 180)
    onb = prod("Onboarding Package", "SERVICE", 2500, 1100)
    db.flush()

    def plan(name, p, price, cyc, **kw):
        pl = Plan(name=name, product_id=p.id, price=price, billing_cycle=cyc, **kw)
        db.add(pl)
        return pl
    plans = [plan("CRM Monthly", crm, 1200, "MONTHLY", can_pause=True, can_close_early=True, description="Flexible month-to-month CRM"),
             plan("CRM Yearly", crm, 12000, "YEARLY", auto_close=True, can_renew=True, can_close_early=False, description="Annual contract, 2 months free"),
             plan("Helpdesk Monthly", desk, 900, "MONTHLY", can_pause=True, can_renew=True),
             plan("Support Weekly", supp, 500, "WEEKLY", can_pause=True),
             plan("Sandbox Daily", seat, 50, "DAILY", min_quantity=2)]
    db.flush()

    db.add_all([
        DiscountRule(name="Volume 10% (5+ seats)", type="PERCENTAGE", value=10, scope="SUBSCRIPTION", min_quantity=5,
                     start_date=today - timedelta(days=30), end_date=today + timedelta(days=330)),
        DiscountRule(name="Welcome 500 off", type="FIXED", value=500, scope="SUBSCRIPTION", min_purchase=3000, max_uses=20,
                     start_date=today - timedelta(days=10), end_date=today + timedelta(days=90)),
        DiscountRule(name="Seat promo 15%", type="PERCENTAGE", value=15, scope="PRODUCT", product_id=seat.id,
                     start_date=today - timedelta(days=5), end_date=today + timedelta(days=60)),
    ])
    db.add(QuotationTemplate(name="Starter CRM pack", description="CRM seats plus onboarding", plan_id=plans[0].id, valid_days=15, lines=[
        TemplateLine(product_id=crm.id, quantity=5, unit_price=1200, tax_rate=18, sort_order=0),
        TemplateLine(product_id=onb.id, quantity=1, unit_price=2500, tax_rate=18, sort_order=1)]))
    db.flush()

    names = [("Kaveri Textiles", "accounts@kaveritextiles.in", "Coimbatore", "India"), ("Nimbus Retail", "finance@nimbusretail.com", "Mumbai", "India"),
             ("GlowCart", "billing@glowcart.shop", "Bengaluru", "India"), ("Orbit Logistics", "ap@orbitlogistics.co", "Singapore", "Singapore"),
             ("Zenko Labs", "pay@zenkolabs.io", "Pune", "India"), ("Blue Fern Boutique", "hello@bluefern.nz", "Auckland", "New Zealand"),
             ("Marigold Sweets", "owner@marigoldsweets.in", "Jaipur", "India"), ("Crestline Realty", "accounts@crestline.re", "Hyderabad", "India"),
             ("Pinewood Interiors", "billing@pinewood.design", "Chennai", "India"), ("Quill & Press", "subs@quillandpress.com", "Kochi", "India"),
             ("Halcyon Clinics", "finance@halcyon.care", "Delhi", "India"), ("Verve Fitness", "ap@vervefitness.in", "Ahmedabad", "India"),
             ("Sable Motors", "accounts@sablemotors.co", "Dubai", "UAE"), ("Fjord Analytics", "invoices@fjordanalytics.no", "Bergen", "Norway")]
    main_prod = {pl.id: p for pl, p in zip(plans, [crm, crm, desk, supp, seat])}
    back = {"DAILY": 10, "WEEKLY": 50, "MONTHLY": 210, "YEARLY": 500}
    stats = {"payments": 0}

    def make_customer(name, email, city, country, with_user=True):
        c = Customer(name=name, email=email, city=city, country=country, phone=f"+91 9{rng.randint(10**8, 10**9 - 1)}")
        db.add(c)
        db.flush()
        if with_user:
            db.add(User(email=email, name=name, role="CUSTOMER", password_hash=cust_pw, customer_id=c.id))
        return c

    def make_sub(c, pl, status, history=True):
        p = main_prod[pl.id]
        qty = rng.choice([1, 2, 3, 5, 8, 12]) if pl.billing_cycle != "DAILY" else 2
        price = p.sales_price + (rng.choice([0, 560]) if p is crm else 0)
        lines = [SubscriptionLine(product_id=p.id, quantity=qty, unit_price=price if pl.billing_cycle != "YEARLY" else price * 10, tax_rate=18, sort_order=0)]
        if p is not seat and rng.random() < 0.35:
            lines.append(SubscriptionLine(product_id=seat.id, quantity=rng.randint(1, 6), unit_price=150, tax_rate=18, sort_order=1))
        start = today - timedelta(days=rng.randint(0, back[pl.billing_cycle])) if status in ("ACTIVE", "PAUSED", "CLOSED") else today + timedelta(days=rng.randint(0, 20))
        expiry = None
        if pl.auto_close:
            expiry = add_cycle(start, "YEARLY")
        elif status == "ACTIVE" and rng.random() < 0.2:
            expiry = today + timedelta(days=rng.randint(4, 26))
        s = Subscription(number=next_number(db, "SUB", "SUB"), customer_id=c.id, plan_id=pl.id, status=status, start_date=start,
                         expiry_date=expiry, payment_terms=rng.choice(list(PAYMENT_TERMS_DAYS)), lines=lines,
                         created_at=start if start < today else today)
        db.add(s)
        db.flush()
        if status in ("ACTIVE", "PAUSED", "CLOSED") and history:
            periods, d = [], start
            while d <= today:
                periods.append(d)
                d = add_cycle(d, pl.billing_cycle)
            leave_due = status == "ACTIVE" and rng.random() < 0.25 and bool(periods)
            billed = periods[:-1] if leave_due else periods
            for ps in billed:
                inv, _n = create_invoice_row(db, db.scalar(select(Subscription).where(Subscription.id == s.id).options(
                    selectinload(Subscription.lines).joinedload(SubscriptionLine.product), joinedload(Subscription.plan))),
                    ps, ps, [], status="CONFIRMED")
                old = (today - ps).days > 45
                if rng.random() < (0.92 if old else 0.65):
                    inv.status, inv.amount_paid, inv.paid_at = "PAID", inv.total, ps + timedelta(days=3)
                    db.add(Payment(number=next_number(db, "PAY", "PAY"), invoice_id=inv.id, customer_id=c.id,
                                   method=rng.choice(METHODS), amount=inv.total, date=min(today, inv.issue_date + timedelta(days=rng.randint(0, 9))),
                                   note=rng.choice([None, "Bank ref received", "Paid via portal link"])))
                    stats["payments"] += 1
            s.next_billing_date = periods[-1] if leave_due else d
            if status == "CLOSED":
                s.next_billing_date, s.closed_at, s.close_reason = None, today - timedelta(days=rng.randint(1, 20)), "Customer request"
            if status == "PAUSED":
                s.next_billing_date = None
        return s

    statuses = ["ACTIVE"] * 12 + ["CLOSED", "PAUSED", "DRAFT", "QUOTATION", "CONFIRMED"]
    for i, (n, e, city, country) in enumerate(names):
        c = make_customer(n, e, city, country)
        for _ in range(1 if i % 3 else 2):
            pl = rng.choice(plans)
            st = rng.choice(statuses)
            if st == "PAUSED" and not pl.can_pause:
                st = "ACTIVE"
            make_sub(c, pl, st)
    db.commit()

    for i in range(bulk):  # load-test data: python main.py seed --bulk 5000
        c = make_customer(f"Bulk Customer {i}", f"bulk{i}@example.com", "Bengaluru", "India", with_user=False)
        make_sub(c, rng.choice([plans[0], plans[1], plans[2]]), "ACTIVE")
        if i % 200 == 199:
            db.commit()
    db.commit()
    cnt = lambda m: db.scalar(select(func.count()).select_from(m))  # noqa: E731
    return {"users": cnt(User), "customers": cnt(Customer), "products": cnt(Product), "plans": cnt(Plan),
            "taxRules": cnt(TaxRule), "discounts": cnt(DiscountRule), "templates": cnt(QuotationTemplate),
            "subscriptions": cnt(Subscription), "invoices": cnt(Invoice), "payments": cnt(Payment)}
