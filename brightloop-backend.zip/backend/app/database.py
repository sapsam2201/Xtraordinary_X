"""Database engine and session factory (SQLite by default, PostgreSQL via DATABASE_URL)."""

import os

from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker


DB_URL = os.getenv("DATABASE_URL", "sqlite:///./brightloop.db")


IS_SQLITE = DB_URL.startswith("sqlite")


engine = create_engine(
    DB_URL,
    connect_args={"check_same_thread": False} if IS_SQLITE else {},
    pool_pre_ping=True,
)


if IS_SQLITE:
    @event.listens_for(engine, "connect")
    def _sqlite_connect(dbapi_conn, _):
        dbapi_conn.isolation_level = None  # we emit BEGIN ourselves (needed for SAVEPOINT)
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA foreign_keys=ON")
        cur.execute("PRAGMA busy_timeout=10000")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.close()

    @event.listens_for(engine, "begin")
    def _sqlite_begin(conn):
        conn.exec_driver_sql("BEGIN")


SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
