"""API routes: subscriptions."""

from datetime import timedelta
from typing import Optional

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from sqlalchemy import delete, func, or_, select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.config import PAYMENT_TERMS_DAYS
from app.deps import Body0, anyone, get_db, staff_or_admin
from app.models import Customer, Invoice, Plan, Product, Subscription, SubscriptionLine, User
from app.serializers import ser_sub
from app.services.billing import bill_now, load_sub_for_billing, next_number
from app.services.lines import clean_lines
from app.utils import ApiError, dump, like, paging, parse_dt, renewal_expiry, start_of_day, today_utc, utcnow


router = APIRouter()


def sub_options():
    return (joinedload(Subscription.customer), joinedload(Subscription.plan), selectinload(Subscription.lines))


def check_ownership(user: User, customer_id: str, what: str):
    if user.role == "CUSTOMER" and customer_id != user.customer_id:
        raise ApiError(403, f"You can only view your own {what}.")


@router.get("/subscriptions")
def list_subscriptions(status: Optional[str] = None, q: Optional[str] = None, customerId: Optional[str] = None,
                       limit: Optional[int] = None, offset: Optional[int] = None,
                       user: User = Depends(anyone), db: Session = Depends(get_db)):
    stmt = select(Subscription).options(*sub_options()).order_by(Subscription.created_at.desc())
    if user.role == "CUSTOMER":
        stmt = stmt.where(Subscription.customer_id == user.customer_id)
    elif customerId:
        stmt = stmt.where(Subscription.customer_id == customerId)
    if status and status != "ALL":
        stmt = stmt.where(Subscription.status == status)
    if q and q.strip():
        stmt = stmt.where(or_(like(Subscription.number, q.strip()),
                              Subscription.customer_id.in_(select(Customer.id).where(like(Customer.name, q.strip())))))
    rows = db.scalars(paging(stmt, limit, offset, 1000)).all()
    counts = dict(db.execute(select(Invoice.subscription_id, func.count()).where(
        Invoice.subscription_id.in_([s.id for s in rows])).group_by(Invoice.subscription_id)).all()) if rows else {}
    return {"subscriptions": [ser_sub(s, counts.get(s.id, 0)) for s in rows]}


@router.post("/subscriptions", status_code=201)
def create_subscription(b: dict = Body0, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    cust = db.get(Customer, str(b.get("customerId") or ""))
    if not cust:
        raise ApiError(400, "Please choose a customer.")
    plan = None
    if b.get("planId"):
        plan = db.get(Plan, b["planId"])
        if not plan:
            raise ApiError(400, "Selected plan not found.")
        now = utcnow()
        if not plan.active:
            raise ApiError(400, "This plan is no longer available.")
        if plan.available_from and now < plan.available_from:
            raise ApiError(400, "This plan is not available yet.")
        if plan.available_to and now > plan.available_to + timedelta(days=1):
            raise ApiError(400, "This plan is no longer available.")
    lines = clean_lines(db, b.get("lines"), require_known_tax=True)
    if not lines:
        raise ApiError(400, "Add at least one product line.")
    if plan and sum(l["quantity"] for l in lines) < plan.min_quantity:
        raise ApiError(400, f"The {plan.name} plan requires at least {plan.min_quantity} unit(s) in total.")
    terms = b.get("paymentTerms") if b.get("paymentTerms") in PAYMENT_TERMS_DAYS else "DUE_ON_RECEIPT"
    start = parse_dt(b.get("startDate")) or today_utc()
    expiry = parse_dt(b.get("expiryDate"))
    if expiry and expiry < start:
        raise ApiError(400, "Expiry date cannot be before the start date.")
    s = Subscription(number=next_number(db, "SUB", "SUB"), customer_id=cust.id, plan_id=plan.id if plan else None,
                     status="DRAFT", start_date=start, expiry_date=expiry, payment_terms=terms,
                     notes=b.get("notes") or None, lines=[SubscriptionLine(**l) for l in lines])
    db.add(s)
    db.commit()
    return {"subscription": ser_sub(load_sub_for_billing(db, s.id))}


@router.get("/subscriptions/{sid}")
def get_subscription(sid: str, user: User = Depends(anyone), db: Session = Depends(get_db)):
    s = db.scalar(select(Subscription).where(Subscription.id == sid).options(
        joinedload(Subscription.customer), joinedload(Subscription.plan),
        selectinload(Subscription.lines).joinedload(SubscriptionLine.product).selectinload(Product.variants),
        selectinload(Subscription.invoices)))
    if not s:
        raise ApiError(404, "Subscription not found.")
    check_ownership(user, s.customer_id, "subscriptions")
    return {"subscription": ser_sub(s, detail=True)}


@router.patch("/subscriptions/{sid}")
def update_subscription(sid: str, b: dict = Body0, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    s = db.get(Subscription, sid)
    if not s:
        raise ApiError(404, "Subscription not found.")
    if s.status != "DRAFT":
        raise ApiError(400, "Only draft subscriptions can be edited.")
    if b.get("customerId"):
        if not db.get(Customer, b["customerId"]):
            raise ApiError(400, "Customer not found.")
        s.customer_id = b["customerId"]
    if "planId" in b:
        s.plan_id = b["planId"] or None
    if b.get("paymentTerms") in PAYMENT_TERMS_DAYS:
        s.payment_terms = b["paymentTerms"]
    if b.get("startDate"):
        s.start_date = parse_dt(b["startDate"])
    if "expiryDate" in b:
        s.expiry_date = parse_dt(b.get("expiryDate"))
    if "notes" in b:
        s.notes = b.get("notes") or None
    if isinstance(b.get("lines"), list) and b["lines"]:
        lines = clean_lines(db, b["lines"], require_known_tax=True)
        db.execute(delete(SubscriptionLine).where(SubscriptionLine.subscription_id == sid))
        db.expire(s, ["lines"])
        s.lines = [SubscriptionLine(**l) for l in lines]
    db.commit()
    return {"subscription": ser_sub(load_sub_for_billing(db, sid))}


@router.delete("/subscriptions/{sid}")
def delete_subscription(sid: str, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    s = db.get(Subscription, sid)
    if not s:
        raise ApiError(404, "Subscription not found.")
    if s.status != "DRAFT":
        raise ApiError(400, "Only draft subscriptions can be deleted.")
    db.delete(s)
    db.commit()
    return {"success": True}


@router.post("/subscriptions/{sid}/invoice", status_code=201)
def bill_subscription_now(sid: str, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    return bill_now(db, sid)


@router.post("/subscriptions/{sid}/transition")
def transition(sid: str, b: dict = Body0, user: User = Depends(anyone), db: Session = Depends(get_db)):
    """Lifecycle: send_quote DRAFT>QUOTATION | confirm >CONFIRMED | activate >ACTIVE | pause | resume | close | renew.
    Staff can do everything; portal customers may only pause / resume / close / renew their *own* subscriptions
    (still subject to the plan's canPause / canCloseEarly / canRenew flags)."""
    action = str(b.get("action") or "")
    s = db.scalar(select(Subscription).where(Subscription.id == sid).options(
        joinedload(Subscription.plan), selectinload(Subscription.lines)))
    if not s:
        raise ApiError(404, "Subscription not found.")
    if user.role == "CUSTOMER":
        if s.customer_id != user.customer_id:
            raise ApiError(403, "You can only manage your own subscriptions.")
        if action not in ("pause", "resume", "close", "renew"):
            raise ApiError(403, "You do not have permission to perform this action.")
    today, plan = today_utc(), s.plan
    if action == "send_quote":
        if s.status != "DRAFT":
            raise ApiError(400, "Only draft subscriptions can be sent as a quotation.")
        s.status = "QUOTATION"
    elif action == "confirm":
        if s.status != "QUOTATION":
            raise ApiError(400, "Only quotations can be confirmed.")
        s.status = "CONFIRMED"
    elif action == "activate":
        if s.status != "CONFIRMED":
            raise ApiError(400, "Confirm the quotation before activating.")
        start = start_of_day(s.start_date)
        s.status = "ACTIVE"
        if plan:  # bill on the start date; if it is already past, bill the current period on the next run
            s.next_billing_date = start if start >= today else today
    elif action == "close":
        if s.status == "CLOSED":
            raise ApiError(400, "This subscription is already closed.")
        if s.status in ("ACTIVE", "PAUSED") and plan and not plan.can_close_early:
            raise ApiError(400, f"The {plan.name} plan does not allow closing early.")
        default_reason = "Cancelled before activation" if s.status in ("DRAFT", "QUOTATION") else (
            "Closed by customer" if user.role == "CUSTOMER" else "Closed by staff")
        s.status, s.closed_at = "CLOSED", utcnow()
        s.close_reason = str(b.get("reason") or default_reason)
    elif action == "pause":
        if s.status != "ACTIVE":
            raise ApiError(400, "Only active subscriptions can be paused.")
        if plan and not plan.can_pause:
            raise ApiError(400, f"The {plan.name} plan cannot be paused.")
        s.status = "PAUSED"
    elif action == "resume":
        if s.status != "PAUSED":
            raise ApiError(400, "This subscription is not paused.")
        s.status = "ACTIVE"  # the paused period is not charged
        if s.next_billing_date is None or s.next_billing_date < today:
            s.next_billing_date = today  # skip missed cycles; a future date keeps its rhythm
    elif action == "renew":
        if plan and not plan.can_renew:
            raise ApiError(400, f"The {plan.name} plan cannot be renewed.")
        if s.status in ("DRAFT", "QUOTATION"):
            raise ApiError(400, "Confirm this subscription before renewing it.")
        if (s.close_reason or "").startswith("Renewed as"):
            raise ApiError(400, "This subscription has already been renewed.")
        base = s.expiry_date if s.expiry_date and s.expiry_date > today else today
        new_start = start_of_day(base)
        new = Subscription(
            number=next_number(db, "SUB", "SUB"), customer_id=s.customer_id, plan_id=s.plan_id, status="CONFIRMED",
            start_date=new_start, expiry_date=renewal_expiry(new_start, plan.billing_cycle) if plan else None,
            payment_terms=s.payment_terms, notes=f"Renewal of {s.number}",
            lines=[SubscriptionLine(product_id=l.product_id, variant_id=l.variant_id, description=l.description,
                                    quantity=l.quantity, unit_price=l.unit_price, tax_rate=l.tax_rate, sort_order=i)
                   for i, l in enumerate(s.lines)])
        db.add(new)
        if s.status in ("ACTIVE", "PAUSED"):
            s.status, s.closed_at, s.close_reason = "CLOSED", utcnow(), f"Renewed as {new.number}"
        db.commit()
        return JSONResponse({"subscription": dump(new), "renewed": True}, status_code=201)
    else:
        raise ApiError(400, f'Unknown action "{action}".')
    db.commit()
    return {"subscription": ser_sub(load_sub_for_billing(db, sid))}
