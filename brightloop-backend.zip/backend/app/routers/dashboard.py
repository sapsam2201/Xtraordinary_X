"""API routes: dashboard."""

from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.deps import get_db, staff_or_admin
from app.models import Customer, Invoice, Payment, Plan, Subscription, SubscriptionLine, User
from app.utils import add_months, jv, monthly_normalized, r2, today_utc


router = APIRouter()


@router.get("/dashboard")
def dashboard(period: str = "this_month", _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    today = today_utc()
    month_start = today.replace(day=1)
    prev_start = add_months(month_start, -1)
    quarter_start = today.replace(month=(today.month - 1) // 3 * 3 + 1, day=1)
    year_start = today.replace(month=1, day=1)
    r_start = {"this_month": month_start, "last_month": prev_start, "quarter": quarter_start, "year": year_start}.get(period)
    r_end = (month_start if period == "last_month" else today + timedelta(days=1))

    def pay_sum(a: Optional[datetime], b: Optional[datetime]) -> float:
        stmt = select(func.coalesce(func.sum(Payment.amount), 0.0))
        if a:
            stmt = stmt.where(Payment.date >= a)
        if b:
            stmt = stmt.where(Payment.date < b)
        return r2(db.scalar(stmt) or 0)

    active = db.scalar(select(func.count()).select_from(Subscription).where(Subscription.status == "ACTIVE"))
    cust_n = db.scalar(select(func.count()).select_from(Customer))
    cycle = func.coalesce(Plan.billing_cycle, "MONTHLY")
    mrr_rows = db.execute(select(cycle, func.sum(SubscriptionLine.quantity * SubscriptionLine.unit_price))
                          .select_from(SubscriptionLine).join(Subscription, Subscription.id == SubscriptionLine.subscription_id)
                          .outerjoin(Plan, Plan.id == Subscription.plan_id).where(Subscription.status == "ACTIVE").group_by(cycle)).all()
    mrr = r2(sum(monthly_normalized(v or 0, c) for c, v in mrr_rows))

    open_n, open_total, open_paid = db.execute(select(func.count(), func.coalesce(func.sum(Invoice.total), 0.0), func.coalesce(func.sum(Invoice.amount_paid), 0.0))
                                               .where(Invoice.status == "CONFIRMED")).one()
    od_n, od_total, od_paid = db.execute(select(func.count(), func.coalesce(func.sum(Invoice.total), 0.0), func.coalesce(func.sum(Invoice.amount_paid), 0.0))
                                         .where(Invoice.status == "CONFIRMED", Invoice.due_date < today)).one()
    inv_status = db.execute(select(Invoice.status, func.count(), func.coalesce(func.sum(Invoice.total), 0.0)).group_by(Invoice.status)).all()
    sub_status = db.execute(select(Subscription.status, func.count()).group_by(Subscription.status)).all()
    by_plan = db.execute(select(Plan.name, func.count(Subscription.id)).join(Subscription, Subscription.plan_id == Plan.id)
                         .where(Subscription.status == "ACTIVE").group_by(Plan.id, Plan.name).order_by(func.count(Subscription.id).desc())).all()

    trend = []
    for i in range(5, -1, -1):
        a = add_months(month_start, -i)
        trend.append({"month": a.strftime("%b"), "revenue": pay_sum(a, add_months(a, 1))})

    recent = db.execute(select(Invoice, Customer.name).join(Customer, Customer.id == Invoice.customer_id)
                        .order_by(Invoice.created_at.desc()).limit(8)).all()
    overdue = db.execute(select(Invoice, Customer.name).join(Customer, Customer.id == Invoice.customer_id)
                         .where(Invoice.status == "CONFIRMED", Invoice.due_date < today).order_by(Invoice.due_date).limit(8)).all()
    renewals = db.execute(select(Subscription, Customer.name, Plan.name, Plan.can_renew).join(Customer, Customer.id == Subscription.customer_id)
                          .outerjoin(Plan, Plan.id == Subscription.plan_id)
                          .where(Subscription.status == "ACTIVE", Subscription.expiry_date >= today,
                                 Subscription.expiry_date <= today + timedelta(days=30)).order_by(Subscription.expiry_date).limit(8)).all()
    return {
        "kpis": {"activeSubscriptions": active, "customers": cust_n, "mrr": mrr,
                 "revenueInPeriod": pay_sum(r_start, r_end if r_start else None),
                 "revenueThisMonth": pay_sum(month_start, None), "revenuePrevMonth": pay_sum(prev_start, month_start),
                 "outstandingTotal": r2(open_total - open_paid), "openInvoices": open_n,
                 "overdueCount": od_n, "overdueAmount": r2(od_total - od_paid)},
        "invoicesByStatus": [{"status": s, "count": n, "total": r2(t)} for s, n, t in inv_status],
        "subscriptionsByStatus": [{"status": s, "count": n} for s, n in sub_status],
        "subsByPlan": [{"plan": p, "count": n} for p, n in by_plan if n > 0],
        "revenueByMonth": trend,
        "recentInvoices": [{"id": i.id, "number": i.number, "customer": c, "status": i.status, "total": i.total,
                            "amountPaid": i.amount_paid, "issueDate": jv(i.issue_date), "dueDate": jv(i.due_date)} for i, c in recent],
        "overdueList": [{"id": i.id, "number": i.number, "customer": c, "total": i.total, "amountPaid": i.amount_paid,
                         "dueDate": jv(i.due_date), "daysOverdue": max(0, (today - i.due_date).days)} for i, c in overdue],
        "upcomingRenewals": [{"id": s.id, "number": s.number, "customer": c, "plan": p or "—",
                              "expiryDate": jv(s.expiry_date), "canRenew": bool(cr)} for s, c, p, cr in renewals],
    }
