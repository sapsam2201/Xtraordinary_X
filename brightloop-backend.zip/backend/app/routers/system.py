"""API routes: system."""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.deps import admin_only, get_db
from app.models import User
from app.seed import run_seed


router = APIRouter()


@router.get("/health")
def health():
    return {"status": "ok"}


@router.post("/seed")
def reseed(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    return {"summary": run_seed(db)}
