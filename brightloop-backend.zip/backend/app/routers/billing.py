"""API routes: billing."""

import hmac
import os
from typing import Optional

from fastapi import APIRouter, Depends, Request
from sqlalchemy import and_, func, select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.deps import get_db, staff_or_admin
from app.models import Customer, Plan, Subscription, User
from app.services.billing import run_billing_day
from app.utils import ApiError, jv, r2, today_utc


router = APIRouter()


@router.get("/billing")
def billing_preview(limit: Optional[int] = None, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    today = today_utc()
    cond = and_(Subscription.status == "ACTIVE", Subscription.next_billing_date <= today)
    total_due = db.scalar(select(func.count()).select_from(Subscription).where(cond))
    subs = db.scalars(select(Subscription).where(cond).options(
        joinedload(Subscription.customer), joinedload(Subscription.plan), selectinload(Subscription.lines)
    ).order_by(Subscription.next_billing_date).limit(min(limit or 500, 2000))).all()
    due = [{"id": s.id, "number": s.number, "customer": s.customer.name, "plan": s.plan.name if s.plan else "—",
            "billingCycle": s.plan.billing_cycle if s.plan else "MONTHLY", "nextBillingDate": jv(s.next_billing_date),
            "estimatedAmount": r2(sum(l.quantity * l.unit_price for l in s.lines)),
            "overdueDays": max(0, (today - s.next_billing_date).days)} for s in subs]
    exp = db.execute(select(Subscription.id, Subscription.number, Customer.name, Plan.name, Subscription.expiry_date)
                     .join(Customer, Customer.id == Subscription.customer_id).join(Plan, Plan.id == Subscription.plan_id)
                     .where(Subscription.status == "ACTIVE", Subscription.expiry_date < today, Plan.auto_close == True)  # noqa: E712
                     .limit(100)).all()
    return {"dueCount": total_due, "due": due, "autoCloseCount": len(exp),
            "autoClose": [{"id": e[0], "number": e[1], "customer": {"name": e[2]}, "plan": {"name": e[3]}, "expiryDate": jv(e[4])} for e in exp]}


@router.post("/billing")
def billing_run(_: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    return run_billing_day(db)


@router.post("/cron/billing")
def billing_cron(req: Request, db: Session = Depends(get_db)):
    secret = os.getenv("CRON_SECRET")
    if not secret or not hmac.compare_digest(req.headers.get("x-cron-secret", ""), secret):
        raise ApiError(401, "Invalid cron secret.")
    return run_billing_day(db)
