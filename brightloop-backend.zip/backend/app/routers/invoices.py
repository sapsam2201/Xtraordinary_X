"""API routes: invoices."""

import os
from typing import Optional

from fastapi import APIRouter, Depends, Request
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.config import demo_mode, upi_settings
from app.deps import Body0, anyone, get_db, staff_or_admin
from app.mailer import send_mail
from app.models import Customer, Invoice, Payment, Subscription, User
from app.serializers import ser_invoice
from app.services.payments import build_upi_uri
from app.database import SessionLocal
from app.utils import ApiError, add_cycle, apply_sort, csv_response, iter_chunks, day_end_exclusive, like, paging, parse_dt, r2, today_utc, utcnow


router = APIRouter()


def inv_visible(stmt, user: User):
    if user.role == "CUSTOMER":  # customers never see drafts
        return stmt.where(Invoice.customer_id == user.customer_id, Invoice.status != "DRAFT")
    return stmt


def _invoice_filters(stmt, user: User, status, q, customerId, frm, to, with_status_q: bool = True):
    stmt = inv_visible(stmt, user)
    if user.role != "CUSTOMER" and customerId:
        stmt = stmt.where(Invoice.customer_id == customerId)
    if frm:
        stmt = stmt.where(Invoice.issue_date >= parse_dt(frm))
    if to:
        stmt = stmt.where(Invoice.issue_date < day_end_exclusive(to))
    if with_status_q:
        if status and status != "ALL":
            stmt = stmt.where(Invoice.status == status)
        if q and q.strip():
            stmt = stmt.where(or_(like(Invoice.number, q.strip()),
                                  Invoice.customer_id.in_(select(Customer.id).where(like(Customer.name, q.strip())))))
    return stmt


_INV_SORT = {
    "number": Invoice.number, "issueDate": Invoice.issue_date, "dueDate": Invoice.due_date,
    "total": Invoice.total, "status": Invoice.status, "balance": Invoice.total - Invoice.amount_paid,
    "customer": select(Customer.name).where(Customer.id == Invoice.customer_id).scalar_subquery(),
}


@router.get("/invoices")
def list_invoices(status: Optional[str] = None, q: Optional[str] = None, customerId: Optional[str] = None,
                  to: Optional[str] = None, limit: Optional[int] = None, offset: Optional[int] = None,
                  sort: Optional[str] = None, dir: Optional[str] = None,
                  user: User = Depends(anyone), db: Session = Depends(get_db), req: Request = None):
    """Paged list. Returns `total` (rows matching the filters) and `summary` (open/overdue figures for the
    date range, independent of the status tab and search box) so the UI never needs to load every invoice."""
    frm = req.query_params.get("from")
    stmt = _invoice_filters(select(Invoice).options(joinedload(Invoice.customer), joinedload(Invoice.subscription)),
                            user, status, q, customerId, frm, to)
    stmt = apply_sort(stmt, sort, dir, _INV_SORT, (Invoice.issue_date.desc(), Invoice.number.desc()))
    count_stmt = _invoice_filters(select(func.count()).select_from(Invoice), user, status, q, customerId, frm, to)
    total = db.scalar(count_stmt) or 0
    rows = db.scalars(paging(stmt, limit, offset, 1000)).all()
    counts = dict(db.execute(select(Payment.invoice_id, func.count()).where(
        Payment.invoice_id.in_([i.id for i in rows])).group_by(Payment.invoice_id)).all()) if rows else {}
    base = _invoice_filters(select(func.count(), func.coalesce(func.sum(Invoice.total - Invoice.amount_paid), 0.0))
                            .select_from(Invoice), user, None, None, customerId, frm, to, with_status_q=False)
    open_n, open_amt = db.execute(base.where(Invoice.status == "CONFIRMED")).one()
    od_n, od_amt = db.execute(base.where(Invoice.status == "CONFIRMED", Invoice.due_date < today_utc())).one()
    return {"invoices": [ser_invoice(i, "list", counts.get(i.id, 0)) for i in rows], "total": total,
            "summary": {"openCount": open_n, "openAmount": r2(open_amt), "overdueCount": od_n, "overdueAmount": r2(od_amt)}}


@router.get("/invoices.csv")
def export_invoices(status: Optional[str] = None, q: Optional[str] = None, customerId: Optional[str] = None,
                    to: Optional[str] = None, overdue: bool = False,
                    user: User = Depends(anyone), db: Session = Depends(get_db), req: Request = None):
    """CSV export of the invoices matching the current filters (finance lead / accountants)."""
    frm = req.query_params.get("from")
    stmt = _invoice_filters(select(Invoice).options(joinedload(Invoice.customer)), user, status, q, customerId, frm, to)
    if overdue:
        stmt = stmt.where(Invoice.status == "CONFIRMED", Invoice.due_date < today_utc())
    stmt = stmt.order_by(Invoice.issue_date.desc(), Invoice.number.desc())

    def rows():
        today = today_utc()
        with SessionLocal() as s2:  # own session: the request's session may be closed before streaming starts
          for i in iter_chunks(s2, stmt):
            od = i.status == "CONFIRMED" and i.due_date < today
            yield [i.number, i.customer.name, i.status, "YES" if od else "NO", i.issue_date.date(), i.due_date.date(),
                   f"{i.subtotal:.2f}", f"{i.discount_total:.2f}", f"{i.tax_total:.2f}", f"{i.total:.2f}",
                   f"{i.amount_paid:.2f}", f"{(0 if i.status == 'CANCELLED' else i.total - i.amount_paid):.2f}"]
    return csv_response("invoices.csv", ["Invoice", "Customer", "Status", "Overdue", "Issued", "Due", "Subtotal",
                                         "Discount", "Tax", "Total", "Paid", "Balance"], rows())


@router.get("/invoices/{iid}")
def get_invoice(iid: str, user: User = Depends(anyone), db: Session = Depends(get_db)):
    i = db.scalar(select(Invoice).where(Invoice.id == iid).options(
        joinedload(Invoice.customer), joinedload(Invoice.subscription).joinedload(Subscription.plan),
        selectinload(Invoice.lines), selectinload(Invoice.payments)))
    if not i:
        raise ApiError(404, "Invoice not found.")
    if user.role == "CUSTOMER" and (i.customer_id != user.customer_id or i.status == "DRAFT"):
        raise ApiError(403, "You can only view your own invoices.")
    return {"invoice": ser_invoice(i, "detail")}


@router.get("/invoices/{iid}/upi")
def invoice_upi(iid: str, user: User = Depends(anyone), db: Session = Depends(get_db)):
    """Payment QR payload for an open invoice: the UPI link (render it as a QR) plus display details."""
    i = db.scalar(select(Invoice).where(Invoice.id == iid).options(joinedload(Invoice.customer)))
    if not i:
        raise ApiError(404, "Invoice not found.")
    if user.role == "CUSTOMER" and (i.customer_id != user.customer_id or i.status == "DRAFT"):
        raise ApiError(403, "You can only pay your own invoices.")
    if i.status != "CONFIRMED":
        raise ApiError(400, "This invoice is already settled." if i.status == "PAID" else "Only confirmed invoices can be paid.")
    balance = r2(i.total - i.amount_paid)
    if balance <= 0:
        raise ApiError(400, "This invoice has no outstanding balance.")
    cfg = upi_settings()
    if not cfg:
        raise ApiError(503, "UPI payments are not set up yet. Please contact our team.")
    return {
        "upiUri": build_upi_uri(cfg["vpa"], cfg["name"], balance, i.number, f"{i.number} {i.customer.name}"),
        "upiId": cfg["vpa"], "payee": cfg["name"], "amount": balance, "currency": "INR", "reference": i.number,
        "placeholder": cfg["placeholder"],
        # portal customers may confirm their own payment only in demo mode; otherwise staff verify it
        "selfConfirm": bool(demo_mode() or os.getenv("ALLOW_CUSTOMER_SELF_PAY") == "1"),
    }


@router.post("/invoices/{iid}/action")
def invoice_action(iid: str, b: dict = Body0, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    """confirm DRAFT>CONFIRMED | send (e-mail the customer) | cancel (only while nothing is paid)."""
    action = str(b.get("action") or "")
    i = db.scalar(select(Invoice).where(Invoice.id == iid).options(joinedload(Invoice.customer)))
    if not i:
        raise ApiError(404, "Invoice not found.")
    if action == "confirm":
        if i.status != "DRAFT":
            raise ApiError(400, "Only draft invoices can be confirmed.")
        i.status = "CONFIRMED"
    elif action == "send":
        if i.status == "CANCELLED":
            raise ApiError(400, "This invoice was cancelled.")
        if i.status == "DRAFT":
            raise ApiError(400, "Confirm the invoice before sending it.")
        send_mail(i.customer.email, f"Invoice {i.number} from Brightloop",
                  f"Hi {i.customer.name},\n\nInvoice {i.number} for {i.total:,.2f} is due on {i.due_date:%d %b %Y}.\n\nThank you,\nBrightloop")
        i.sent_at = utcnow()
    elif action == "cancel":
        if i.status == "PAID":
            raise ApiError(400, "A paid invoice cannot be cancelled.")
        if i.status == "CANCELLED":
            raise ApiError(400, "This invoice is already cancelled.")
        if i.amount_paid > 0:
            raise ApiError(400, "Payments exist against this invoice; refund them first.")
        i.status = "CANCELLED"
        # If this was the latest invoiced period, rewind the schedule so billing day re-issues it.
        if i.subscription_id and i.period_start:
            sub = db.scalar(select(Subscription).where(Subscription.id == i.subscription_id).options(joinedload(Subscription.plan)))
            if sub and sub.status == "ACTIVE" and sub.plan and sub.next_billing_date == add_cycle(i.period_start, sub.plan.billing_cycle):
                sub.next_billing_date = i.period_start
    else:
        raise ApiError(400, f'Unknown action "{action}".')
    db.commit()
    full = db.scalar(select(Invoice).where(Invoice.id == iid).options(
        joinedload(Invoice.customer), selectinload(Invoice.lines), selectinload(Invoice.payments)))
    return {"invoice": ser_invoice(full, "action")}
