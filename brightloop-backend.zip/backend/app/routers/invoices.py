"""API routes: invoices."""

from typing import Optional

from fastapi import APIRouter, Depends, Request
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.deps import Body0, anyone, get_db, staff_or_admin
from app.mailer import send_mail
from app.models import Customer, Invoice, Payment, Subscription, User
from app.serializers import ser_invoice
from app.utils import ApiError, add_cycle, day_end_exclusive, like, paging, parse_dt, utcnow


router = APIRouter()


def inv_visible(stmt, user: User):
    if user.role == "CUSTOMER":  # customers never see drafts
        return stmt.where(Invoice.customer_id == user.customer_id, Invoice.status != "DRAFT")
    return stmt


@router.get("/invoices")
def list_invoices(status: Optional[str] = None, q: Optional[str] = None, customerId: Optional[str] = None,
                  to: Optional[str] = None, limit: Optional[int] = None, offset: Optional[int] = None,
                  user: User = Depends(anyone), db: Session = Depends(get_db), req: Request = None):
    frm = req.query_params.get("from")
    stmt = inv_visible(select(Invoice).options(joinedload(Invoice.customer), joinedload(Invoice.subscription))
                       .order_by(Invoice.issue_date.desc(), Invoice.number.desc()), user)
    if user.role != "CUSTOMER" and customerId:
        stmt = stmt.where(Invoice.customer_id == customerId)
    if status and status != "ALL":
        stmt = stmt.where(Invoice.status == status)
    if frm:
        stmt = stmt.where(Invoice.issue_date >= parse_dt(frm))
    if to:
        stmt = stmt.where(Invoice.issue_date < day_end_exclusive(to))
    if q and q.strip():
        stmt = stmt.where(or_(like(Invoice.number, q.strip()),
                              Invoice.customer_id.in_(select(Customer.id).where(like(Customer.name, q.strip())))))
    rows = db.scalars(paging(stmt, limit, offset, 1000)).all()
    counts = dict(db.execute(select(Payment.invoice_id, func.count()).where(
        Payment.invoice_id.in_([i.id for i in rows])).group_by(Payment.invoice_id)).all()) if rows else {}
    return {"invoices": [ser_invoice(i, "list", counts.get(i.id, 0)) for i in rows]}


@router.get("/invoices/{iid}")
def get_invoice(iid: str, user: User = Depends(anyone), db: Session = Depends(get_db)):
    i = db.scalar(select(Invoice).where(Invoice.id == iid).options(
        joinedload(Invoice.customer), joinedload(Invoice.subscription).joinedload(Subscription.plan),
        selectinload(Invoice.lines), selectinload(Invoice.payments)))
    if not i:
        raise ApiError(404, "Invoice not found.")
    if user.role == "CUSTOMER" and (i.customer_id != user.customer_id or i.status == "DRAFT"):
        raise ApiError(403, "You can only view your own invoices.")
    return {"invoice": ser_invoice(i, "detail")}


@router.post("/invoices/{iid}/action")
def invoice_action(iid: str, b: dict = Body0, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    """confirm DRAFT>CONFIRMED | send (e-mail the customer) | cancel (only while nothing is paid)."""
    action = str(b.get("action") or "")
    i = db.scalar(select(Invoice).where(Invoice.id == iid).options(joinedload(Invoice.customer)))
    if not i:
        raise ApiError(404, "Invoice not found.")
    if action == "confirm":
        if i.status != "DRAFT":
            raise ApiError(400, "Only draft invoices can be confirmed.")
        i.status = "CONFIRMED"
    elif action == "send":
        if i.status == "CANCELLED":
            raise ApiError(400, "This invoice was cancelled.")
        if i.status == "DRAFT":
            raise ApiError(400, "Confirm the invoice before sending it.")
        send_mail(i.customer.email, f"Invoice {i.number} from Brightloop",
                  f"Hi {i.customer.name},\n\nInvoice {i.number} for {i.total:,.2f} is due on {i.due_date:%d %b %Y}.\n\nThank you,\nBrightloop")
        i.sent_at = utcnow()
    elif action == "cancel":
        if i.status == "PAID":
            raise ApiError(400, "A paid invoice cannot be cancelled.")
        if i.status == "CANCELLED":
            raise ApiError(400, "This invoice is already cancelled.")
        if i.amount_paid > 0:
            raise ApiError(400, "Payments exist against this invoice; refund them first.")
        i.status = "CANCELLED"
        # If this was the latest invoiced period, rewind the schedule so billing day re-issues it.
        if i.subscription_id and i.period_start:
            sub = db.scalar(select(Subscription).where(Subscription.id == i.subscription_id).options(joinedload(Subscription.plan)))
            if sub and sub.status == "ACTIVE" and sub.plan and sub.next_billing_date == add_cycle(i.period_start, sub.plan.billing_cycle):
                sub.next_billing_date = i.period_start
    else:
        raise ApiError(400, f'Unknown action "{action}".')
    db.commit()
    full = db.scalar(select(Invoice).where(Invoice.id == iid).options(
        joinedload(Invoice.customer), selectinload(Invoice.lines), selectinload(Invoice.payments)))
    return {"invoice": ser_invoice(full, "action")}
