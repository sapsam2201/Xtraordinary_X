"""API routes: products."""

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.deps import Body0, admin_only, get_db, staff_or_admin
from app.models import DiscountRule, Plan, Product, ProductVariant, SubscriptionLine, TemplateLine, User
from app.serializers import ser_product
from app.utils import ApiError, money


router = APIRouter()


def apply_variants(db: Session, p: Product, incoming: list):
    incoming = [v for v in incoming if isinstance(v, dict) and str(v.get("value") or "").strip()]
    keep = {v["id"] for v in incoming if v.get("id")}
    for v in list(p.variants):
        if v.id not in keep:
            p.variants.remove(v)
    existing = {v.id: v for v in p.variants}
    for v in incoming:
        vals = dict(name=str(v.get("name") or "Variant").strip() or "Variant", value=str(v["value"]).strip(),
                    price_delta=float(v.get("priceDelta") or 0))
        if v.get("id") in existing:
            for k, x in vals.items():
                setattr(existing[v["id"]], k, x)
        else:
            p.variants.append(ProductVariant(**vals))


@router.get("/products")
def list_products(_: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    rows = db.scalars(select(Product).options(selectinload(Product.variants)).order_by(Product.created_at)).all()
    counts = dict(db.execute(select(SubscriptionLine.product_id, func.count()).group_by(SubscriptionLine.product_id)).all())
    return {"products": [ser_product(p, counts.get(p.id, 0)) for p in rows]}


@router.post("/products", status_code=201)
def create_product(b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    name = str(b.get("name") or "").strip()
    if not name:
        raise ApiError(400, "Product name is required.")
    p = Product(name=name, type=b.get("type") if b.get("type") in ("SOFTWARE", "ADDON", "SERVICE") else "SOFTWARE",
                sales_price=money(b.get("salesPrice"), "Sales price"), cost_price=money(b.get("costPrice"), "Cost price"),
                notes=b.get("notes") or None)
    db.add(p)
    apply_variants(db, p, b.get("variants") if isinstance(b.get("variants"), list) else [])
    db.commit()
    return {"product": ser_product(p)}


@router.patch("/products/{pid}")
def update_product(pid: str, b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if not p:
        raise ApiError(404, "Product not found.")
    if isinstance(b.get("name"), str) and b["name"].strip():
        p.name = b["name"].strip()
    if b.get("type") in ("SOFTWARE", "ADDON", "SERVICE"):
        p.type = b["type"]
    if b.get("salesPrice") is not None:
        p.sales_price = money(b["salesPrice"], "Sales price")
    if b.get("costPrice") is not None:
        p.cost_price = money(b["costPrice"], "Cost price")
    if "notes" in b:
        p.notes = b["notes"] or None
    if isinstance(b.get("active"), bool):
        p.active = b["active"]
    if isinstance(b.get("variants"), list):
        apply_variants(db, p, b["variants"])
    db.commit()
    return {"product": ser_product(p)}


@router.delete("/products/{pid}")
def delete_product(pid: str, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if not p:
        raise ApiError(404, "Product not found.")
    used = sum(db.scalar(select(func.count()).select_from(m).where(m.product_id == pid)) for m in
               (SubscriptionLine, TemplateLine, Plan, DiscountRule))
    if used:  # keep history intact: archive instead of delete
        p.active = False
        db.commit()
        return {"product": ser_product(p), "archived": True}
    db.delete(p)
    db.commit()
    return {"success": True}
