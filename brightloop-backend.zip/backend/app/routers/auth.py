"""API routes: auth."""

import os
import secrets
import time
from datetime import timedelta

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import delete, func, select, update
from sqlalchemy.orm import Session

from app.config import SESSION_COOKIE, demo_mode, log
from app.deps import Body0, any_user, get_db, open_session, request_token, safe_user, session_user
from app.mailer import send_mail
from app.models import AuthSession, Customer, PasswordResetToken, User
from app.security import _fails, _throttle_key, hash_password, password_error, rate_limit, valid_email, verify_password
from app.seed import run_seed
from app.utils import ApiError, utcnow


router = APIRouter()


@router.post("/auth/register", status_code=201)
def register(req: Request, response: Response, b: dict = Body0, db: Session = Depends(get_db)):
    rate_limit(req, "register", 20)
    name = str(b.get("name") or "").strip()
    email = str(b.get("email") or "").strip().lower()
    pw = str(b.get("password") or "")
    if not name:
        raise ApiError(400, "Please enter your name.")
    if not valid_email(email):
        raise ApiError(400, "Please enter a valid email address.")
    if err := password_error(pw):
        raise ApiError(400, err)
    if db.scalar(select(User.id).where(User.email == email)) or db.scalar(select(Customer.id).where(Customer.email == email)):
        raise ApiError(409, "This email already belongs to an account.")
    cust = Customer(name=name, email=email)
    db.add(cust)
    db.flush()
    user = User(email=email, name=name, role="CUSTOMER", password_hash=hash_password(pw), customer_id=cust.id)
    db.add(user)
    db.commit()
    return {"token": open_session(db, user, response), "user": safe_user(user)}


@router.post("/auth/login")
def login(req: Request, response: Response, b: dict = Body0, db: Session = Depends(get_db)):
    email = str(b.get("email") or "").strip().lower()
    pw = str(b.get("password") or "")
    if not email or not pw:
        raise ApiError(400, "Email and password are required.")
    key = _throttle_key(req, email)
    fails = [t for t in _fails.get(key, []) if t > time.time() - 900]
    if len(fails) >= 10:
        raise ApiError(429, "Too many failed attempts. Try again in a few minutes.")
    if demo_mode() and db.scalar(select(func.count()).select_from(User)) == 0:  # self-healing demo database
        run_seed(db)
    user = db.scalar(select(User).where(User.email == email))
    if not user or not verify_password(pw, user.password_hash):
        _fails[key] = fails + [time.time()]
        raise ApiError(401, "Incorrect email or password.")
    if not user.is_active:
        raise ApiError(403, "This account has been deactivated. Contact your admin.")
    _fails.pop(key, None)
    return {"token": open_session(db, user, response), "user": safe_user(user)}


@router.post("/auth/logout")
def logout(req: Request, response: Response, db: Session = Depends(get_db)):
    token = request_token(req)
    if token:
        db.execute(delete(AuthSession).where(AuthSession.token == token))
        db.commit()
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"success": True}


@router.get("/auth/me")
def me(req: Request, db: Session = Depends(get_db)):
    u = session_user(req, db)
    if not u:
        return {"user": None}
    d = safe_user(u)
    d["customerName"] = u.customer.name if u.customer else None
    return {"user": d}


@router.post("/auth/forgot")
def forgot(req: Request, b: dict = Body0, db: Session = Depends(get_db)):
    rate_limit(req, "forgot", 10)
    email = str(b.get("email") or "").strip().lower()
    if not valid_email(email):
        raise ApiError(400, "Please enter a valid email address.")
    generic = {"sent": True, "resetUrl": None}  # identical answer whether or not the account exists
    user = db.scalar(select(User).where(User.email == email))
    if not user or not user.is_active:
        return generic
    token = secrets.token_hex(24)
    db.add(PasswordResetToken(token=token, user_id=user.id, expires_at=utcnow() + timedelta(hours=1)))
    db.commit()
    url = f"/?reset={token}"
    base = os.getenv("PUBLIC_URL", "http://localhost:3000")
    if send_mail(user.email, "Reset your Brightloop password",
                 f"Hi {user.name},\n\nUse this link within one hour to choose a new password:\n{base}{url}\n"):
        return generic
    if demo_mode():  # no SMTP configured: only the demo shows the link on screen
        return {"sent": True, "resetUrl": url, "simulated": True}
    log.warning("password reset requested for %s but SMTP is not configured", email)
    return generic


@router.post("/auth/reset")
def reset(b: dict = Body0, db: Session = Depends(get_db)):
    token, pw = str(b.get("token") or ""), str(b.get("password") or "")
    if err := password_error(pw):
        raise ApiError(400, err)
    rec = db.scalar(select(PasswordResetToken).where(PasswordResetToken.token == token))
    if not rec or rec.used_at or rec.expires_at < utcnow():
        raise ApiError(400, "This reset link is invalid or has expired. Request a new one.")
    db.execute(update(User).where(User.id == rec.user_id).values(password_hash=hash_password(pw)))
    rec.used_at = utcnow()
    db.execute(delete(AuthSession).where(AuthSession.user_id == rec.user_id))
    db.commit()
    return {"success": True}


@router.put("/auth/password")
def change_password(b: dict = Body0, user: User = Depends(any_user), db: Session = Depends(get_db)):
    if not verify_password(str(b.get("current") or ""), user.password_hash):
        raise ApiError(400, "Your current password is incorrect.")
    nxt = str(b.get("next") or "")
    if err := password_error(nxt):
        raise ApiError(400, err)
    user.password_hash = hash_password(nxt)
    db.merge(user)
    db.commit()
    return {"success": True}
