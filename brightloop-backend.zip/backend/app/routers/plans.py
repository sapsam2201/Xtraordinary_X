"""API routes: plans."""

import re

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload

from app.config import CYCLES
from app.deps import Body0, admin_only, anyone, get_db
from app.models import Plan, Product, QuotationTemplate, Subscription, User
from app.serializers import ser_plan
from app.utils import ApiError, dump, money, parse_dt


router = APIRouter()


def plan_fields(b: dict, db: Session, partial: bool) -> dict:
    out: dict = {}
    if not partial or (isinstance(b.get("name"), str) and b["name"].strip()):
        if not str(b.get("name") or "").strip():
            raise ApiError(400, "Plan name is required.")
        out["name"] = b["name"].strip()
    if not partial or b.get("price") is not None:
        out["price"] = money(b.get("price"), "Plan price")
    if not partial or b.get("billingCycle"):
        if b.get("billingCycle") not in CYCLES:
            if not partial:
                raise ApiError(400, "Billing cycle must be daily, weekly, monthly or yearly.")
        else:
            out["billing_cycle"] = b["billingCycle"]
    if not partial or b.get("minQuantity") is not None:
        out["min_quantity"] = max(1, int(float(b.get("minQuantity") or 1)))
    if not partial or "description" in b:
        out["description"] = b.get("description") or None
    if not partial or "productId" in b:
        pid = b.get("productId") or None
        if pid and not db.get(Product, pid):
            raise ApiError(400, "Linked product not found.")
        out["product_id"] = pid
    if not partial or "availableFrom" in b:
        out["available_from"] = parse_dt(b.get("availableFrom"))
    if not partial or "availableTo" in b:
        out["available_to"] = parse_dt(b.get("availableTo"))
    for flag in ("autoClose", "canCloseEarly", "canPause", "canRenew", "active"):
        if not partial:
            if flag != "active":
                out[re.sub(r"([A-Z])", lambda m: "_" + m.group(1).lower(), flag)] = bool(b.get(flag))
        elif isinstance(b.get(flag), bool):
            out[re.sub(r"([A-Z])", lambda m: "_" + m.group(1).lower(), flag)] = b[flag]
    return out


@router.get("/plans")
def list_plans(user: User = Depends(anyone), db: Session = Depends(get_db)):
    rows = db.scalars(select(Plan).options(joinedload(Plan.product)).order_by(Plan.created_at)).all()
    if user.role == "CUSTOMER":  # catalogue view for the portal
        return {"plans": [{"id": p.id, "name": p.name, "description": p.description,
                           "product": {"name": p.product.name} if p.product else None,
                           "price": p.price, "billingCycle": p.billing_cycle} for p in rows if p.active]}
    counts = dict(db.execute(select(Subscription.plan_id, func.count()).group_by(Subscription.plan_id)).all())
    return {"plans": [ser_plan(p, counts.get(p.id, 0)) for p in rows]}


@router.post("/plans", status_code=201)
def create_plan(b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    f = plan_fields(b, db, partial=False)
    if f["available_from"] and f["available_to"] and f["available_to"] < f["available_from"]:
        raise ApiError(400, "The plan cannot end before it starts.")
    p = Plan(**f)
    db.add(p)
    db.commit()
    db.refresh(p)
    return {"plan": ser_plan(p)}


@router.patch("/plans/{pid}")
def update_plan(pid: str, b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Plan, pid)
    if not p:
        raise ApiError(404, "Plan not found.")
    for k, v in plan_fields(b, db, partial=True).items():
        setattr(p, k, v)
    db.commit()
    db.refresh(p)
    return {"plan": ser_plan(p)}


@router.delete("/plans/{pid}")
def delete_plan(pid: str, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Plan, pid)
    if not p:
        raise ApiError(404, "Plan not found.")
    if db.scalar(select(func.count()).select_from(Subscription).where(Subscription.plan_id == pid)) or \
       db.scalar(select(func.count()).select_from(QuotationTemplate).where(QuotationTemplate.plan_id == pid)):
        p.active = False
        db.commit()
        return {"plan": dump(p), "archived": True}
    db.delete(p)
    db.commit()
    return {"success": True}
