"""API routes: payments."""

import os
from typing import Optional

from fastapi import APIRouter, Depends, Request
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload

from app.config import METHODS, demo_mode
from app.deps import Body0, anyone, get_db
from app.models import Customer, Invoice, Payment, User
from app.serializers import ser_payment
from app.services.payments import record_payment
from app.database import SessionLocal
from app.utils import ApiError, apply_sort, csv_response, iter_chunks, day_end_exclusive, like, paging, parse_dt, r2


router = APIRouter()


def _payment_filters(stmt, user: User, method, q, frm, to):
    if user.role == "CUSTOMER":
        stmt = stmt.where(Payment.customer_id == user.customer_id)
    if method and method != "ALL":
        stmt = stmt.where(Payment.method == method)
    if frm:
        stmt = stmt.where(Payment.date >= parse_dt(frm))
    if to:
        stmt = stmt.where(Payment.date < day_end_exclusive(to))
    if q and q.strip():
        q = q.strip()
        stmt = stmt.where(or_(like(Payment.number, q),
                              Payment.invoice_id.in_(select(Invoice.id).where(like(Invoice.number, q))),
                              Payment.customer_id.in_(select(Customer.id).where(like(Customer.name, q)))))
    return stmt


_PAY_SORT = {
    "number": Payment.number, "date": Payment.date, "amount": Payment.amount, "method": Payment.method,
    "invoice": select(Invoice.number).where(Invoice.id == Payment.invoice_id).scalar_subquery(),
    "customer": select(Customer.name).where(Customer.id == Payment.customer_id).scalar_subquery(),
}


@router.get("/payments")
def list_payments(method: Optional[str] = None, q: Optional[str] = None, to: Optional[str] = None,
                  limit: Optional[int] = None, offset: Optional[int] = None,
                  sort: Optional[str] = None, dir: Optional[str] = None,
                  user: User = Depends(anyone), db: Session = Depends(get_db), req: Request = None):
    """Paged list with `total` and `totalAmount` for the whole filtered set (not just the current page)."""
    frm = req.query_params.get("from")
    stmt = _payment_filters(select(Payment).options(joinedload(Payment.invoice), joinedload(Payment.customer)),
                            user, method, q, frm, to)
    stmt = apply_sort(stmt, sort, dir, _PAY_SORT, (Payment.date.desc(), Payment.number.desc()))
    n, amt = db.execute(_payment_filters(select(func.count(), func.coalesce(func.sum(Payment.amount), 0.0))
                                         .select_from(Payment), user, method, q, frm, to)).one()
    return {"payments": [ser_payment(p) for p in db.scalars(paging(stmt, limit, offset, 1000))],
            "total": n, "totalAmount": r2(amt)}


@router.get("/payments.csv")
def export_payments(method: Optional[str] = None, q: Optional[str] = None, to: Optional[str] = None,
                    user: User = Depends(anyone), db: Session = Depends(get_db), req: Request = None):
    frm = req.query_params.get("from")
    stmt = _payment_filters(select(Payment).options(joinedload(Payment.invoice), joinedload(Payment.customer)),
                            user, method, q, frm, to).order_by(Payment.date.desc(), Payment.number.desc())

    def rows():
        with SessionLocal() as s2:
          for p in iter_chunks(s2, stmt):
            yield [p.number, p.date.date(), p.invoice.number, p.customer.name, p.method, f"{p.amount:.2f}", p.note or ""]
    return csv_response("payments.csv", ["Payment", "Date", "Invoice", "Customer", "Method", "Amount", "Note"], rows())


@router.post("/payments", status_code=201)
def create_payment(b: dict = Body0, user: User = Depends(anyone), db: Session = Depends(get_db)):
    # Staff record payments. Letting customers self-report a payment would let anyone mark an
    # invoice paid without paying, so portal payments need a gateway webhook (see README).
    if user.role == "CUSTOMER" and not (demo_mode() or os.getenv("ALLOW_CUSTOMER_SELF_PAY") == "1"):
        raise ApiError(403, "Payments are recorded by our team once funds arrive.")
    invoice_id = str(b.get("invoiceId") or "")
    method = b.get("method") if b.get("method") in METHODS else None
    try:
        amount = float(b.get("amount"))
    except (TypeError, ValueError):
        amount = 0
    if not invoice_id:
        raise ApiError(400, "Choose the invoice this payment belongs to.")
    if not method:
        raise ApiError(400, "Choose a payment method.")
    if not amount > 0:
        raise ApiError(400, "Payment amount must be a positive number.")
    if user.role == "CUSTOMER":
        inv = db.get(Invoice, invoice_id)
        if not inv or inv.customer_id != user.customer_id:
            raise ApiError(403, "You can only pay your own invoices.")
    return record_payment(db, invoice_id, method, amount, parse_dt(b.get("date")), b.get("note") or None)
