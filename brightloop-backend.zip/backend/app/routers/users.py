"""API routes: users."""

from fastapi import APIRouter, Depends
from sqlalchemy import delete, select
from sqlalchemy.orm import Session, joinedload

from app.deps import Body0, admin_only, get_db, staff_or_admin
from app.models import AuthSession, User
from app.security import hash_password, password_error, valid_email
from app.utils import ApiError, jv


router = APIRouter()


def ser_user(u: User) -> dict:
    return {"id": u.id, "email": u.email, "name": u.name, "role": u.role, "isActive": u.is_active,
            "createdAt": jv(u.created_at), "customerId": u.customer_id,
            "customer": {"name": u.customer.name} if u.customer else None}


@router.get("/users")
def list_users(_: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    rows = db.scalars(select(User).options(joinedload(User.customer)).order_by(User.created_at.desc())).all()
    return {"users": [ser_user(u) for u in rows]}


@router.post("/users", status_code=201)
def create_user(b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    name = str(b.get("name") or "").strip()
    email = str(b.get("email") or "").strip().lower()
    pw = str(b.get("password") or "")
    role = "ADMIN" if b.get("role") == "ADMIN" else "STAFF"
    if not name:
        raise ApiError(400, "Name is required.")
    if not valid_email(email):
        raise ApiError(400, "Please enter a valid email address.")
    if err := password_error(pw):
        raise ApiError(400, err)
    if db.scalar(select(User.id).where(User.email == email)):
        raise ApiError(409, "This email already belongs to an account.")
    u = User(name=name, email=email, role=role, password_hash=hash_password(pw))
    db.add(u)
    db.commit()
    return {"user": ser_user(u)}


@router.patch("/users/{uid}")
def update_user(uid: str, b: dict = Body0, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if not u:
        raise ApiError(404, "User not found.")
    if isinstance(b.get("isActive"), bool):
        if u.id == admin.id and not b["isActive"]:
            raise ApiError(400, "You cannot deactivate your own account.")
        u.is_active = b["isActive"]
        if not u.is_active:
            db.execute(delete(AuthSession).where(AuthSession.user_id == u.id))
    if isinstance(b.get("name"), str) and b["name"].strip():
        u.name = b["name"].strip()
    db.commit()
    return {"user": ser_user(u)}


@router.delete("/users/{uid}")
def delete_user(uid: str, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    if uid == admin.id:
        raise ApiError(400, "You cannot remove your own account.")
    u = db.get(User, uid)
    if not u:
        raise ApiError(404, "User not found.")
    db.delete(u)
    db.commit()
    return {"success": True}
