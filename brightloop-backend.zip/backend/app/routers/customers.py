"""API routes: customers."""

import re
from typing import Optional

from fastapi import APIRouter, Depends
from sqlalchemy import delete, func, or_, select, update
from sqlalchemy.orm import Session, joinedload

from app.deps import Body0, get_db, staff_or_admin
from app.models import Customer, Invoice, Payment, Subscription, User
from app.security import valid_email
from app.utils import ApiError, camel, dump, like, paging


router = APIRouter()


def customer_counts(db: Session, ids: list) -> dict:
    out = {i: {"subscriptions": 0, "invoices": 0, "payments": 0} for i in ids}
    for model, key in ((Subscription, "subscriptions"), (Invoice, "invoices"), (Payment, "payments")):
        for cid, n in db.execute(select(model.customer_id, func.count()).where(model.customer_id.in_(ids)).group_by(model.customer_id)):
            out[cid][key] = n
    return out


@router.get("/customers")
def list_customers(q: Optional[str] = None, limit: Optional[int] = None, offset: Optional[int] = None,
                   _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    stmt = select(Customer).order_by(Customer.name)
    if q and q.strip():
        q = q.strip()
        stmt = stmt.where(or_(like(Customer.name, q), like(Customer.email, q), like(Customer.city, q)))
    rows = db.scalars(paging(stmt, limit, offset, 500)).all()
    counts = customer_counts(db, [c.id for c in rows])
    return {"customers": [{**dump(c), "_count": {k: v for k, v in counts[c.id].items() if k != "payments"}} for c in rows]}


@router.post("/customers", status_code=201)
def create_customer(b: dict = Body0, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    name = str(b.get("name") or "").strip()
    email = str(b.get("email") or "").strip().lower()
    if not name:
        raise ApiError(400, "Customer name is required.")
    if not valid_email(email):
        raise ApiError(400, "Please enter a valid email address.")
    if db.scalar(select(Customer.id).where(Customer.email == email)):
        raise ApiError(409, "A customer with this email already exists.")
    c = Customer(name=name, email=email, **{k: (b.get(camel(k)) or None) for k in
                 ("phone", "company", "address", "city", "country", "tax_id", "notes")})
    db.add(c)
    db.commit()
    return {"customer": dump(c)}


@router.get("/customers/{cid}")
def get_customer(cid: str, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    c = db.get(Customer, cid)
    if not c:
        raise ApiError(404, "Customer not found.")
    subs = db.scalars(select(Subscription).where(Subscription.customer_id == cid).options(joinedload(Subscription.plan))
                      .order_by(Subscription.created_at.desc())).all()
    invs = db.scalars(select(Invoice).where(Invoice.customer_id == cid).order_by(Invoice.issue_date.desc()).limit(20)).all()
    d = dump(c)
    d["subscriptions"] = [{**dump(s), "plan": {"name": s.plan.name, "billingCycle": s.plan.billing_cycle} if s.plan else None} for s in subs]
    d["invoices"] = [dump(i) for i in invs]
    d["_count"] = customer_counts(db, [cid])[cid]
    return {"customer": d}


@router.patch("/customers/{cid}")
def update_customer(cid: str, b: dict = Body0, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    c = db.get(Customer, cid)
    if not c:
        raise ApiError(404, "Customer not found.")
    for key in ("name", "email", "phone", "company", "address", "city", "country", "taxId", "notes"):
        if key in b:
            val = b[key] or None
            if key == "email" and val:
                val = str(val).strip().lower()
                if db.scalar(select(Customer.id).where(Customer.email == val, Customer.id != cid)):
                    raise ApiError(409, "Another customer already uses this email.")
            setattr(c, re.sub(r"([A-Z])", lambda m: "_" + m.group(1).lower(), key), val)
    db.commit()
    return {"customer": dump(c)}


@router.delete("/customers/{cid}")
def delete_customer(cid: str, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    if db.scalar(select(func.count()).select_from(Subscription).where(Subscription.customer_id == cid)):
        raise ApiError(400, "This customer has subscriptions and cannot be deleted.")
    db.execute(update(User).where(User.customer_id == cid).values(customer_id=None, is_active=False))
    db.execute(delete(Customer).where(Customer.id == cid))
    db.commit()
    return {"success": True}
