"""API routes: templates."""

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.deps import Body0, admin_only, get_db, staff_or_admin
from app.models import Plan, Product, QuotationTemplate, TemplateLine, User
from app.serializers import ser_template
from app.services.lines import clean_lines
from app.utils import ApiError


router = APIRouter()


@router.get("/templates")
def list_templates(_: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    rows = db.scalars(select(QuotationTemplate).options(
        joinedload(QuotationTemplate.plan), selectinload(QuotationTemplate.lines).joinedload(TemplateLine.product)
    ).order_by(QuotationTemplate.created_at)).all()
    return {"templates": [ser_template(t) for t in rows]}


@router.post("/templates", status_code=201)
def create_template(b: dict = Body0, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    name = str(b.get("name") or "").strip()
    if not name:
        raise ApiError(400, "Template name is required.")
    lines = clean_lines(db, b.get("lines"), require_known_tax=False)
    if not lines:
        raise ApiError(400, "Add at least one product line to the template.")
    if b.get("planId") and not db.get(Plan, b["planId"]):
        raise ApiError(400, "Linked plan not found.")
    t = QuotationTemplate(name=name, description=b.get("description") or None, plan_id=b.get("planId") or None,
                          valid_days=max(1, int(float(b.get("validDays") or 30))),
                          lines=[TemplateLine(**{k: v for k, v in l.items() if k != "description"}) for l in lines])
    db.add(t)
    db.commit()
    t = db.scalar(select(QuotationTemplate).where(QuotationTemplate.id == t.id).options(
        joinedload(QuotationTemplate.plan), selectinload(QuotationTemplate.lines).joinedload(TemplateLine.product)))
    return {"template": ser_template(t)}


@router.get("/templates/{tid}")
def get_template(tid: str, _: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    t = db.scalar(select(QuotationTemplate).where(QuotationTemplate.id == tid).options(
        joinedload(QuotationTemplate.plan),
        selectinload(QuotationTemplate.lines).joinedload(TemplateLine.product).selectinload(Product.variants)))
    if not t:
        raise ApiError(404, "Template not found.")
    return {"template": ser_template(t, full=True)}


@router.delete("/templates/{tid}")
def delete_template(tid: str, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    t = db.get(QuotationTemplate, tid)
    if t:
        db.delete(t)
        db.commit()
    return {"success": True}
