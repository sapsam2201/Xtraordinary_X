"""API routes: discounts."""

from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy import delete, select
from sqlalchemy.orm import Session, joinedload

from app.deps import Body0, admin_only, get_db, staff_or_admin
from app.models import DiscountRule, Product, User
from app.serializers import ser_discount
from app.utils import ApiError, parse_dt


router = APIRouter()


def opt_num(v: Any, as_int: bool = False):
    if v is None or v == "":
        return None
    n = float(v)
    return max(1, int(n)) if as_int else n


@router.get("/discounts")
def list_discounts(_: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    rows = db.scalars(select(DiscountRule).options(joinedload(DiscountRule.product)).order_by(DiscountRule.created_at.desc()))
    return {"discounts": [ser_discount(r) for r in rows]}


@router.post("/discounts", status_code=201)
def create_discount(b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    name = str(b.get("name") or "").strip()
    if not name:
        raise ApiError(400, "Discount name is required.")
    typ = "FIXED" if b.get("type") == "FIXED" else "PERCENTAGE"
    try:
        value = float(b.get("value"))
    except (TypeError, ValueError):
        value = 0
    if value <= 0:
        raise ApiError(400, "Discount value must be positive.")
    if typ == "PERCENTAGE" and value > 100:
        raise ApiError(400, "A percentage discount cannot exceed 100%.")
    scope = "PRODUCT" if b.get("scope") == "PRODUCT" else "SUBSCRIPTION"
    if scope == "PRODUCT":
        if not b.get("productId"):
            raise ApiError(400, "Product-scope discounts need a product.")
        if not db.get(Product, b["productId"]):
            raise ApiError(400, "Selected product not found.")
    try:
        start, end = parse_dt(b.get("startDate"), True), parse_dt(b.get("endDate"), True)
    except ApiError:
        raise ApiError(400, "Start and end dates are required.")
    if end < start:
        raise ApiError(400, "The discount cannot end before it starts.")
    d = DiscountRule(name=name, type=typ, value=value, scope=scope,
                     product_id=b["productId"] if scope == "PRODUCT" else None,
                     min_purchase=opt_num(b.get("minPurchase")), min_quantity=opt_num(b.get("minQuantity"), True),
                     start_date=start, end_date=end, max_uses=opt_num(b.get("maxUses"), True))
    db.add(d)
    db.commit()
    db.refresh(d)
    return {"discount": ser_discount(d)}


@router.patch("/discounts/{did}")
def update_discount(did: str, b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    d = db.get(DiscountRule, did)
    if not d:
        raise ApiError(404, "Discount rule not found.")
    if isinstance(b.get("name"), str) and b["name"].strip():
        d.name = b["name"].strip()
    if isinstance(b.get("active"), bool):
        d.active = b["active"]
    if b.get("value") is not None:
        v = float(b["value"])
        if v <= 0:
            raise ApiError(400, "Discount value must be positive.")
        d.value = v
    if b.get("endDate"):
        try:
            d.end_date = parse_dt(b["endDate"])
        except ApiError:
            raise ApiError(400, "Invalid end date.")
    db.commit()
    db.refresh(d)
    return {"discount": ser_discount(d)}


@router.delete("/discounts/{did}")
def delete_discount(did: str, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    db.execute(delete(DiscountRule).where(DiscountRule.id == did))
    db.commit()
    return {"success": True}
