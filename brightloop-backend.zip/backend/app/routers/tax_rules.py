"""API routes: tax rules."""

from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.deps import Body0, admin_only, get_db, staff_or_admin
from app.models import TaxRule, User
from app.utils import ApiError, dump


router = APIRouter()


def rate_of(v: Any) -> float:
    try:
        r = float(v)
    except (TypeError, ValueError):
        raise ApiError(400, "Rate must be between 0 and 100.")
    if not 0 <= r <= 100:
        raise ApiError(400, "Rate must be between 0 and 100.")
    return r


@router.get("/tax-rules")
def list_tax(_: User = Depends(staff_or_admin), db: Session = Depends(get_db)):
    return {"taxRules": [dump(t) for t in db.scalars(select(TaxRule).order_by(TaxRule.rate.desc()))]}


@router.post("/tax-rules", status_code=201)
def create_tax(b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    name = str(b.get("name") or "").strip()
    if not name:
        raise ApiError(400, "Tax rule name is required.")
    t = TaxRule(name=name, rate=rate_of(b.get("rate")))
    db.add(t)
    db.commit()
    return {"taxRule": dump(t)}


@router.patch("/tax-rules/{tid}")
def update_tax(tid: str, b: dict = Body0, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    t = db.get(TaxRule, tid)
    if not t:
        raise ApiError(404, "Tax rule not found.")
    if isinstance(b.get("name"), str) and b["name"].strip():
        t.name = b["name"].strip()
    if b.get("rate") is not None:
        t.rate = rate_of(b["rate"])
    if isinstance(b.get("active"), bool):
        t.active = b["active"]
    db.commit()
    return {"taxRule": dump(t)}


@router.delete("/tax-rules/{tid}")
def delete_tax(tid: str, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    db.execute(delete(TaxRule).where(TaxRule.id == tid))
    db.commit()
    return {"success": True}
