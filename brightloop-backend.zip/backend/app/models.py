"""SQLAlchemy models (all tables)."""

from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Index, Integer, String, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from app.utils import new_id, utcnow


class Base(DeclarativeBase):
    pass


def _cust_fk(**kw):
    return mapped_column(String, ForeignKey("customers.id"), **kw)


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    email: Mapped[str] = mapped_column(String, unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String)
    name: Mapped[str] = mapped_column(String)
    role: Mapped[str] = mapped_column(String, default="CUSTOMER")  # ADMIN | STAFF | CUSTOMER
    customer_id: Mapped[Optional[str]] = _cust_fk(nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    customer = relationship("Customer")


class AuthSession(Base):
    __tablename__ = "sessions"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    token: Mapped[str] = mapped_column(String, unique=True, index=True)
    user_id: Mapped[str] = mapped_column(String, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    user = relationship("User")


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    token: Mapped[str] = mapped_column(String, unique=True, index=True)
    user_id: Mapped[str] = mapped_column(String, ForeignKey("users.id", ondelete="CASCADE"))
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    used_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String, index=True)
    email: Mapped[str] = mapped_column(String, unique=True)
    phone: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    company: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    address: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    city: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    country: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    tax_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Product(Base):
    __tablename__ = "products"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String, index=True)
    type: Mapped[str] = mapped_column(String, default="SOFTWARE")  # SOFTWARE | ADDON | SERVICE
    sales_price: Mapped[float] = mapped_column(Float, default=0)
    cost_price: Mapped[float] = mapped_column(Float, default=0)
    notes: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    variants = relationship("ProductVariant", cascade="all, delete-orphan", passive_deletes=True)


class ProductVariant(Base):
    __tablename__ = "product_variants"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    product_id: Mapped[str] = mapped_column(String, ForeignKey("products.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String)    # e.g. "Brand"
    value: Mapped[str] = mapped_column(String)   # e.g. "Odoo"
    price_delta: Mapped[float] = mapped_column(Float, default=0)  # e.g. +560


class Plan(Base):
    __tablename__ = "plans"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String, index=True)
    description: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    product_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("products.id"), nullable=True)
    price: Mapped[float] = mapped_column(Float, default=0)
    billing_cycle: Mapped[str] = mapped_column(String, default="MONTHLY")
    min_quantity: Mapped[int] = mapped_column(Integer, default=1)
    available_from: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    available_to: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    auto_close: Mapped[bool] = mapped_column(Boolean, default=False)
    can_close_early: Mapped[bool] = mapped_column(Boolean, default=True)
    can_pause: Mapped[bool] = mapped_column(Boolean, default=False)
    can_renew: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    product = relationship("Product")


class TaxRule(Base):
    __tablename__ = "tax_rules"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String)
    rate: Mapped[float] = mapped_column(Float, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class DiscountRule(Base):
    __tablename__ = "discount_rules"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String)
    type: Mapped[str] = mapped_column(String)    # PERCENTAGE | FIXED
    value: Mapped[float] = mapped_column(Float)
    scope: Mapped[str] = mapped_column(String)   # PRODUCT | SUBSCRIPTION
    product_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("products.id"), nullable=True)
    min_purchase: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    min_quantity: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    start_date: Mapped[datetime] = mapped_column(DateTime)
    end_date: Mapped[datetime] = mapped_column(DateTime)
    max_uses: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    used_count: Mapped[int] = mapped_column(Integer, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    product = relationship("Product")


class QuotationTemplate(Base):
    __tablename__ = "quotation_templates"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String)
    description: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    plan_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("plans.id"), nullable=True)
    valid_days: Mapped[int] = mapped_column(Integer, default=30)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    plan = relationship("Plan")
    lines = relationship("TemplateLine", cascade="all, delete-orphan", passive_deletes=True,
                         order_by="TemplateLine.sort_order")


class TemplateLine(Base):
    __tablename__ = "template_lines"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    template_id: Mapped[str] = mapped_column(String, ForeignKey("quotation_templates.id", ondelete="CASCADE"), index=True)
    product_id: Mapped[str] = mapped_column(String, ForeignKey("products.id"))
    variant_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    quantity: Mapped[float] = mapped_column(Float, default=1)
    unit_price: Mapped[float] = mapped_column(Float, default=0)
    tax_rate: Mapped[float] = mapped_column(Float, default=0)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    product = relationship("Product")


class Subscription(Base):
    __tablename__ = "subscriptions"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    number: Mapped[str] = mapped_column(String, unique=True)
    customer_id: Mapped[str] = _cust_fk(index=True)
    plan_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("plans.id"), nullable=True)
    status: Mapped[str] = mapped_column(String, default="DRAFT")  # DRAFT|QUOTATION|CONFIRMED|ACTIVE|PAUSED|CLOSED
    start_date: Mapped[datetime] = mapped_column(DateTime)
    expiry_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    payment_terms: Mapped[str] = mapped_column(String, default="DUE_ON_RECEIPT")
    next_billing_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    close_reason: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    customer = relationship("Customer")
    plan = relationship("Plan")
    lines = relationship("SubscriptionLine", cascade="all, delete-orphan", passive_deletes=True,
                         order_by="SubscriptionLine.sort_order")
    invoices = relationship("Invoice", order_by="desc(Invoice.issue_date)")
    __table_args__ = (Index("ix_sub_status_nbd", "status", "next_billing_date"),)


class SubscriptionLine(Base):
    __tablename__ = "subscription_lines"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    subscription_id: Mapped[str] = mapped_column(String, ForeignKey("subscriptions.id", ondelete="CASCADE"), index=True)
    product_id: Mapped[str] = mapped_column(String, ForeignKey("products.id"))
    variant_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    description: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    quantity: Mapped[float] = mapped_column(Float, default=1)
    unit_price: Mapped[float] = mapped_column(Float, default=0)
    tax_rate: Mapped[float] = mapped_column(Float, default=0)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    product = relationship("Product")


class Invoice(Base):
    __tablename__ = "invoices"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    number: Mapped[str] = mapped_column(String, unique=True)
    subscription_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("subscriptions.id"), nullable=True)
    customer_id: Mapped[str] = _cust_fk(index=True)
    status: Mapped[str] = mapped_column(String, default="DRAFT")  # DRAFT | CONFIRMED | PAID | CANCELLED
    issue_date: Mapped[datetime] = mapped_column(DateTime, index=True)
    due_date: Mapped[datetime] = mapped_column(DateTime)
    subtotal: Mapped[float] = mapped_column(Float, default=0)
    discount_total: Mapped[float] = mapped_column(Float, default=0)
    discount_note: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    tax_total: Mapped[float] = mapped_column(Float, default=0)
    total: Mapped[float] = mapped_column(Float, default=0)
    amount_paid: Mapped[float] = mapped_column(Float, default=0)
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    period_start: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    period_end: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    customer = relationship("Customer")
    subscription = relationship("Subscription", overlaps="invoices")
    lines = relationship("InvoiceLine", cascade="all, delete-orphan", passive_deletes=True,
                         order_by="InvoiceLine.sort_order")
    payments = relationship("Payment", order_by="Payment.date")
    __table_args__ = (
        # "Nothing billed twice": one invoice per subscription per billing period, enforced by the DB.
        # Cancelled invoices are excluded so a wrongly cancelled period can be billed again.
        Index("uq_invoice_sub_period", "subscription_id", "period_start", unique=True,
              sqlite_where=text("status <> 'CANCELLED'"), postgresql_where=text("status <> 'CANCELLED'")),
        Index("ix_invoice_status_due", "status", "due_date"),
    )


class InvoiceLine(Base):
    __tablename__ = "invoice_lines"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    invoice_id: Mapped[str] = mapped_column(String, ForeignKey("invoices.id", ondelete="CASCADE"), index=True)
    product_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    description: Mapped[str] = mapped_column(String)
    quantity: Mapped[float] = mapped_column(Float, default=1)
    unit_price: Mapped[float] = mapped_column(Float, default=0)
    discount: Mapped[float] = mapped_column(Float, default=0)
    tax_rate: Mapped[float] = mapped_column(Float, default=0)
    tax_amount: Mapped[float] = mapped_column(Float, default=0)
    net_amount: Mapped[float] = mapped_column(Float, default=0)
    total: Mapped[float] = mapped_column(Float, default=0)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class Payment(Base):
    __tablename__ = "payments"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_id)
    number: Mapped[str] = mapped_column(String, unique=True)
    invoice_id: Mapped[str] = mapped_column(String, ForeignKey("invoices.id"), index=True)
    customer_id: Mapped[str] = _cust_fk(index=True)
    method: Mapped[str] = mapped_column(String)  # CARD | BANK_TRANSFER | CASH | UPI | CHEQUE
    amount: Mapped[float] = mapped_column(Float)
    date: Mapped[datetime] = mapped_column(DateTime, index=True)
    note: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    invoice = relationship("Invoice", overlaps="payments")
    customer = relationship("Customer")


class Counter(Base):
    __tablename__ = "counters"
    key: Mapped[str] = mapped_column(String, primary_key=True)
    value: Mapped[int] = mapped_column(Integer, default=0)
