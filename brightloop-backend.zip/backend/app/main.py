"""FastAPI application: lifespan, error handlers, router registration."""

import os
import threading
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError

from app.config import log
from app.database import SessionLocal, engine
from app.models import Base, Counter
from app.services.billing import run_billing_day
from app.utils import ApiError

from app.routers import auth, billing, customers, dashboard, discounts, invoices, payments, plans, products, subscriptions, system, tax_rules, templates, users


def _billing_loop():
    hours = float(os.getenv("BILLING_INTERVAL_HOURS", "6"))
    time.sleep(30)
    while True:
        try:
            with SessionLocal() as db:
                res = run_billing_day(db)
                log.info("auto billing: %s invoices, %s closed", res["invoicesCreated"], res["subscriptionsClosed"])
        except Exception:
            log.exception("auto billing failed")
        time.sleep(hours * 3600)


def init_db():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        for k in ("INV", "SUB", "PAY"):
            if not db.get(Counter, k):
                db.add(Counter(key=k, value=0))
        db.commit()


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    if os.getenv("AUTO_BILLING") == "1":
        threading.Thread(target=_billing_loop, daemon=True).start()
    yield


app = FastAPI(title="Brightloop Subscription API", lifespan=lifespan)


app.include_router(auth.router, prefix="/api")
app.include_router(billing.router, prefix="/api")
app.include_router(customers.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
app.include_router(discounts.router, prefix="/api")
app.include_router(invoices.router, prefix="/api")
app.include_router(payments.router, prefix="/api")
app.include_router(plans.router, prefix="/api")
app.include_router(products.router, prefix="/api")
app.include_router(subscriptions.router, prefix="/api")
app.include_router(system.router, prefix="/api")
app.include_router(tax_rules.router, prefix="/api")
app.include_router(templates.router, prefix="/api")
app.include_router(users.router, prefix="/api")


@app.exception_handler(ApiError)
async def _api_error(_: Request, e: ApiError):
    return JSONResponse({"error": e.message}, status_code=e.status)


@app.exception_handler(RequestValidationError)
async def _validation(_: Request, e: RequestValidationError):
    return JSONResponse({"error": "Invalid request body."}, status_code=400)


@app.exception_handler(IntegrityError)
async def _integrity(_: Request, e: IntegrityError):
    log.warning("integrity error: %s", e.orig)
    return JSONResponse({"error": "That change conflicts with existing data."}, status_code=409)


@app.exception_handler(Exception)
async def _unexpected(_: Request, e: Exception):
    log.exception("unexpected error")
    return JSONResponse({"error": "Internal server error"}, status_code=500)
