"""Validation of subscription / template product lines."""

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models import Product, TaxRule
from app.utils import ApiError


def clean_lines(db: Session, lines: Any, require_known_tax: bool) -> list:
    """Validates subscription/template lines: products exist, variants belong to the product,
    tax rates come from the admin's tax rules."""
    if not isinstance(lines, list) or not lines:
        return []
    pids = {str(l.get("productId") or "") for l in lines}
    products = {p.id: p for p in db.scalars(select(Product).where(Product.id.in_(pids)).options(selectinload(Product.variants)))}
    allowed = {0.0} | {float(r) for r in db.scalars(select(TaxRule.rate).where(TaxRule.active == True))}  # noqa: E712
    out = []
    for i, l in enumerate(lines):
        p = products.get(str(l.get("productId") or ""))
        if not p:
            raise ApiError(400, "One of the lines points to a missing product.")
        vid = l.get("variantId") or None
        if vid and vid not in {v.id for v in p.variants}:
            raise ApiError(400, f"The selected variant does not belong to {p.name}.")
        tax = max(0.0, float(l.get("taxRate") or 0))
        if require_known_tax and not any(abs(tax - a) < 0.001 for a in allowed):
            raise ApiError(400, f"Tax rate {tax:g}% is not one of the configured tax rules.")
        out.append(dict(product_id=p.id, variant_id=vid, description=l.get("description") or None,
                        quantity=max(1.0, float(l.get("quantity") or 1)), unit_price=max(0.0, float(l.get("unitPrice") or 0)),
                        tax_rate=tax, sort_order=i))
    return out
