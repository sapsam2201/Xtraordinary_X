"""Recording payments against invoices."""

from datetime import datetime
from typing import Optional

from sqlalchemy import update
from sqlalchemy.orm import Session

from app.models import Invoice, Payment
from app.services.billing import next_number
from app.utils import ApiError, r2, start_of_day, today_utc, utcnow


def record_payment(db: Session, invoice_id: str, method: str, amount: float, date: Optional[datetime], note: Optional[str]) -> dict:
    inv = db.get(Invoice, invoice_id)
    if not inv:
        raise ApiError(404, "Invoice not found")
    if inv.status == "CANCELLED":
        raise ApiError(400, "Cannot pay a cancelled invoice.")
    if inv.status == "DRAFT":
        raise ApiError(400, "Confirm the invoice before recording a payment.")
    amount = r2(amount)
    if amount <= 0:
        raise ApiError(400, "Payment amount must be positive.")
    # atomic guard against double-spending the balance when two payments arrive together
    res = db.execute(update(Invoice).where(
        Invoice.id == invoice_id, Invoice.status == "CONFIRMED", Invoice.amount_paid + amount <= Invoice.total + 0.001
    ).values(amount_paid=Invoice.amount_paid + amount))
    if res.rowcount == 0:
        db.rollback()
        fresh = db.get(Invoice, invoice_id)
        raise ApiError(400, f"Amount exceeds the outstanding balance ({r2(fresh.total - fresh.amount_paid):.2f}).")
    pay = Payment(number=next_number(db, "PAY", "PAY"), invoice_id=invoice_id, customer_id=inv.customer_id,
                  method=method, amount=amount, date=start_of_day(date) if date else today_utc(), note=note)
    db.add(pay)
    db.flush()
    db.refresh(inv)
    if inv.amount_paid >= inv.total - 0.001:
        inv.status, inv.paid_at = "PAID", utcnow()
    db.commit()
    return {"paymentId": pay.id, "invoiceStatus": inv.status, "balance": r2(inv.total - inv.amount_paid)}
