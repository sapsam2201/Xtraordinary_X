"""Billing engine: numbering, discounts, taxes, invoice generation, billing day."""

import threading
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import and_, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload, selectinload

from app.config import PAYMENT_TERMS_DAYS
from app.models import Counter, DiscountRule, Invoice, InvoiceLine, Plan, Subscription, SubscriptionLine
from app.utils import ApiError, add_cycle, r2, start_of_day, today_utc, utcnow


def next_number(db: Session, key: str, prefix: str) -> str:
    res = db.execute(update(Counter).where(Counter.key == key).values(value=Counter.value + 1))
    if res.rowcount == 0:
        db.add(Counter(key=key, value=1))
        db.flush()
        v = 1
    else:
        v = db.scalar(select(Counter.value).where(Counter.key == key))
    return f"{prefix}-{v:04d}"


def rule_dict(r: DiscountRule) -> dict:
    return dict(id=r.id, name=r.name, type=r.type, value=r.value, scope=r.scope, product_id=r.product_id,
                min_purchase=r.min_purchase, min_quantity=r.min_quantity, start_date=r.start_date,
                end_date=r.end_date, max_uses=r.max_uses, used_count=r.used_count or 0, active=r.active)


def load_rules(db: Session) -> list:
    return [rule_dict(r) for r in db.scalars(select(DiscountRule).where(DiscountRule.active == True))]  # noqa: E712


def pick_discounts(rules: list, lines: list, on: datetime, excluded: set) -> dict:
    day_end = start_of_day(on) + timedelta(days=1)
    elig = [r for r in rules
            if r["id"] not in excluded and r["active"]
            and r["start_date"] <= on < start_of_day(r["end_date"]) + timedelta(days=1)
            and (r["max_uses"] is None or r["used_count"] < r["max_uses"])]
    del day_end

    def saving(r: dict) -> float:  # customers always get the best eligible discount, not an arbitrary one
        pool = [l for l in lines if r["scope"] == "SUBSCRIPTION" or l["product_id"] == r["product_id"]]
        amt = sum(l["quantity"] * l["unit_price"] for l in pool)
        return amt * r["value"] / 100 if r["type"] == "PERCENTAGE" else min(r["value"], amt)
    elig.sort(key=saving, reverse=True)
    product_rules: dict = {}
    sub_rule = None
    total_qty = sum(l["quantity"] for l in lines)
    total_amt = sum(l["quantity"] * l["unit_price"] for l in lines)
    for r in elig:
        if r["scope"] == "PRODUCT" and r["product_id"]:
            m = [l for l in lines if l["product_id"] == r["product_id"]]
            if not m:
                continue
            ok_q = r["min_quantity"] is None or any(l["quantity"] >= r["min_quantity"] for l in m)
            ok_a = r["min_purchase"] is None or sum(l["quantity"] * l["unit_price"] for l in m) >= r["min_purchase"]
            if ok_q and ok_a:
                product_rules.setdefault(r["product_id"], r)
        elif r["scope"] == "SUBSCRIPTION":
            ok_q = r["min_quantity"] is None or total_qty >= r["min_quantity"]
            ok_a = r["min_purchase"] is None or total_amt >= r["min_purchase"]
            if ok_q and ok_a and sub_rule is None:
                sub_rule = r
    return {"product_rules": product_rules, "subscription_rule": sub_rule}


def compute_invoice(lines: list, picked: dict) -> dict:
    base = [r2(l["quantity"] * l["unit_price"]) for l in lines]
    grand = r2(sum(base))
    pdisc = []
    for i, l in enumerate(lines):
        rule = picked["product_rules"].get(l["product_id"]) if l.get("product_id") else None
        if not rule:
            pdisc.append(0.0)
        elif rule["type"] == "PERCENTAGE":
            pdisc.append(r2(base[i] * rule["value"] / 100))
        else:
            pdisc.append(r2(min(rule["value"], base[i])))
    after = r2(sum(b - p for b, p in zip(base, pdisc)))
    sub_total = 0.0
    rule = picked["subscription_rule"]
    if rule:
        sub_total = r2(after * rule["value"] / 100) if rule["type"] == "PERCENTAGE" else r2(min(rule["value"], after))
    share = [r2(sub_total * b / grand) if sub_total > 0 and grand > 0 else 0.0 for b in base]
    drift = r2(sub_total - sum(share))
    if drift and share:  # push rounding drift onto the last discounted line
        for i in range(len(share) - 1, -1, -1):
            if share[i] > 0:
                share[i] = r2(share[i] + drift)
                break
    out = []
    for i, l in enumerate(lines):
        disc = r2(pdisc[i] + share[i])
        net = r2(base[i] - disc)
        tax = r2(net * l["tax_rate"] / 100)
        out.append({**l, "discount": disc, "net_amount": net, "tax_amount": tax, "total": r2(net + tax)})
    used, notes = [], []
    for r in picked["product_rules"].values():
        if any(c["discount"] > 0 and c.get("product_id") == r["product_id"] for c in out):
            used.append(r["id"])
            if r["name"] not in notes:
                notes.append(r["name"])
    if rule and sub_total > 0:
        used.append(rule["id"])
        if rule["name"] not in notes:
            notes.append(rule["name"])
    return {
        "lines": out,
        "subtotal": r2(sum(r2(l["quantity"] * l["unit_price"]) for l in lines)),
        "discount_total": r2(sum(c["discount"] for c in out)),
        "discount_note": ", ".join(notes),
        "tax_total": r2(sum(c["tax_amount"] for c in out)),
        "total": r2(sum(c["total"] for c in out)),
        "used_ids": used,
    }


class AlreadyBilled(Exception):
    pass


class _Retry(Exception):
    def __init__(self, rule_id: str):
        self.rule_id = rule_id


def create_invoice_row(db: Session, sub: Subscription, period_start: datetime, issue_date: datetime,
                       rules: list, status: str = "DRAFT") -> tuple:
    """Builds one invoice (lines, taxes, discounts, totals) for a billing period.
    Discount usage is reserved atomically and the (subscription, period) unique key
    guarantees the same period can never be billed twice, even with concurrent runs."""
    if not sub.lines:
        raise ApiError(400, "Subscription has no product lines to bill.")
    line_inputs = [dict(product_id=l.product_id, description=l.description or (l.product.name if l.product else "Item"),
                        quantity=l.quantity, unit_price=l.unit_price, tax_rate=l.tax_rate) for l in sub.lines]
    cycle = sub.plan.billing_cycle if sub.plan else "MONTHLY"
    period_end = add_cycle(period_start, cycle) - timedelta(days=1) if sub.plan else None
    due = issue_date + timedelta(days=PAYMENT_TERMS_DAYS.get(sub.payment_terms, 0))
    by_id = {r["id"]: r for r in rules}
    excluded: set = set()
    for _ in range(6):
        picked = pick_discounts(rules, line_inputs, issue_date, excluded)
        comp = compute_invoice(line_inputs, picked)
        sp = db.begin_nested()
        try:
            for rid in comp["used_ids"]:
                res = db.execute(update(DiscountRule).where(
                    DiscountRule.id == rid, DiscountRule.active == True,  # noqa: E712
                    or_(DiscountRule.max_uses.is_(None), DiscountRule.used_count < DiscountRule.max_uses),
                ).values(used_count=DiscountRule.used_count + 1))
                if res.rowcount == 0:
                    raise _Retry(rid)
            inv = Invoice(
                number=next_number(db, "INV", "INV"), subscription_id=sub.id, customer_id=sub.customer_id,
                status=status, issue_date=issue_date, due_date=due, subtotal=comp["subtotal"],
                discount_total=comp["discount_total"], discount_note=comp["discount_note"] or None,
                tax_total=comp["tax_total"], total=comp["total"], period_start=period_start,
                period_end=period_end, notes=f"Generated from subscription {sub.number}",
                lines=[InvoiceLine(product_id=c["product_id"], description=c["description"], quantity=c["quantity"],
                                   unit_price=c["unit_price"], discount=c["discount"], tax_rate=c["tax_rate"],
                                   tax_amount=c["tax_amount"], net_amount=c["net_amount"], total=c["total"], sort_order=i)
                       for i, c in enumerate(comp["lines"])],
            )
            db.add(inv)
            db.flush()
            sp.commit()
        except _Retry as e:
            sp.rollback()
            excluded.add(e.rule_id)
            continue
        except IntegrityError:
            sp.rollback()
            raise AlreadyBilled()
        except Exception:
            sp.rollback()
            raise
        for rid in comp["used_ids"]:
            by_id[rid]["used_count"] += 1
        names = comp["discount_note"].split(", ") if comp["discount_note"] else []
        return inv, names
    raise ApiError(409, "Could not reserve discount usage, please retry.")


def load_sub_for_billing(db: Session, sub_id: str) -> Optional[Subscription]:
    return db.scalar(select(Subscription).where(Subscription.id == sub_id).options(
        selectinload(Subscription.lines).joinedload(SubscriptionLine.product),
        joinedload(Subscription.plan), joinedload(Subscription.customer)))


def bill_now(db: Session, sub_id: str) -> dict:
    """Staff 'Bill now' button: invoice the current period straight away."""
    sub = load_sub_for_billing(db, sub_id)
    if not sub:
        raise ApiError(404, "Subscription not found.")
    if sub.status not in ("CONFIRMED", "ACTIVE", "PAUSED"):
        raise ApiError(400, "Only confirmed or active subscriptions can be billed.")
    period_start = sub.next_billing_date or sub.start_date
    try:
        inv, names = create_invoice_row(db, sub, period_start, today_utc(), load_rules(db))
    except AlreadyBilled:
        db.rollback()
        raise ApiError(400, "This billing period has already been invoiced.")
    if sub.plan:
        sub.next_billing_date = add_cycle(period_start, sub.plan.billing_cycle)
    db.commit()
    return {"invoice": {"id": inv.id, "number": inv.number, "total": inv.total, "status": inv.status}, "discountNames": names}


MAX_CATCHUP = 36


_billing_lock = threading.Lock()


def run_billing_day(db: Session) -> dict:
    """Close finished plans, then invoice every due subscription (catching up missed cycles).
    Only one run at a time per process (the unique key still protects multi-process deployments)."""
    if not _billing_lock.acquire(blocking=False):
        raise ApiError(409, "A billing run is already in progress.")
    try:
        return _run_billing_day(db)
    finally:
        _billing_lock.release()


def _run_billing_day(db: Session) -> dict:
    today = today_utc()
    expired = db.execute(
        select(Subscription.id, Subscription.number).join(Plan, Subscription.plan_id == Plan.id)
        .where(Subscription.status == "ACTIVE", Subscription.expiry_date < today, Plan.auto_close == True)  # noqa: E712
    ).all()
    if expired:
        db.execute(update(Subscription).where(Subscription.id.in_([e.id for e in expired])).values(
            status="CLOSED", closed_at=utcnow(), close_reason="Plan period ended"))
        db.commit()

    rules = load_rules(db)
    created, skipped = [], []
    last_key = None
    while True:  # keyset pagination so thousands of subscriptions never sit in memory at once
        q = select(Subscription.id, Subscription.next_billing_date).where(
            Subscription.status == "ACTIVE", Subscription.next_billing_date <= today
        ).order_by(Subscription.next_billing_date, Subscription.id).limit(200)
        if last_key:
            q = q.where(or_(Subscription.next_billing_date > last_key[0],
                            and_(Subscription.next_billing_date == last_key[0], Subscription.id > last_key[1])))
        batch = db.execute(q).all()
        if not batch:
            break
        last_key = (batch[-1][1], batch[-1][0])
        for sub_id, _ in batch:
            sub = load_sub_for_billing(db, sub_id)
            if not sub or not sub.plan:
                continue
            made = 0
            for _ in range(MAX_CATCHUP):
                if not sub.next_billing_date or sub.next_billing_date > today:
                    break
                period_start = sub.next_billing_date
                try:
                    inv, _n = create_invoice_row(db, sub, period_start, today, rules)
                    sub.next_billing_date = add_cycle(period_start, sub.plan.billing_cycle)
                    db.commit()
                    created.append({"number": sub.number, "invoice": inv.number, "total": inv.total})
                    made += 1
                except AlreadyBilled:  # period already invoiced elsewhere: just move the schedule on
                    db.rollback()
                    sub = load_sub_for_billing(db, sub_id)
                    sub.next_billing_date = add_cycle(period_start, sub.plan.billing_cycle)
                    db.commit()
                    skipped.append({"number": sub.number, "reason": "Period already invoiced; schedule advanced"})
                except Exception as e:
                    db.rollback()
                    skipped.append({"number": sub.number, "reason": str(getattr(e, "message", e))})
                    break
    return {"invoicesCreated": len(created), "subscriptionsClosed": len(expired), "created": created,
            "skipped": skipped, "closed": [e.number for e in expired]}
