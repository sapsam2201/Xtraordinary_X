"""Logging, constants and feature flags."""

import logging
import os
import re


log = logging.getLogger("brightloop")


logging.basicConfig(level=logging.INFO)


PAYMENT_TERMS_DAYS = {"DUE_ON_RECEIPT": 0, "NET_15": 15, "NET_30": 30}


CYCLES = ("DAILY", "WEEKLY", "MONTHLY", "YEARLY")


METHODS = ("CARD", "BANK_TRANSFER", "UPI", "CASH", "CHEQUE")


def demo_mode() -> bool:
    return os.getenv("DEMO_MODE") == "1"


def upi_settings():
    """UPI receiving account for the customer QR code. Set UPI_ID (and UPI_PAYEE_NAME) in production.
    In DEMO_MODE a placeholder is used so the QR can be shown without configuration."""
    vpa = os.getenv("UPI_ID", "").strip()
    name = (os.getenv("UPI_PAYEE_NAME") or "Brightloop Software").strip()
    placeholder = False
    if not vpa and demo_mode():
        vpa, placeholder = "brightloop.demo@upi", True
    if not re.fullmatch(r"[A-Za-z0-9._\-]{2,256}@[A-Za-z]{2,64}", vpa):
        return None
    return {"vpa": vpa, "name": name, "placeholder": placeholder}


SESSION_COOKIE = "bl_session"


SESSION_DAYS = 30
