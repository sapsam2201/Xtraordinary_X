"""Logging, constants and feature flags."""

import logging
import os


log = logging.getLogger("brightloop")


logging.basicConfig(level=logging.INFO)


PAYMENT_TERMS_DAYS = {"DUE_ON_RECEIPT": 0, "NET_15": 15, "NET_30": 30}


CYCLES = ("DAILY", "WEEKLY", "MONTHLY", "YEARLY")


METHODS = ("CARD", "BANK_TRANSFER", "UPI", "CASH", "CHEQUE")


def demo_mode() -> bool:
    return os.getenv("DEMO_MODE") == "1"


SESSION_COOKIE = "bl_session"


SESSION_DAYS = 30
