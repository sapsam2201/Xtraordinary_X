"""Turn models into the JSON shapes the frontend expects."""

from typing import Optional

from app.models import DiscountRule, Invoice, Payment, Plan, Product, QuotationTemplate, Subscription
from app.utils import dump


def ser_variant(v):
    return dump(v)


def ser_product(p: Product, sub_lines: Optional[int] = None) -> dict:
    d = dump(p)
    d["variants"] = [ser_variant(v) for v in p.variants]
    if sub_lines is not None:
        d["_count"] = {"subLines": sub_lines}
    return d


def ser_plan(p: Plan, n_subs: Optional[int] = None) -> dict:
    d = dump(p)
    d["product"] = {"name": p.product.name} if p.product else None
    if n_subs is not None:
        d["_count"] = {"subscriptions": n_subs}
    return d


def ser_discount(r: DiscountRule) -> dict:
    d = dump(r)
    d["product"] = {"name": r.product.name} if r.product else None
    return d


def ser_template(t: QuotationTemplate, full: bool = False) -> dict:
    d = dump(t)
    if full:
        d["plan"] = dump(t.plan) if t.plan else None
    else:
        d["plan"] = {"name": t.plan.name, "billingCycle": t.plan.billing_cycle, "price": t.plan.price} if t.plan else None
    lines = []
    for l in t.lines:
        ld = dump(l)
        ld["product"] = ser_product(l.product) if full else {"name": l.product.name}
        lines.append(ld)
    d["lines"] = lines
    return d


def ser_sub(s: Subscription, n_inv: Optional[int] = None, detail: bool = False) -> dict:
    d = dump(s)
    if detail:
        d["customer"] = dump(s.customer)
        d["plan"] = dump(s.plan) if s.plan else None
        d["lines"] = [{**dump(l), "product": ser_product(l.product)} for l in s.lines]
        d["invoices"] = [dump(i) for i in s.invoices[:12]]
    else:
        d["customer"] = {"id": s.customer.id, "name": s.customer.name, "email": s.customer.email}
        d["plan"] = dump(s.plan) if s.plan else None
        d["lines"] = [dump(l) for l in s.lines]
        if n_inv is not None:
            d["_count"] = {"invoices": n_inv}
    return d


def ser_invoice(i: Invoice, kind: str = "list", n_pay: int = 0) -> dict:
    d = dump(i)
    if kind == "list":
        d["customer"] = {"id": i.customer.id, "name": i.customer.name}
        d["subscription"] = {"id": i.subscription.id, "number": i.subscription.number} if i.subscription else None
        d["_count"] = {"payments": n_pay}
    else:
        d["customer"] = dump(i.customer)
        if kind == "detail":
            d["subscription"] = ({"id": i.subscription.id, "number": i.subscription.number,
                                  "plan": {"name": i.subscription.plan.name} if i.subscription.plan else None}
                                 if i.subscription else None)
        d["lines"] = [dump(l) for l in i.lines]
        d["payments"] = [dump(p) for p in i.payments]
    return d


def ser_payment(p: Payment) -> dict:
    d = dump(p)
    d["invoice"] = {"id": p.invoice.id, "number": p.invoice.number, "total": p.invoice.total}
    d["customer"] = {"id": p.customer.id, "name": p.customer.name}
    return d
