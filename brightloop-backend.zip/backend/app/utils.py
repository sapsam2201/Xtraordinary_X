"""Small shared helpers: errors, JSON/camelCase, dates, paging."""

import calendar
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def today_utc() -> datetime:
    return utcnow().replace(hour=0, minute=0, second=0, microsecond=0)


def new_id() -> str:
    return uuid.uuid4().hex


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def camel(s: str) -> str:
    p = s.split("_")
    return p[0] + "".join(x.title() for x in p[1:])


def jv(v: Any) -> Any:
    if isinstance(v, datetime):
        return v.isoformat(timespec="milliseconds") + "Z"
    return v


def dump(o: Any, skip: tuple = ()) -> dict:
    return {camel(c.key): jv(getattr(o, c.key)) for c in o.__table__.columns if c.key not in skip}


def r2(n: float) -> float:
    return round(n + 1e-12, 2)


def parse_dt(v: Any, required: bool = False) -> Optional[datetime]:
    if v in (None, ""):
        if required:
            raise ApiError(400, "A valid date is required.")
        return None
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        raise ApiError(400, "A valid date is required.")
    if d.tzinfo:
        d = d.astimezone(timezone.utc).replace(tzinfo=None)
    return d


def start_of_day(d: datetime) -> datetime:
    return d.replace(hour=0, minute=0, second=0, microsecond=0)


def add_months(d: datetime, n: int) -> datetime:
    """Calendar-aware (Jan 31 + 1 month = Feb 28/29, never Mar 3)."""
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    return d.replace(year=y, month=m, day=min(d.day, calendar.monthrange(y, m)[1]))


def add_cycle(d: datetime, cycle: str) -> datetime:
    if cycle == "DAILY":
        return d + timedelta(days=1)
    if cycle == "WEEKLY":
        return d + timedelta(days=7)
    if cycle == "YEARLY":
        return add_months(d, 12)
    return add_months(d, 1)


def renewal_expiry(start: datetime, cycle: str) -> datetime:
    """Term of a renewed subscription: one year for yearly plans, otherwise one month
    (never shorter than the billing cycle itself, so daily/weekly plans still get invoiced)."""
    return add_months(start, 12) if cycle == "YEARLY" else add_months(start, 1)


def monthly_normalized(amount: float, cycle: str) -> float:
    return {"DAILY": amount * 30, "WEEKLY": amount * 52 / 12, "YEARLY": amount / 12}.get(cycle, amount)


def like(col, q: str):
    return col.ilike(f"%{q}%")


def paging(stmt, limit: Optional[int], offset: Optional[int], default: int):
    n = max(1, min(int(limit or default), 5000))
    return stmt.limit(n).offset(max(0, int(offset or 0)))


def day_end_exclusive(s: Optional[str]) -> Optional[datetime]:
    d = parse_dt(s)
    return start_of_day(d) + timedelta(days=1) if d else None


def money(v: Any, label: str) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        raise ApiError(400, f"{label} must be a positive number.")
    if x != x or x < 0 or x == float("inf"):
        raise ApiError(400, f"{label} must be a positive number.")
    return x
