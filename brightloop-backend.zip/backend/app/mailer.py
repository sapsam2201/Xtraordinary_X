"""Outgoing e-mail (SMTP). Does nothing when SMTP_HOST is not set."""

import os
import smtplib
from email.message import EmailMessage

from app.config import log


def send_mail(to: str, subject: str, body: str) -> bool:
    host = os.getenv("SMTP_HOST")
    if not host:
        return False
    try:
        msg = EmailMessage()
        msg["From"] = os.getenv("SMTP_FROM", "billing@brightloop.local")
        msg["To"], msg["Subject"] = to, subject
        msg.set_content(body)
        with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587")), timeout=10) as s:
            s.starttls()
            if os.getenv("SMTP_USER"):
                s.login(os.getenv("SMTP_USER"), os.getenv("SMTP_PASSWORD", ""))
            s.send_message(msg)
        return True
    except Exception as e:  # never let mail problems break an API call
        log.warning("mail failed: %s", e)
        return False
