"""FastAPI dependencies: DB session, current user, role guards."""

import secrets
from datetime import timedelta, timezone
from typing import Optional

from fastapi import Body, Depends, Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.config import SESSION_COOKIE, SESSION_DAYS
from app.database import SessionLocal
from app.models import AuthSession, User
from app.utils import ApiError, utcnow


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def request_token(req: Request) -> Optional[str]:
    h = req.headers.get("authorization", "")
    if h.lower().startswith("bearer ") and h[7:].strip():
        return h[7:].strip()
    return req.cookies.get(SESSION_COOKIE)


def session_user(req: Request, db: Session) -> Optional[User]:
    token = request_token(req)
    if not token:
        return None
    s = db.scalar(select(AuthSession).where(AuthSession.token == token).options(joinedload(AuthSession.user)))
    if not s:
        return None
    if s.expires_at < utcnow():
        db.delete(s)
        db.commit()
        return None
    return s.user if s.user.is_active else None


def require(*roles: str):
    def dep(req: Request, db: Session = Depends(get_db)) -> User:
        u = session_user(req, db)
        if not u:
            raise ApiError(401, "You must be signed in.")
        if roles and u.role not in roles:
            raise ApiError(403, "You do not have permission to perform this action.")
        return u
    return dep


any_user = require()


staff_or_admin = require("ADMIN", "STAFF")


admin_only = require("ADMIN")


anyone = require("ADMIN", "STAFF", "CUSTOMER")


def open_session(db: Session, user: User, response: Response) -> str:
    token = secrets.token_hex(32)
    exp = utcnow() + timedelta(days=SESSION_DAYS)
    db.add(AuthSession(token=token, user_id=user.id, expires_at=exp))
    db.commit()
    response.set_cookie(SESSION_COOKIE, token, httponly=True, samesite="lax", path="/", expires=exp.replace(tzinfo=timezone.utc))
    return token


def safe_user(u: User) -> dict:
    return {"id": u.id, "email": u.email, "name": u.name, "role": u.role, "customerId": u.customer_id}


Body0 = Body(default_factory=dict)
