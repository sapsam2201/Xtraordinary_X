# Brightloop – Backend (FastAPI + SQLAlchemy)

Runs on http://127.0.0.1:8000 · Swagger docs at http://127.0.0.1:8000/docs
The frontend (separate project) calls this API through `/api/*`.

## Run
```bash
./run.sh            # Windows: run.bat
```
or manually:
```bash
python3 -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export DEMO_MODE=1                                      # Windows PowerShell: $env:DEMO_MODE="1"
python main.py seed          # demo data (add --bulk 5000 to load-test)
python main.py               # start the API
```
Logins: `admin@brightloop.com / Admin@123!`, `maya@brightloop.com / Staff@123!`, `accounts@kaveritextiles.in / Customer@123!`
Tests: `pytest -q` (unit + API suite) · `python smoke_test.py` (end-to-end script) · `python scripts/bench.py` (performance check)

## Layout
```
main.py            entry point (run / seed)
app/main.py        FastAPI app, error handlers, router registration
app/models.py      all database tables
app/serializers.py model -> JSON shapes the frontend expects
app/routers/       one file per API area (auth, users, customers, products, plans, tax_rules,
                   discounts, templates, subscriptions, billing, invoices, payments, dashboard, system)
app/services/      business logic (billing.py, payments.py, lines.py)
app/config.py database.py utils.py security.py mailer.py deps.py seed.py
```

## Adding a feature (example: "coupons")
1. Add the table to `app/models.py`.
2. Create `app/routers/coupons.py` with `router = APIRouter()` and routes using `Depends(staff_or_admin)` / `admin_only` from `app.deps`.
3. In `app/main.py` add `coupons` to the `from app.routers import ...` line and
   `app.include_router(coupons.router, prefix="/api")`.
4. Put reusable logic in `app/services/`.
5. SQLite tables are only created, never altered: after changing a table delete `brightloop.db` and run `python main.py seed`
   (use Alembic migrations before going to PostgreSQL in production).

## Environment variables (all optional)
| Variable | Purpose |
|---|---|
| `DEMO_MODE=1` | demo only: auto-seed empty DB, show reset link on screen, let customers press "Pay now". **Never in production** |
| `DATABASE_URL` | default `sqlite:///./brightloop.db`; PostgreSQL: `postgresql+psycopg://user:pw@host/db` |
| `AUTO_BILLING=1`, `BILLING_INTERVAL_HOURS` | run billing day automatically in the background |
| `CRON_SECRET` | enables `POST /api/cron/billing` (header `X-Cron-Secret`) |
| `SMTP_HOST/PORT/USER/PASSWORD/FROM`, `PUBLIC_URL` | send real reset-password and invoice e-mails |
| `UPI_ID`, `UPI_PAYEE_NAME` | **receiving UPI account for the customer payment QR** (e.g. `UPI_ID=yourshop@okaxis`). Without it the QR is only available in `DEMO_MODE`, with a placeholder ID |
| `HOST`, `PORT` | default `127.0.0.1`, `8000` |

## Customer payment QR (UPI)
`GET /api/invoices/{id}/upi` (customer for their own open invoice, or staff) returns a standard UPI link
(`upi://pay?pa=<UPI_ID>&pn=<name>&am=<balance>&cu=INR&tn=<note>&tr=<invoice no>`) plus display details.
The frontend renders that link as a QR code, so any UPI app can scan it with the amount and invoice reference pre-filled.
A QR cannot confirm a payment by itself: staff record the payment (Payments page) and the customer's screen updates
automatically. In `DEMO_MODE` the customer also gets an "I've paid" button that simulates a gateway confirmation.
For fully automatic confirmation, connect a payment gateway (e.g. Razorpay UPI QR) and call `record_payment` from its webhook.


## List endpoints: paging, sorting, totals
`/api/invoices`, `/api/subscriptions` and `/api/payments` are paged on the server so pages stay fast with thousands of rows.

| Param | Meaning |
|---|---|
| `limit`, `offset` | page window (default 1000, max 5000) |
| `sort`, `dir=asc\|desc` | whitelisted columns only (invoices: number, issueDate, dueDate, total, balance, status, customer) |
| `status`, `q`, `from`, `to`, `customerId` | filters (payments: `method`) |

Responses include `total` (rows matching the filters). Extras: invoices → `summary` (open/overdue count and amount for the date range),
subscriptions → `counts` (per-status badges), payments → `totalAmount` (sum of the whole filtered set).

## CSV export
`GET /api/invoices.csv` (add `overdue=true` for the chase list), `/api/payments.csv`, `/api/subscriptions.csv`. They take the same filters, stream the result
and respect roles (customers only get their own rows).

## Performance
`python scripts/bench.py 5000` seeds 5,000 subscriptions into a temporary database and times every list page, the dashboard and the CSV export (fails if any takes 2s or more).

## Docker
`docker compose up --build` starts API (8000) and UI (3000) in demo mode with the frontend project next to this folder.

## Where each scene of the brief lives
| Scene | API | UI |
|---|---|---|
| New customer signs up, reset link, roles | `auth.py`, `users.py` | Auth screen, Staff page (admin only) |
| Launching a plan (products, variants, plans) | `products.py`, `plans.py` | Products, Plans |
| Quote to subscription (templates, lifecycle) | `templates.py`, `subscriptions.py` | Templates, Subscriptions |
| Billing day (no double billing, taxes) | `services/billing.py`, `billing.py`, `tax_rules.py` | Invoices → Billing day, Taxes |
| Better price (discount rules) | `discounts.py`, `pick_discounts()` | Discounts |
| Money comes in | `payments.py`, `services/payments.py` | Payments, invoice detail, UPI QR |
| Finance lead | `dashboard.py`, `*.csv` | Dashboard, Reports |

## Known limitations
- Money is stored as floats rounded with `r2()` at every step; use `Numeric`/integer minor units before real production use.
- SQLite tables are only created, never altered; use Alembic migrations with PostgreSQL.
