# Brightloop – Backend (FastAPI + SQLAlchemy)

Runs on http://127.0.0.1:8000 · Swagger docs at http://127.0.0.1:8000/docs
The frontend (separate project) calls this API through `/api/*`.

## Run
```bash
./run.sh            # Windows: run.bat
```
or manually:
```bash
python3 -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export DEMO_MODE=1                                      # Windows PowerShell: $env:DEMO_MODE="1"
python main.py seed          # demo data (add --bulk 5000 to load-test)
python main.py               # start the API
```
Logins: `admin@brightloop.com / Admin@123!`, `maya@brightloop.com / Staff@123!`, `accounts@kaveritextiles.in / Customer@123!`
Tests: `python smoke_test.py`

## Layout
```
main.py            entry point (run / seed)
app/main.py        FastAPI app, error handlers, router registration
app/models.py      all database tables
app/serializers.py model -> JSON shapes the frontend expects
app/routers/       one file per API area (auth, users, customers, products, plans, tax_rules,
                   discounts, templates, subscriptions, billing, invoices, payments, dashboard, system)
app/services/      business logic (billing.py, payments.py, lines.py)
app/config.py database.py utils.py security.py mailer.py deps.py seed.py
```

## Adding a feature (example: "coupons")
1. Add the table to `app/models.py`.
2. Create `app/routers/coupons.py` with `router = APIRouter()` and routes using `Depends(staff_or_admin)` / `admin_only` from `app.deps`.
3. In `app/main.py` add `coupons` to the `from app.routers import ...` line and
   `app.include_router(coupons.router, prefix="/api")`.
4. Put reusable logic in `app/services/`.
5. SQLite tables are only created, never altered: after changing a table delete `brightloop.db` and run `python main.py seed`
   (use Alembic migrations before going to PostgreSQL in production).

## Environment variables (all optional)
| Variable | Purpose |
|---|---|
| `DEMO_MODE=1` | demo only: auto-seed empty DB, show reset link on screen, let customers press "Pay now". **Never in production** |
| `DATABASE_URL` | default `sqlite:///./brightloop.db`; PostgreSQL: `postgresql+psycopg://user:pw@host/db` |
| `AUTO_BILLING=1`, `BILLING_INTERVAL_HOURS` | run billing day automatically in the background |
| `CRON_SECRET` | enables `POST /api/cron/billing` (header `X-Cron-Secret`) |
| `SMTP_HOST/PORT/USER/PASSWORD/FROM`, `PUBLIC_URL` | send real reset-password and invoice e-mails |
| `HOST`, `PORT` | default `127.0.0.1`, `8000` |
