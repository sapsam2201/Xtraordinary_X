"""End-to-end smoke test: python smoke_test.py  (uses a throw-away SQLite database)."""
import os, sys, json
import tempfile
os.environ["DATABASE_URL"]="sqlite:///"+os.path.join(tempfile.mkdtemp(),"smoke.db")
sys.path.insert(0, ".")
from fastapi.testclient import TestClient
import main, logging; logging.getLogger("httpx").setLevel(logging.WARNING)
main.init_db()
with main.SessionLocal() as _s: main.run_seed(_s)
c = TestClient(main.app); anon = TestClient(main.app)
fails=[]
def chk(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ")+name, extra if not cond else "")
    if not cond: fails.append(name)

def login(email, pw):
    r=c.post("/api/auth/login", json={"email":email,"password":pw}); 
    return r, {"Authorization":"Bearer "+r.json().get("token","")}
r,A = login("admin@brightloop.com","Admin@123!"); chk("admin login", r.status_code==200 and r.json()["user"]["role"]=="ADMIN", r.text)
r,S = login("maya@brightloop.com","Staff@123!"); chk("staff login", r.status_code==200)
r,C = login("accounts@kaveritextiles.in","Customer@123!"); chk("customer login", r.status_code==200, r.text)
chk("bad login 401", c.post("/api/auth/login", json={"email":"admin@brightloop.com","password":"x"}).status_code==401)
chk("me", c.get("/api/auth/me", headers=A).json()["user"]["email"]=="admin@brightloop.com")
chk("me anon", anon.get("/api/auth/me").json()["user"] is None)

# every GET list as staff
for u in ["products","plans","tax-rules","discounts","templates","customers","subscriptions","invoices","payments","billing","dashboard","users"]:
    r=c.get("/api/"+u, headers=A); chk("GET "+u, r.status_code==200, r.text[:200])
d=c.get("/api/dashboard?period=this_month", headers=A).json(); print(json.dumps(d["kpis"]))
for p in ["last_month","quarter","year","all"]:
    chk("dashboard "+p, c.get("/api/dashboard?period="+p, headers=A).status_code==200)
# roles
chk("customer cannot list customers", c.get("/api/customers", headers=C).status_code==403)
chk("staff cannot create product", c.post("/api/products", headers=S, json={"name":"x","salesPrice":1,"costPrice":1}).status_code==403)
chk("staff cannot create user", c.post("/api/users", headers=S, json={"name":"n","email":"n@x.com","password":"Abcdefgh1!"}).status_code==403)
chk("staff cannot create discount", c.post("/api/discounts", headers=S, json={}).status_code==403)
chk("anon 401", anon.get("/api/invoices").status_code==401)
# customer scope
ci=c.get("/api/invoices", headers=C).json()["invoices"]; cs=c.get("/api/subscriptions", headers=C).json()["subscriptions"]
chk("customer sees own only", all(i["customer"]["name"]=="Kaveri Textiles" for i in ci) and all(s["customer"]["name"]=="Kaveri Textiles" for s in cs), f"{len(ci)} {len(cs)}")
chk("customer plans catalogue", "costPrice" not in json.dumps(c.get("/api/plans", headers=C).json()))
other=[i for i in c.get("/api/invoices", headers=A).json()["invoices"] if i["customer"]["name"]!="Kaveri Textiles"][0]
chk("customer blocked from other invoice", c.get(f"/api/invoices/{other['id']}", headers=C).status_code==403)
chk("customer cannot self-pay", c.post("/api/payments", headers=C, json={"invoiceId":other["id"],"method":"CASH","amount":1}).status_code==403)

# register / password policy / dup email
chk("weak pw", c.post("/api/auth/register", json={"name":"A","email":"a@x.com","password":"short"}).status_code==400)
r=c.post("/api/auth/register", json={"name":"New Co","email":"new@co.com","password":"Strong#Pass1"}); chk("register", r.status_code==201, r.text)
chk("dup email", c.post("/api/auth/register", json={"name":"New Co","email":"NEW@co.com","password":"Strong#Pass1"}).status_code==409)
# forgot/reset
os.environ.pop("DEMO_MODE",None)
rk=c.post("/api/auth/forgot", json={"email":"new@co.com"}).json(); ru=c.post("/api/auth/forgot", json={"email":"nobody@nowhere.com"}).json()
chk("forgot leaks nothing outside demo mode", rk=={"sent":True,"resetUrl":None} and rk==ru, (rk,ru))
os.environ["DEMO_MODE"]="1"
r=c.post("/api/auth/forgot", json={"email":"new@co.com"}).json(); chk("forgot link (demo mode)", r["resetUrl"].startswith("/?reset="))
os.environ.pop("DEMO_MODE",None)
tok=r["resetUrl"].split("=")[1]
chk("reset", c.post("/api/auth/reset", json={"token":tok,"password":"Another#Pass2"}).status_code==200)
chk("reset reuse blocked", c.post("/api/auth/reset", json={"token":tok,"password":"Another#Pass3"}).status_code==400)
chk("login new pw", c.post("/api/auth/login", json={"email":"new@co.com","password":"Another#Pass2"}).status_code==200)
chk("change pw", c.put("/api/auth/password", headers=A, json={"current":"Admin@123!","next":"Admin@123!"}).status_code==200)

# staff creation by admin
chk("admin adds staff", c.post("/api/users", headers=A, json={"name":"Zed","email":"zed@brightloop.com","password":"Staff@4567!"}).status_code==201)

# catalog CRUD
r=c.post("/api/products", headers=A, json={"name":"Odoo Connector","type":"ADDON","salesPrice":1000,"costPrice":300,"variants":[{"name":"Brand","value":"Odoo","priceDelta":560}]}); chk("create product", r.status_code==201 and r.json()["product"]["variants"][0]["priceDelta"]==560, r.text)
prod=r.json()["product"]
r=c.patch(f"/api/products/{prod['id']}", headers=A, json={"salesPrice":1100,"variants":[{"id":prod["variants"][0]["id"],"name":"Brand","value":"Odoo","priceDelta":600},{"name":"Brand","value":"Zoho","priceDelta":100}]}); chk("patch product", r.status_code==200 and len(r.json()["product"]["variants"])==2, r.text)
r=c.post("/api/plans", headers=A, json={"name":"Connector Monthly","productId":prod["id"],"price":1100,"billingCycle":"MONTHLY","minQuantity":2,"canPause":True,"canCloseEarly":True,"canRenew":True}); chk("create plan", r.status_code==201, r.text); plan=r.json()["plan"]
r=c.patch(f"/api/plans/{plan['id']}", headers=A, json={"autoClose":True}); chk("patch plan", r.json()["plan"]["autoClose"] is True)
chk("tax rule create", c.post("/api/tax-rules", headers=A, json={"name":"VAT 20%","rate":20}).status_code==201)
r=c.post("/api/discounts", headers=A, json={"name":"Big deal","type":"PERCENTAGE","value":20,"scope":"SUBSCRIPTION","minQuantity":4,"startDate":"2026-10-01","endDate":"2027-12-31","maxUses":2}); chk("create discount", r.status_code==201, r.text); disc=r.json()["discount"]
chk("tpl create", c.post("/api/templates", headers=S, json={"name":"T","planId":plan["id"],"validDays":10,"lines":[{"productId":prod["id"],"quantity":2,"unitPrice":1100,"taxRate":18}]}).status_code==201)
tid=c.get("/api/templates", headers=A).json()["templates"][0]["id"]; chk("tpl get", c.get(f"/api/templates/{tid}", headers=A).status_code==200)

# subscription lifecycle + billing
cust=c.get("/api/customers?q=Nimbus", headers=A).json()["customers"][0]
chk("min qty enforced", c.post("/api/subscriptions", headers=S, json={"customerId":cust["id"],"planId":plan["id"],"lines":[{"productId":prod["id"],"quantity":1,"unitPrice":1100,"taxRate":18}]}).status_code==400)
chk("bad tax rejected", c.post("/api/subscriptions", headers=S, json={"customerId":cust["id"],"planId":plan["id"],"lines":[{"productId":prod["id"],"quantity":5,"unitPrice":1100,"taxRate":7}]}).status_code==400)
r=c.post("/api/subscriptions", headers=S, json={"customerId":cust["id"],"planId":plan["id"],"paymentTerms":"NET_15","startDate":"2026-08-31","lines":[{"productId":prod["id"],"quantity":5,"unitPrice":1100,"taxRate":18}]}); chk("create sub", r.status_code==201, r.text); sub=r.json()["subscription"]
chk("starts draft", sub["status"]=="DRAFT")
chk("cannot bill draft", c.post(f"/api/subscriptions/{sub['id']}/invoice", headers=S).status_code==400)
for a,exp in [("send_quote","QUOTATION"),("confirm","CONFIRMED"),("activate","ACTIVE")]:
    r=c.post(f"/api/subscriptions/{sub['id']}/transition", headers=S, json={"action":a}); chk(a, r.status_code==200 and r.json()["subscription"]["status"]==exp, r.text)
nb=c.get(f"/api/subscriptions/{sub['id']}", headers=S).json()["subscription"]["nextBillingDate"]; print("nextBilling after activate", nb)
# billing run twice: no duplicates; catch-up of missed cycles (start 2026-08-31 => Aug31, Sep30 (clamped), Oct30 ...)
# back-date the schedule 3 months to prove catch-up works
from sqlalchemy import update as _u
with main.SessionLocal() as _db:
    _db.execute(_u(main.Subscription).where(main.Subscription.id==sub["id"]).values(next_billing_date=main.add_months(main.today_utc(),-3))); _db.commit()
prev=c.get("/api/billing", headers=S).json(); print("due before:", prev["dueCount"])
r1=c.post("/api/billing", headers=S).json(); print("run1", r1["invoicesCreated"], r1["subscriptionsClosed"], r1["skipped"][:3])
r2_=c.post("/api/billing", headers=S).json(); chk("second run creates nothing (idempotent)", r2_["invoicesCreated"]==0, r2_)
invs=c.get(f"/api/invoices?customerId={cust['id']}", headers=S).json()["invoices"]
mine=[i for i in invs if i["subscription"] and i["subscription"]["id"]==sub["id"]]
chk("catch-up made 4 invoices (3 months back + now)", len(mine)==4, len(mine))
chk("period starts unique", len({i["periodStart"] for i in mine})==len(mine))
inv=sorted(mine,key=lambda i:i["number"])[0]; d=c.get(f"/api/invoices/{inv['id']}", headers=S).json()["invoice"]
print("invoice", d["number"], d["subtotal"], d["discountTotal"], d["discountNote"], d["taxTotal"], d["total"], d["status"])
chk("discount applied automatically", d["discountTotal"]>0 and "Big deal" in (d["discountNote"] or ""))
with main.SessionLocal() as _db:
    used=_db.get(main.DiscountRule, disc["id"]).used_count
chk("discount usage cap honoured (maxUses=2)", used==2, used)
chk("math reconciles", abs(d["subtotal"]-d["discountTotal"]+d["taxTotal"]-d["total"])<0.02)
chk("pay draft blocked", c.post("/api/payments", headers=S, json={"invoiceId":inv["id"],"method":"UPI","amount":10}).status_code==400)
chk("customer hidden draft", c.get("/api/invoices", headers=C).status_code==200)
for a in ["confirm","send"]:
    r=c.post(f"/api/invoices/{inv['id']}/action", headers=S, json={"action":a}); chk("inv "+a, r.status_code==200, r.text)
chk("overpay blocked", c.post("/api/payments", headers=S, json={"invoiceId":inv["id"],"method":"CASH","amount":d["total"]+50}).status_code==400)
half=round(d["total"]/2,2)
r=c.post("/api/payments", headers=S, json={"invoiceId":inv["id"],"method":"UPI","amount":half,"date":"2026-10-30","note":"part"}); chk("partial pay", r.status_code==201 and r.json()["invoiceStatus"]=="CONFIRMED", r.text)
chk("cancel blocked after payment", c.post(f"/api/invoices/{inv['id']}/action", headers=S, json={"action":"cancel"}).status_code==400)
r=c.post("/api/payments", headers=S, json={"invoiceId":inv["id"],"method":"BANK_TRANSFER","amount":round(d["total"]-half,2)}); chk("final pay -> PAID", r.status_code==201 and r.json()["invoiceStatus"]=="PAID" and r.json()["balance"]==0, r.text)
# cancelled invoice gives its period back to billing day
live=[i for i in c.get(f"/api/invoices?customerId={cust['id']}", headers=S).json()["invoices"] if i["subscription"] and i["subscription"]["id"]==sub["id"] and i["status"]!="CANCELLED"]
latest=max(live,key=lambda i:i["periodStart"])
chk("cancel latest invoice", c.post(f"/api/invoices/{latest['id']}/action", headers=S, json={"action":"cancel"}).status_code==200)
rb=c.post("/api/billing", headers=S).json(); chk("billing day re-issues cancelled period", rb["invoicesCreated"]==1, rb)
live2=[i for i in c.get(f"/api/invoices?customerId={cust['id']}", headers=S).json()["invoices"] if i["subscription"] and i["subscription"]["id"]==sub["id"] and i["status"]!="CANCELLED"]
chk("still exactly one live invoice per period", len(live2)==len({i["periodStart"] for i in live2})==4, len(live2))
# bill now conflict
r=c.post(f"/api/subscriptions/{sub['id']}/invoice", headers=S); print("bill-now:", r.status_code, r.text[:120])
# pause/resume/close/renew + customer self-service
chk("pause", c.post(f"/api/subscriptions/{sub['id']}/transition", headers=S, json={"action":"pause"}).status_code==200)
chk("resume", c.post(f"/api/subscriptions/{sub['id']}/transition", headers=S, json={"action":"resume"}).status_code==200)
r=c.post(f"/api/subscriptions/{sub['id']}/transition", headers=S, json={"action":"renew"}); chk("renew", r.status_code==201 and r.json()["renewed"], r.text)
chk("renew twice blocked", c.post(f"/api/subscriptions/{sub['id']}/transition", headers=S, json={"action":"renew"}).status_code==400)
rp=c.post("/api/plans", headers=A, json={"name":"Locked","productId":prod["id"],"price":500,"billingCycle":"MONTHLY","canPause":True,"canCloseEarly":False}).json()["plan"]
s2=c.post("/api/subscriptions", headers=S, json={"customerId":cust["id"],"planId":rp["id"],"lines":[{"productId":prod["id"],"quantity":1,"unitPrice":500,"taxRate":18}]}).json()["subscription"]
for a in ["send_quote","confirm","activate","pause"]: c.post(f"/api/subscriptions/{s2['id']}/transition", headers=S, json={"action":a})
chk("cannot close early via pause", c.post(f"/api/subscriptions/{s2['id']}/transition", headers=S, json={"action":"close"}).status_code==400)
s3=c.post("/api/subscriptions", headers=S, json={"customerId":cust["id"],"planId":plan["id"],"lines":[{"productId":prod["id"],"quantity":2,"unitPrice":1100,"taxRate":18}]}).json()["subscription"]
r=c.post(f"/api/subscriptions/{s3['id']}/transition", headers=S, json={"action":"close"}); chk("close reason before activation", r.json()["subscription"]["closeReason"]=="Cancelled before activation", r.text)
chk("customer cannot activate", c.post(f"/api/subscriptions/{cs[0]['id']}/transition", headers=C, json={"action":"activate"}).status_code==403)
chk("customer cannot touch others", c.post(f"/api/subscriptions/{sub['id']}/transition", headers=C, json={"action":"close"}).status_code==403)
# filters
chk("filter status", c.get("/api/subscriptions?status=ACTIVE&q=SUB", headers=A).status_code==200)
chk("filter invoices dates", c.get("/api/invoices?from=2026-01-01&to=2026-12-31&status=PAID&q=INV", headers=A).status_code==200)
chk("filter payments", c.get("/api/payments?method=UPI&from=2026-01-01&to=2026-12-31&q=PAY", headers=A).status_code==200)
chk("customer detail", c.get(f"/api/customers/{cust['id']}", headers=A).status_code==200)
chk("customer patch", c.patch(f"/api/customers/{cust['id']}", headers=A, json={"phone":"123","taxId":"GSTIN1"}).json()["customer"]["taxId"]=="GSTIN1")
chk("customer create", c.post("/api/customers", headers=S, json={"name":"Acme","email":"acme@x.com","taxId":"T1","city":"Pune"}).status_code==201)
chk("reseed admin", c.post("/api/seed", headers=A).status_code==200)
chk("logout", c.post("/api/auth/logout", headers=A).status_code==200 and c.get("/api/auth/me", headers=A).json()["user"] is None)
print("\nFAILS:", fails)
sys.exit(1 if fails else 0)
