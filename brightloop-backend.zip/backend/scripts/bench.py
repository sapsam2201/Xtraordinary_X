"""Performance check for the "every page under two seconds with thousands of subscriptions" requirement.

    python scripts/bench.py            # seeds 5000 bulk customers/subscriptions into a temp DB, times the API
    python scripts/bench.py 10000
"""
import os
import statistics
import sys
import tempfile
import time

os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.mkdtemp(), "bench.db")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient  # noqa: E402

import logging  # noqa: E402
import main  # noqa: E402
logging.getLogger("httpx").setLevel(logging.WARNING)

N = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
main.init_db()
t = time.perf_counter()
with main.SessionLocal() as s:
    main.run_seed(s, bulk=N)
print(f"seeded {N} bulk records in {time.perf_counter() - t:.1f}s")

c = TestClient(main.app)
tok = c.post("/api/auth/login", json={"email": "admin@brightloop.com", "password": "Admin@123!"}).json()["token"]
H = {"Authorization": "Bearer " + tok}

CASES = [
    ("Dashboard", "/api/dashboard"),
    ("Subscriptions page 1", "/api/subscriptions?limit=10&sort=number&dir=desc"),
    ("Subscriptions search", "/api/subscriptions?limit=10&q=Bulk Customer 42"),
    ("Subscriptions ACTIVE filter", "/api/subscriptions?limit=10&status=ACTIVE"),
    ("Invoices page 1", "/api/invoices?limit=10"),
    ("Invoices sorted by customer", "/api/invoices?limit=10&sort=customer&dir=asc"),
    ("Invoices overdue summary", "/api/invoices?limit=10&status=CONFIRMED"),
    ("Payments page 1", "/api/payments?limit=10"),
    ("Billing preview", "/api/billing"),
    ("Invoices CSV export", "/api/invoices.csv"),
]
worst = 0.0
print(f"\n{'endpoint':34} {'median':>8} {'worst':>8}")
for name, url in CASES:
    ts = []
    for _ in range(3):
        a = time.perf_counter()
        r = c.get(url, headers=H)
        ts.append(time.perf_counter() - a)
        assert r.status_code == 200, (url, r.text[:200])
    worst = max(worst, max(ts))
    print(f"{name:34} {statistics.median(ts) * 1000:7.0f}ms {max(ts) * 1000:7.0f}ms")

a = time.perf_counter()
res = c.post("/api/billing", headers=H).json()
dt = time.perf_counter() - a
print(f"\nBilling day: {res['invoicesCreated']} invoices in {dt:.1f}s (background job, not a page load)")
print("PASS: every page < 2s" if worst < 2 else f"SLOW: worst page {worst:.2f}s")
sys.exit(0 if worst < 2 else 1)
