#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install -q -r requirements.txt
export DEMO_MODE=${DEMO_MODE:-1}
[ -f brightloop.db ] || python main.py seed
python main.py
