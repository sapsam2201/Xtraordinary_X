@echo off
cd /d %~dp0
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
pip install -q -r requirements.txt
if "%DEMO_MODE%"=="" set DEMO_MODE=1
if not exist brightloop.db python main.py seed
python main.py
