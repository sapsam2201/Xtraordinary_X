"""API routes: AI assistant (Groq)."""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from fastapi import Request

from app.deps import Body0, anyone, get_db
from app.models import User
from app.security import rate_limit
from app.services.chat import answer, chat_enabled, clean_history
from app.utils import ApiError


router = APIRouter()


@router.get("/chat/status")
def chat_status(_: User = Depends(anyone)):
    """The UI uses this to hide the chat button when no GROQ_API_KEY is configured."""
    return {"enabled": chat_enabled()}


@router.post("/chat")
def chat(req: Request, b: dict = Body0, user: User = Depends(anyone), db: Session = Depends(get_db)):
    if not chat_enabled():
        raise ApiError(503, "The AI assistant is not configured. Set GROQ_API_KEY on the server.")
    rate_limit(req, f"chat:{user.id}", 30, 600)  # 30 questions per 10 minutes per user (and IP)
    return answer(db, user, clean_history(b.get("messages")))
