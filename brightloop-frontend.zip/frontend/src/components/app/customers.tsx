'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { api } from './api-client'
import { fmtDate, fmtMoney } from './format'
import { EmptyState, ErrorNote, PageHeader, StatusBadge } from './ui-bits'
import { Segmented, useCountUp } from './interactive'
import { Skeleton } from '@/components/ui/skeleton'
import type { Customer, Invoice, Subscription } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from '@/hooks/use-toast'
import {
  Building2, Eye, Loader2, Mail, MapPin, Pencil, Phone, Plus, Search, Trash2, Users,
} from 'lucide-react'

type CustomerDetail = Customer & {
  subscriptions: (Subscription & { plan?: { name: string; billingCycle: string } | null })[]
  invoices: Invoice[]
  _count: { subscriptions: number; invoices: number; payments: number }
}

const EMPTY: Partial<Customer> = { name: '', email: '', phone: '', company: '', address: '', city: '', country: '', taxId: '', notes: '' }

export function Customers() {
  const [customers, setCustomers] = useState<Customer[] | null>(null)
  const [q, setQ] = useState('')
  const [sort, setSort] = useState<'name' | 'subs' | 'invoices'>('name')
  const [error, setError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<Customer | null>(null)
  const [form, setForm] = useState<Partial<Customer>>(EMPTY)
  const [busy, setBusy] = useState(false)
  const [detail, setDetail] = useState<CustomerDetail | null>(null)

  const load = useCallback(async () => {
    setError('')
    try {
      const res = await api.get<{ customers: Customer[] }>(`/api/customers?q=${encodeURIComponent(q)}`)
      setCustomers(res.customers)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load customers')
    }
  }, [q])

  useEffect(() => { load() }, [load])

  const stats = useMemo(() => {
    const list = customers ?? []
    return { total: list.length }
  }, [customers])

  const sorted = useMemo(() => {
    const list = [...(customers ?? [])]
    if (sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name))
    if (sort === 'subs') list.sort((a, b) => (b._count?.subscriptions ?? 0) - (a._count?.subscriptions ?? 0))
    if (sort === 'invoices') list.sort((a, b) => (b._count?.invoices ?? 0) - (a._count?.invoices ?? 0))
    return list
  }, [customers, sort])

  async function save() {
    setBusy(true)
    try {
      if (editing) {
        await api.patch(`/api/customers/${editing.id}`, form)
        toast({ title: 'Customer updated' })
      } else {
        await api.post('/api/customers', form)
        toast({ title: 'Customer added' })
      }
      setFormOpen(false)
      setEditing(null)
      setForm(EMPTY)
      await load()
    } catch (err) {
      toast({ title: 'Could not save', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function remove(c: Customer) {
    if (!confirm(`Delete ${c.name}? This only works for customers without subscriptions.`)) return
    try {
      await api.del(`/api/customers/${c.id}`)
      toast({ title: 'Customer deleted' })
      await load()
    } catch (err) {
      toast({ title: 'Could not delete', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function openDetail(c: Customer) {
    try {
      const res = await api.get<{ customer: CustomerDetail }>(`/api/customers/${c.id}`)
      setDetail(res.customer)
    } catch (err) {
      toast({ title: 'Could not open customer', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  if (!customers && !error) {
    return (
      <div aria-busy="true">
        <div className="mb-5 h-14 w-64 animate-pulse rounded-lg bg-muted/70" />
        <div className="mb-5 h-9 w-full max-w-sm animate-pulse rounded-md bg-muted/60" />
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-xl" style={{ opacity: 1 - i * 0.1 }} />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Customers"
        subtitle={`${stats.total} businesses from small shops to large companies — all their subscriptions and invoices live here.`}
        actions={
          <Button onClick={() => { setEditing(null); setForm(EMPTY); setFormOpen(true) }}>
            <Plus className="mr-1.5 h-4 w-4" /> Add customer
          </Button>
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative w-full sm:max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search name, email or city…" className="pl-8" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Segmented
          value={sort}
          onChange={setSort}
          options={[
            { value: 'name', label: 'A–Z' },
            { value: 'subs', label: 'Most subs' },
            { value: 'invoices', label: 'Most invoices' },
          ]}
          size="sm"
          aria-label="Sort customers"
        />
      </div>

      {error ? <ErrorNote message={error} /> : null}

      {customers && customers.length === 0 ? (
        <EmptyState icon={Users} title="No customers found" hint="Add your first customer to start selling subscriptions." />
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3 stagger">
          {sorted.map((c) => (
            <div key={c.id} className="group rounded-xl border bg-card p-4 shadow-sm transition-shadow hover:shadow-md">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/12 text-sm font-bold text-primary">
                    {c.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{c.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{c.email}</p>
                  </div>
                </div>
              </div>
              <div className="mt-3 space-y-1 text-xs text-muted-foreground">
                {c.city || c.country ? (
                  <p className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> {[c.city, c.country].filter(Boolean).join(', ')}</p>
                ) : null}
                {c.phone ? <p className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> {c.phone}</p> : null}
                {c.company ? <p className="flex items-center gap-1.5"><Building2 className="h-3.5 w-3.5" /> {c.company}</p> : null}
              </div>
              <div className="mt-3 flex items-center gap-2 border-t pt-3 text-xs text-muted-foreground">
                <span className="rounded-full bg-emerald-100 px-2 py-0.5 font-semibold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                  {c._count?.subscriptions ?? 0} subs
                </span>
                <span className="rounded-full bg-muted px-2 py-0.5">{c._count?.invoices ?? 0} invoices</span>
                <div className="ml-auto flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openDetail(c)} aria-label="View customer">
                    <Eye className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditing(c); setForm(c); setFormOpen(true) }} aria-label="Edit customer">
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-destructive" onClick={() => remove(c)} aria-label="Delete customer">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* form dialog */}
      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false) }}>
        <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto scroll-slim">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit customer' : 'Add customer'}</DialogTitle>
            <DialogDescription>Each email belongs to only one customer account.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Name *</Label>
              <Input value={form.name ?? ''} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Kaveri Textiles" />
            </div>
            <div className="space-y-1.5">
              <Label>Email *</Label>
              <Input type="email" value={form.email ?? ''} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="accounts@company.com" />
            </div>
            <div className="space-y-1.5">
              <Label>Phone</Label>
              <Input value={form.phone ?? ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Company</Label>
              <Input value={form.company ?? ''} onChange={(e) => setForm({ ...form, company: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>City</Label>
              <Input value={form.city ?? ''} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Country</Label>
              <Input value={form.country ?? ''} onChange={(e) => setForm({ ...form, country: e.target.value })} />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Address</Label>
              <Input value={form.address ?? ''} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Tax ID / GSTIN</Label>
              <Input value={form.taxId ?? ''} onChange={(e) => setForm({ ...form, taxId: e.target.value })} />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Notes</Label>
              <Textarea rows={2} value={form.notes ?? ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={busy || !form.name || !form.email}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
              {editing ? 'Save changes' : 'Add customer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* detail dialog */}
      <Dialog open={!!detail} onOpenChange={(open) => { if (!open) setDetail(null) }}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto scroll-slim">
          {detail ? (
            <>
              <DialogHeader>
                <DialogTitle>{detail.name}</DialogTitle>
                <DialogDescription className="flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span className="inline-flex items-center gap-1"><Mail className="h-3.5 w-3.5" /> {detail.email}</span>
                  {detail.phone ? <span className="inline-flex items-center gap-1"><Phone className="h-3.5 w-3.5" /> {detail.phone}</span> : null}
                  {detail.taxId ? <span>GSTIN {detail.taxId}</span> : null}
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-3 gap-3">
                <CountStat value={detail._count.subscriptions} label="Subscriptions" />
                <CountStat value={detail._count.invoices} label="Invoices" />
                <CountStat value={detail._count.payments} label="Payments" />
              </div>
              <Tabs defaultValue="subs">
                <TabsList className="w-full">
                  <TabsTrigger value="subs" className="flex-1">Subscriptions ({detail.subscriptions.length})</TabsTrigger>
                  <TabsTrigger value="invoices" className="flex-1">Invoices ({detail.invoices.length})</TabsTrigger>
                </TabsList>
                <TabsContent value="subs" className="mt-3">
                  {detail.subscriptions.length === 0 ? (
                    <p className="rounded-lg border border-dashed py-6 text-center text-sm text-muted-foreground">No subscriptions yet.</p>
                  ) : (
                    <div className="max-h-64 space-y-1 overflow-y-auto scroll-slim">
                      {detail.subscriptions.map((s) => (
                        <div key={s.id} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm transition-colors hover:bg-muted/40">
                          <span className="font-medium">{s.number}</span>
                          <span className="text-xs text-muted-foreground">{s.plan?.name ?? 'custom'} · since {fmtDate(s.startDate)}</span>
                          <span className="ml-auto"><StatusBadge status={s.status} /></span>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
                <TabsContent value="invoices" className="mt-3">
                  {detail.invoices.length === 0 ? (
                    <p className="rounded-lg border border-dashed py-6 text-center text-sm text-muted-foreground">No invoices yet.</p>
                  ) : (
                    <div className="max-h-64 space-y-1 overflow-y-auto scroll-slim">
                      {detail.invoices.map((i) => (
                        <div key={i.id} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm transition-colors hover:bg-muted/40">
                          <span className="font-medium">{i.number}</span>
                          <span className="text-xs text-muted-foreground">{fmtDate(i.issueDate)}</span>
                          <span className="ml-auto font-semibold">{fmtMoney(i.total)}</span>
                          <StatusBadge status={i.status} />
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
              {detail.notes ? (
                <p className="rounded-lg bg-muted/50 px-3 py-2 text-sm text-muted-foreground">{detail.notes}</p>
              ) : null}
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  )
}

/** Small stat tile with an animated count-up number. */
function CountStat({ value, label }: { value: number; label: string }) {
  const n = useCountUp(value)
  return (
    <div className="rounded-lg border p-3 text-center transition-colors hover:border-primary/40">
      <p className="num text-xl font-bold">{Math.round(n)}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  )
}
