'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { CYCLE_LABEL, fmtDate, fmtMoney, toDateInput } from './format'
import { ErrorNote, PageHeader, Spinner } from './ui-bits'
import type { Plan, Product } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from '@/hooks/use-toast'
import {
  Archive, CalendarRange, Layers, Loader2, Pencil, PauseCircle, Plus, RotateCcw, Zap,
} from 'lucide-react'

const EMPTY_FORM = {
  name: '', description: '', productId: '', price: '', billingCycle: 'MONTHLY',
  minQuantity: '1', availableFrom: '', availableTo: '',
  autoClose: false, canCloseEarly: true, canPause: false, canRenew: false,
}

export function Plans({ isAdmin }: { isAdmin: boolean }) {
  const [plans, setPlans] = useState<Plan[] | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [error, setError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<Plan | null>(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    setError('')
    try {
      const [p, pr] = await Promise.all([
        api.get<{ plans: Plan[] }>('/api/plans'),
        api.get<{ products: Product[] }>('/api/products'),
      ])
      setPlans(p.plans)
      setProducts(pr.products)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load plans')
    }
  }, [])

  useEffect(() => { load() }, [load])

  function openCreate() {
    setEditing(null)
    setForm(EMPTY_FORM)
    setFormOpen(true)
  }

  function openEdit(p: Plan) {
    setEditing(p)
    setForm({
      name: p.name, description: p.description ?? '', productId: p.productId ?? '',
      price: String(p.price), billingCycle: p.billingCycle,
      minQuantity: String(p.minQuantity),
      availableFrom: toDateInput(p.availableFrom), availableTo: toDateInput(p.availableTo),
      autoClose: p.autoClose, canCloseEarly: p.canCloseEarly, canPause: p.canPause, canRenew: p.canRenew,
    })
    setFormOpen(true)
  }

  async function save() {
    setBusy(true)
    try {
      const payload = { ...form, price: Number(form.price) || 0, minQuantity: Number(form.minQuantity) || 1 }
      if (editing) {
        await api.patch(`/api/plans/${editing.id}`, payload)
        toast({ title: 'Plan updated' })
      } else {
        await api.post('/api/plans', payload)
        toast({ title: 'Plan created' })
      }
      setFormOpen(false)
      await load()
    } catch (err) {
      toast({ title: 'Could not save plan', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function archive(p: Plan) {
    if (!confirm(p._count?.subscriptions ? `Archive "${p.name}"? It has subscriptions, so it will be deactivated instead of deleted.` : `Delete "${p.name}"?`)) return
    try {
      await api.del(`/api/plans/${p.id}`)
      toast({ title: 'Plan removed' })
      await load()
    } catch (err) {
      toast({ title: 'Could not remove plan', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  if (!plans && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Plans"
        subtitle="What it costs, how often it bills, minimum quantity, availability — and which lifecycle moves each plan allows."
        actions={
          isAdmin ? (
            <Button onClick={openCreate}><Plus className="mr-1.5 h-4 w-4" /> Add plan</Button>
          ) : (
            <p className="text-xs text-muted-foreground">Only the admin can change plans — you have view access.</p>
          )
        }
      />

      {error ? <ErrorNote message={error} /> : null}

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
        {(plans ?? []).map((p) => (
          <div key={p.id} className={`flex flex-col rounded-xl border bg-card p-4 shadow-sm transition-shadow hover:shadow-md ${p.active ? '' : 'opacity-60'}`}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold leading-tight">{p.name}</p>
                <p className="text-xs text-muted-foreground">{p.product?.name ?? 'Custom bundle'} · min {p.minQuantity} unit{p.minQuantity > 1 ? 's' : ''}</p>
              </div>
              {isAdmin ? (
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(p)} aria-label="Edit plan">
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-destructive" onClick={() => archive(p)} aria-label="Remove plan">
                    <Archive className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ) : null}
            </div>

            <div className="mt-3 flex items-baseline gap-1.5">
              <p className="text-2xl font-bold">{fmtMoney(p.price)}</p>
              <p className="text-sm text-muted-foreground">/ {CYCLE_LABEL[p.billingCycle]?.toLowerCase() ?? p.billingCycle.toLowerCase()}</p>
            </div>

            {p.description ? <p className="mt-2 text-xs text-muted-foreground">{p.description}</p> : null}

            <div className="mt-3 flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <CalendarRange className="h-3.5 w-3.5" />
              {p.availableFrom ? `from ${fmtDate(p.availableFrom)}` : 'always'}
              {p.availableTo ? ` until ${fmtDate(p.availableTo)}` : ' onward'}
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5 border-t pt-3">
              {p.autoClose ? <Flag icon={Zap} label="Auto-closes" tone="amber" /> : null}
              {p.canCloseEarly ? <Flag icon={Archive} label="Early close" tone="default" /> : null}
              {p.canPause ? <Flag icon={PauseCircle} label="Pausable" tone="default" /> : null}
              {p.canRenew ? <Flag icon={RotateCcw} label="Renewable" tone="emerald" /> : null}
              {!p.active ? <span className="rounded-full bg-zinc-200 px-2 py-0.5 text-[10px] font-semibold text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">inactive</span> : null}
            </div>

            <p className="mt-2 text-[11px] text-muted-foreground">{p._count?.subscriptions ?? 0} subscription(s) on this plan</p>
          </div>
        ))}
      </div>

      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false) }}>
        <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto scroll-slim">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit plan' : 'New plan'}</DialogTitle>
            <DialogDescription>Decide the price, cadence and exactly what customers can do with this plan.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Plan name *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="CRM Starter" />
            </div>
            <div className="space-y-1.5">
              <Label>Linked product</Label>
              <Select value={form.productId || 'none'} onValueChange={(v) => setForm({ ...form, productId: v === 'none' ? '' : v })}>
                <SelectTrigger aria-label="Linked product"><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {products.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Billing cycle</Label>
              <Select value={form.billingCycle} onValueChange={(v) => setForm({ ...form, billingCycle: v })}>
                <SelectTrigger aria-label="Billing cycle"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CYCLE_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Price (₹) *</Label>
              <Input type="number" min={0} value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="499" />
            </div>
            <div className="space-y-1.5">
              <Label>Minimum quantity</Label>
              <Input type="number" min={1} value={form.minQuantity} onChange={(e) => setForm({ ...form, minQuantity: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Available from</Label>
              <Input type="date" value={form.availableFrom} onChange={(e) => setForm({ ...form, availableFrom: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Available until</Label>
              <Input type="date" value={form.availableTo} onChange={(e) => setForm({ ...form, availableTo: e.target.value })} />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Description</Label>
              <Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>

            <div className="rounded-lg border p-3 sm:col-span-2">
              <p className="mb-2.5 flex items-center gap-1.5 text-[13px] font-semibold"><Layers className="h-4 w-4" /> Lifecycle rules for this plan</p>
              <div className="space-y-3">
                <SwitchRow label="Close on its own when the plan ends" checked={form.autoClose} onChange={(v) => setForm({ ...form, autoClose: v })} />
                <SwitchRow label="Can be closed early" checked={form.canCloseEarly} onChange={(v) => setForm({ ...form, canCloseEarly: v })} />
                <SwitchRow label="Can be paused" checked={form.canPause} onChange={(v) => setForm({ ...form, canPause: v })} />
                <SwitchRow label="Can be renewed" checked={form.canRenew} onChange={(v) => setForm({ ...form, canRenew: v })} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={busy || !form.name || form.price === ''}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
              {editing ? 'Save changes' : 'Create plan'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function SwitchRow({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between gap-3 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <Switch checked={checked} onCheckedChange={onChange} />
    </label>
  )
}

function Flag({ icon: Icon, label, tone }: { icon: typeof Zap; label: string; tone: 'amber' | 'emerald' | 'default' }) {
  const tones = {
    amber: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
    emerald: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
    default: 'bg-muted text-muted-foreground',
  }
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${tones[tone]}`}>
      <Icon className="h-3 w-3" /> {label}
    </span>
  )
}
