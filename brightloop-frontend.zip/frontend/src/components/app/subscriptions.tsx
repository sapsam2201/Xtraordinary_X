'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { api, getAll } from './api-client'
import { CYCLE_LABEL, fmtDate, fmtMoney, TERMS_LABEL, toDateInput } from './format'
import { EmptyState, ErrorNote, PageHeader, StatusBadge } from './ui-bits'
import { Pager, SortTh, TableSkeleton, useDebounced, useServerTable } from './interactive'
import { ExportButton, filterQuery } from './export-button'
import { LinesEditor, type LineDraft } from './lines-editor'
import type { Customer, Plan, Product, QuotationTemplate, Subscription, TaxRule } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from '@/hooks/use-toast'
import {
  ArrowRight, Ban, CalendarClock, CreditCard, Eye, FileStack, FileText, Loader2,
  MoreHorizontal, Pause, Play, Plus, RefreshCw, Search, Send, Zap,
} from 'lucide-react'

const STATUS_TABS = ['ALL', 'DRAFT', 'QUOTATION', 'CONFIRMED', 'ACTIVE', 'PAUSED', 'CLOSED']

export function Subscriptions({
  onChanged,
  openInvoiceId,
  presetQuery,
  presetStatus,
}: {
  onChanged?: () => void
  openInvoiceId?: string | null
  presetQuery?: { q: string; n: number }
  presetStatus?: { status: string; n: number }
}) {
  const [subs, setSubs] = useState<Subscription[] | null>(null)
  const [total, setTotal] = useState(0)
  const [counts, setCounts] = useState<Record<string, number>>({})
  const table = useServerTable({ initialSort: { key: 'number', dir: 'desc' }, pageSize: 10 })
  const reqId = useRef(0)
  const [customers, setCustomers] = useState<Customer[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [plans, setPlans] = useState<Plan[]>([])
  const [taxRules, setTaxRules] = useState<TaxRule[]>([])
  const [templates, setTemplates] = useState<QuotationTemplate[]>([])
  const [status, setStatus] = useState('ALL')
  const [q, setQ] = useState('')
  const [error, setError] = useState('')
  const [detail, setDetail] = useState<Subscription | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [busyAction, setBusyAction] = useState('')

  const qd = useDebounced(q, 300)
  const { apply: applyPaging, setPage } = table

  // Only the visible page of subscriptions is fetched; status badges come from `counts`.
  const loadList = useCallback(async () => {
    const id = ++reqId.current
    try {
      const params = new URLSearchParams()
      if (status !== 'ALL') params.set('status', status)
      if (qd.trim()) params.set('q', qd.trim())
      applyPaging(params)
      const res = await api.get<{ subscriptions: Subscription[]; total: number; counts: Record<string, number> }>(`/api/subscriptions?${params}`)
      if (id !== reqId.current) return
      setSubs(res.subscriptions)
      setTotal(res.total)
      setCounts(res.counts)
      setError('')
    } catch (err) {
      if (id === reqId.current) setError(err instanceof Error ? err.message : 'Failed to load')
    }
  }, [status, qd, applyPaging])

  useEffect(() => { loadList() }, [loadList])
  useEffect(() => { setPage(1) }, [status, qd, setPage])

  const loadLookups = useCallback(async () => {
    try {
      const [c, p, t, tr, tp] = await Promise.all([
        getAll<'customers', Customer>('/api/customers', 'customers'),
        api.get<{ products: Product[] }>('/api/products'),
        api.get<{ plans: Plan[] }>('/api/plans'),
        api.get<{ taxRules: TaxRule[] }>('/api/tax-rules'),
        api.get<{ templates: QuotationTemplate[] }>('/api/templates'),
      ])
      setCustomers(c.customers)
      setProducts(p.products)
      setPlans(t.plans)
      setTaxRules(tr.taxRules)
      setTemplates(tp.templates)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load')
    }
  }, [])

  // lookups (customers, products, plans, taxes, templates) load once; the list reloads via loadList
  useEffect(() => { loadLookups() }, [loadLookups])
  const load = loadList

  // Deep links from the dashboard: preset search text / status filter
  useEffect(() => {
    if (!presetQuery) return
    queueMicrotask(() => setQ(presetQuery.q))
  }, [presetQuery])
  useEffect(() => {
    if (!presetStatus) return
    queueMicrotask(() => setStatus(presetStatus.status))
  }, [presetStatus])

  async function openDetail(id: string) {
    setDetailLoading(true)
    try {
      const res = await api.get<{ subscription: Subscription }>(`/api/subscriptions/${id}`)
      setDetail(res.subscription)
    } catch (err) {
      toast({ title: 'Could not open subscription', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setDetailLoading(false)
    }
  }

  async function act(id: string, action: string, extra?: Record<string, unknown>) {
    setBusyAction(`${id}:${action}`)
    try {
      await api.post(`/api/subscriptions/${id}/transition`, { action, ...extra })
      toast({ title: 'Done', description: `Subscription ${action.replace('_', ' ')} completed.` })
      await load()
      if (detail?.id === id) await openDetail(id)
      onChanged?.()
    } catch (err) {
      toast({ title: 'Action failed', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusyAction('')
    }
  }

  async function billNow(id: string) {
    setBusyAction(`${id}:invoice`)
    try {
      const res = await api.post<{ invoice: { number: string } }>(`/api/subscriptions/${id}/invoice`)
      toast({ title: `Invoice ${res.invoice.number} created`, description: 'Taxes and discounts were applied automatically.' })
      await load()
      await openDetail(id)
      onChanged?.()
    } catch (err) {
      toast({ title: 'Could not create invoice', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusyAction('')
    }
  }

  const cycleTotal = (s: Subscription) =>
    s.lines.reduce((sum, l) => sum + l.quantity * l.unitPrice * (1 + l.taxRate / 100), 0)

  if (!subs && !error) return <TableSkeleton rows={7} cols={9} />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Subscriptions"
        subtitle="From draft to quotation to confirmed to active to closed — the whole lifecycle."
        actions={
          <div className="flex flex-wrap gap-2">
            <ExportButton url={`/api/subscriptions.csv${filterQuery({ status, q: qd.trim() })}`} filename="subscriptions.csv" />
            <Button onClick={() => setCreateOpen(true)}>
              <Plus className="mr-1.5 h-4 w-4" /> New subscription
            </Button>
          </div>
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap gap-1.5">
          {STATUS_TABS.map((s) => (
            <button key={s} onClick={() => setStatus(s)}
              className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                status === s ? 'border-primary bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:border-primary/40'
              }`}>
              {s === 'ALL' ? 'All' : s.charAt(0) + s.slice(1).toLowerCase()} <span className="opacity-60">{counts[s] ?? 0}</span>
            </button>
          ))}
        </div>
        <div className="relative ml-auto w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search number, customer, plan…" className="pl-8" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>

      {error ? <ErrorNote message={error} /> : null}

      {(subs ?? []).length === 0 ? (
        <EmptyState icon={RefreshCw} title="No subscriptions here" hint="Try a different status filter or create a new subscription." />
      ) : (
        <div className="overflow-hidden rounded-xl border bg-card shadow-sm">
          <div className="overflow-x-auto scroll-slim">
            <table className="w-full min-w-[860px] text-sm">
              <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  <SortTh label="Number" k="number" sort={table.sort} onSort={table.toggleSort} />
                  <SortTh label="Customer" k="customer" sort={table.sort} onSort={table.toggleSort} />
                  <SortTh label="Plan" k="plan" sort={table.sort} onSort={table.toggleSort} />
                  <th className="px-4 py-3 font-medium">Billing</th>
                  <th className="px-4 py-3 font-medium">Period</th>
                  <SortTh label="Next bill" k="next" sort={table.sort} onSort={table.toggleSort} />
                  <SortTh label="Status" k="status" sort={table.sort} onSort={table.toggleSort} />
                  <SortTh label="Total / cycle" k="cycleTotal" sort={table.sort} onSort={table.toggleSort} align="right" />
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {(subs ?? []).map((s) => {
                  const busyRow = busyAction.startsWith(`${s.id}:`)
                  return (
                    <tr key={s.id} tabIndex={0} role="button"
                      className={`group border-t transition-colors hover:bg-muted/40 focus-visible:bg-muted/40 focus-visible:outline-none ${busyRow ? 'opacity-60' : ''}`}
                      onClick={() => openDetail(s.id)}
                      onKeyDown={(e) => { if (e.key === 'Enter' && !busyRow) { e.preventDefault(); openDetail(s.id) } }}>
                      <td className="px-4 py-3 font-semibold group-hover:text-primary">{s.number}</td>
                      <td className="px-4 py-3">{s.customer?.name}</td>
                      <td className="px-4 py-3">{s.plan?.name ?? <span className="text-muted-foreground">—</span>}</td>
                      <td className="px-4 py-3">{s.plan ? CYCLE_LABEL[s.plan.billingCycle] : '—'}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {fmtDate(s.startDate)} → {s.expiryDate ? fmtDate(s.expiryDate) : 'open'}
                      </td>
                      <td className="px-4 py-3 text-xs">{s.nextBillingDate ? fmtDate(s.nextBillingDate) : '—'}</td>
                      <td className="px-4 py-3"><StatusBadge status={s.status} /></td>
                      <td className="px-4 py-3 text-right font-medium">{fmtMoney(cycleTotal(s))}</td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                          <Button variant="outline" size="sm" className="opacity-0 transition-opacity group-hover:opacity-100 focus-visible:opacity-100" onClick={() => openDetail(s.id)}>
                            <Eye className="mr-1 h-3.5 w-3.5" /> Open
                          </Button>
                          <RowActions
                            sub={s}
                            busy={busyAction}
                            onAct={act}
                            onBillNow={billNow}
                            onOpen={() => openDetail(s.id)}
                          />
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          <Pager page={table.page} totalPages={table.totalPagesFor(total)} total={total}
            pageSize={table.pageSize} onPage={table.setPage} onPageSize={table.setPageSize} />
        </div>
      )}

      {createOpen ? (
        <CreateSubscriptionDialog
          customers={customers}
          products={products}
          plans={plans}
          taxRules={taxRules}
          templates={templates}
          onClose={() => setCreateOpen(false)}
          onCreated={async () => {
            setCreateOpen(false)
            await load()
            onChanged?.()
            toast({ title: 'Subscription created', description: 'It starts as a draft — send it as a quotation when ready.' })
          }}
        />
      ) : null}

      {/* Detail dialog */}
      <Dialog open={!!detail || detailLoading} onOpenChange={(open) => { if (!open) setDetail(null) }}>
        <DialogContent
          className="max-h-[90vh] max-w-3xl overflow-y-auto scroll-slim"
          onInteractOutside={(e) => { if (detailLoading) e.preventDefault() }}
          onFocusOutside={(e) => e.preventDefault()}
        >
          {detail ? (
            <>
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-3">
                  <span>{detail.number}</span>
                  <StatusBadge status={detail.status} />
                </DialogTitle>
                <DialogDescription>
                  {detail.customer?.name} · {detail.plan?.name ?? 'custom'} · {detail.plan ? CYCLE_LABEL[detail.plan.billingCycle] : 'ad-hoc billing'}
                </DialogDescription>
              </DialogHeader>

              <div className="grid grid-cols-2 gap-3 rounded-lg border bg-muted/30 p-4 text-sm sm:grid-cols-4">
                <Info label="Start date" value={fmtDate(detail.startDate)} />
                <Info label="Expiry" value={detail.expiryDate ? fmtDate(detail.expiryDate) : 'Open ended'} />
                <Info label="Payment terms" value={TERMS_LABEL[detail.paymentTerms] ?? detail.paymentTerms} />
                <Info label="Next billing" value={detail.nextBillingDate ? fmtDate(detail.nextBillingDate) : '—'} />
                {detail.closeReason ? <Info label="Close reason" value={detail.closeReason} className="col-span-2" /> : null}
                {detail.notes ? <Info label="Notes" value={detail.notes} className="col-span-2" /> : null}
              </div>

              {/* lifecycle strip */}
              <LifecycleStrip status={detail.status} />

              <div className="overflow-hidden rounded-lg border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2 font-medium">Product</th>
                      <th className="px-3 py-2 font-medium text-right">Qty</th>
                      <th className="px-3 py-2 font-medium text-right">Unit</th>
                      <th className="px-3 py-2 font-medium text-right">Tax</th>
                      <th className="px-3 py-2 font-medium text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.lines.map((l) => (
                      <tr key={l.id} className="border-t">
                        <td className="px-3 py-2">
                          {l.product?.name ?? l.description}
                          {l.variantId && l.product?.variants ? (
                            (() => {
                              const v = l.product?.variants.find((x) => x.id === l.variantId)
                              return v ? <span className="ml-1.5 rounded bg-muted px-1.5 py-0.5 text-[11px]">{v.name}: {v.value}</span> : null
                            })()
                          ) : null}
                        </td>
                        <td className="px-3 py-2 text-right">{l.quantity}</td>
                        <td className="px-3 py-2 text-right">{fmtMoney(l.unitPrice)}</td>
                        <td className="px-3 py-2 text-right">{l.taxRate}%</td>
                        <td className="px-3 py-2 text-right font-medium">{fmtMoney(l.quantity * l.unitPrice)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {detail.invoices && detail.invoices.length > 0 ? (
                <div>
                  <p className="mb-2 text-[13px] font-semibold">Recent invoices</p>
                  <div className="space-y-1">
                    {detail.invoices.slice(0, 5).map((inv) => (
                      <div key={inv.id} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{inv.number}</span>
                        <span className="text-xs text-muted-foreground">{fmtDate(inv.issueDate)}</span>
                        <span className="ml-auto font-semibold">{fmtMoney(inv.total)}</span>
                        <StatusBadge status={inv.status} />
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}

              <DialogFooter className="flex-wrap gap-2">
                {detail.status === 'DRAFT' ? (
                  <Button onClick={() => act(detail.id, 'send_quote')} disabled={busyAction !== ''}>
                    <Send className="mr-1.5 h-4 w-4" /> Send as quotation
                  </Button>
                ) : null}
                {detail.status === 'QUOTATION' ? (
                  <Button onClick={() => act(detail.id, 'confirm')} disabled={busyAction !== ''}>
                    <Zap className="mr-1.5 h-4 w-4" /> Confirm quotation
                  </Button>
                ) : null}
                {detail.status === 'CONFIRMED' ? (
                  <Button onClick={() => act(detail.id, 'activate')} disabled={busyAction !== ''}>
                    <Play className="mr-1.5 h-4 w-4" /> Activate &amp; start billing
                  </Button>
                ) : null}
                {detail.status === 'ACTIVE' && detail.plan?.canPause ? (
                  <Button variant="outline" onClick={() => act(detail.id, 'pause')} disabled={busyAction !== ''}>
                    <Pause className="mr-1.5 h-4 w-4" /> Pause
                  </Button>
                ) : null}
                {detail.status === 'PAUSED' ? (
                  <Button onClick={() => act(detail.id, 'resume')} disabled={busyAction !== ''}>
                    <Play className="mr-1.5 h-4 w-4" /> Resume
                  </Button>
                ) : null}
                {['CONFIRMED', 'ACTIVE', 'PAUSED'].includes(detail.status) && detail.plan?.canRenew ? (
                  <Button variant="outline" onClick={() => act(detail.id, 'renew')} disabled={busyAction !== ''}>
                    <RefreshCw className="mr-1.5 h-4 w-4" /> Renew
                  </Button>
                ) : null}
                {['ACTIVE', 'PAUSED'].includes(detail.status) ? (
                  <Button variant="outline" onClick={() => billNow(detail.id)} disabled={busyAction !== ''}>
                    {busyAction === `${detail.id}:invoice` ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <CreditCard className="mr-1.5 h-4 w-4" />}
                    Bill now
                  </Button>
                ) : null}
                {detail.status !== 'CLOSED' ? (
                  <Button variant="destructive" onClick={() => act(detail.id, 'close')} disabled={busyAction !== ''}
                    title={detail.plan && !detail.plan.canCloseEarly && detail.status === 'ACTIVE' ? 'This plan does not allow closing early' : undefined}>
                    <Ban className="mr-1.5 h-4 w-4" /> Close
                  </Button>
                ) : null}
              </DialogFooter>
            </>
          ) : (
            <>
              <DialogTitle className="sr-only">Subscription details</DialogTitle>
              <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

/** Inline row menu with the lifecycle actions that apply to the row's status. */
function RowActions({
  sub, busy, onAct, onBillNow, onOpen,
}: {
  sub: Subscription
  busy: string
  onAct: (id: string, action: string) => void
  onBillNow: (id: string) => void
  onOpen: () => void
}) {
  const disabled = busy !== ''
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8" disabled={disabled} aria-label={`Actions for ${sub.number}`}>
          {busy.startsWith(`${sub.id}:`) ? <Loader2 className="h-4 w-4 animate-spin" /> : <MoreHorizontal className="h-4 w-4" />}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-52">
        <DropdownMenuLabel className="text-xs text-muted-foreground">{sub.number}</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={onOpen}>
          <Eye className="mr-2 h-4 w-4" /> Open details
        </DropdownMenuItem>
        {sub.status === 'DRAFT' ? (
          <DropdownMenuItem onClick={() => onAct(sub.id, 'send_quote')}><Send className="mr-2 h-4 w-4" /> Send quotation</DropdownMenuItem>
        ) : null}
        {sub.status === 'QUOTATION' ? (
          <DropdownMenuItem onClick={() => onAct(sub.id, 'confirm')}><Zap className="mr-2 h-4 w-4" /> Confirm quotation</DropdownMenuItem>
        ) : null}
        {sub.status === 'CONFIRMED' ? (
          <DropdownMenuItem onClick={() => onAct(sub.id, 'activate')}><Play className="mr-2 h-4 w-4" /> Activate</DropdownMenuItem>
        ) : null}
        {sub.status === 'ACTIVE' && sub.plan?.canPause ? (
          <DropdownMenuItem onClick={() => onAct(sub.id, 'pause')}><Pause className="mr-2 h-4 w-4" /> Pause</DropdownMenuItem>
        ) : null}
        {sub.status === 'PAUSED' ? (
          <DropdownMenuItem onClick={() => onAct(sub.id, 'resume')}><Play className="mr-2 h-4 w-4" /> Resume</DropdownMenuItem>
        ) : null}
        {['CONFIRMED', 'ACTIVE', 'PAUSED'].includes(sub.status) && sub.plan?.canRenew ? (
          <DropdownMenuItem onClick={() => onAct(sub.id, 'renew')}><RefreshCw className="mr-2 h-4 w-4" /> Renew</DropdownMenuItem>
        ) : null}
        {['ACTIVE', 'PAUSED'].includes(sub.status) ? (
          <DropdownMenuItem onClick={() => onBillNow(sub.id)}><CreditCard className="mr-2 h-4 w-4" /> Bill now</DropdownMenuItem>
        ) : null}
        {sub.status !== 'CLOSED' ? (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => onAct(sub.id, 'close')}>
              <Ban className="mr-2 h-4 w-4" /> Close subscription
            </DropdownMenuItem>
          </>
        ) : null}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

function Info({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className={className}>
      <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-medium">{value}</p>
    </div>
  )
}

function LifecycleStrip({ status }: { status: string }) {
  const steps = ['DRAFT', 'QUOTATION', 'CONFIRMED', 'ACTIVE', 'CLOSED']
  const idx = steps.indexOf(status)
  return (
    <div className="flex flex-wrap items-center gap-1.5 text-xs">
      {steps.map((s, i) => {
        const reached = status === 'PAUSED' ? s === 'ACTIVE' || i < 3 : i <= idx
        return (
          <div key={s} className="flex items-center gap-1.5">
            {i > 0 ? <ArrowRight className="h-3 w-3 text-muted-foreground/50" /> : null}
            <span className={`rounded-full px-2.5 py-1 font-semibold ${
              reached ? 'bg-primary/15 text-primary' : 'bg-muted text-muted-foreground/60'
            }`}>
              {s.charAt(0) + s.slice(1).toLowerCase()}
            </span>
          </div>
        )
      })}
      {status === 'PAUSED' ? <StatusBadge status="PAUSED" /> : null}
    </div>
  )
}

function CreateSubscriptionDialog({
  customers, products, plans, taxRules, templates, onClose, onCreated,
}: {
  customers: Customer[]
  products: Product[]
  plans: Plan[]
  taxRules: TaxRule[]
  templates: QuotationTemplate[]
  onClose: () => void
  onCreated: () => void
}) {
  const [customerId, setCustomerId] = useState('')
  const [planId, setPlanId] = useState<string | null>(null)
  const [startDate, setStartDate] = useState(toDateInput(new Date()))
  const [expiryDate, setExpiryDate] = useState('')
  const [paymentTerms, setPaymentTerms] = useState('DUE_ON_RECEIPT')
  const [notes, setNotes] = useState('')
  const [lines, setLines] = useState<LineDraft[]>([{
    productId: products[0]?.id ?? '', variantId: null, quantity: 1,
    unitPrice: products[0]?.salesPrice ?? 0, taxRate: taxRules[0]?.rate ?? 0,
  }])
  const [busy, setBusy] = useState(false)

  function applyTemplate(templateId: string) {
    const t = templates.find((x) => x.id === templateId)
    if (!t) return
    setPlanId(t.planId)
    if (t.plan) setPaymentTerms(paymentTerms)
    setLines(t.lines.map((l) => ({
      productId: l.productId,
      variantId: l.variantId,
      quantity: l.quantity,
      unitPrice: l.unitPrice,
      taxRate: l.taxRate,
    })))
    toast({ title: `Template "${t.name}" applied`, description: `Quotation stays valid for ${t.validDays} days.` })
  }

  async function submit() {
    setBusy(true)
    try {
      await api.post('/api/subscriptions', {
        customerId, planId, startDate, expiryDate: expiryDate || null, paymentTerms, notes, lines,
      })
      onCreated()
    } catch (err) {
      toast({ title: 'Could not create subscription', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose() }}>
      <DialogContent className="max-h-[92vh] max-w-3xl overflow-y-auto scroll-slim">
        <DialogHeader>
          <DialogTitle>New subscription</DialogTitle>
          <DialogDescription>
            Start from a quotation template or build the lines yourself. New subscriptions begin as drafts.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Customer</Label>
            <Select value={customerId} onValueChange={setCustomerId}>
              <SelectTrigger aria-label="Customer"><SelectValue placeholder="Choose customer" /></SelectTrigger>
              <SelectContent>
                {customers.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Start from template</Label>
            <Select onValueChange={applyTemplate}>
              <SelectTrigger aria-label="Quotation template">
                <SelectValue placeholder={<span className="flex items-center gap-2"><FileStack className="h-4 w-4" /> Optional template</span>} />
              </SelectTrigger>
              <SelectContent>
                {templates.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.name} · valid {t.validDays}d
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Plan</Label>
            <Select value={planId ?? 'none'} onValueChange={(v) => setPlanId(v === 'none' ? null : v)}>
              <SelectTrigger aria-label="Plan"><SelectValue placeholder="No plan (ad-hoc)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No plan (ad-hoc billing)</SelectItem>
                {plans.filter((p) => p.active).map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name} · {fmtMoney(p.price)}/{CYCLE_LABEL[p.billingCycle]?.toLowerCase()} · min {p.minQuantity}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Payment terms</Label>
            <Select value={paymentTerms} onValueChange={setPaymentTerms}>
              <SelectTrigger aria-label="Payment terms"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(TERMS_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="sub-start">Start date</Label>
            <Input id="sub-start" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="sub-expiry">Expiry date (optional)</Label>
            <Input id="sub-expiry" type="date" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="sub-notes">Notes</Label>
            <Textarea id="sub-notes" rows={2} placeholder="Anything the team should know…" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Product lines</Label>
          <LinesEditor lines={lines} onChange={setLines} products={products} taxRules={taxRules} />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} disabled={busy || !customerId || lines.length === 0}>
            {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <CalendarClock className="mr-1.5 h-4 w-4" />}
            Create draft subscription
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
