'use client'

import { useState } from 'react'
import { api } from './api-client'
import { Logo } from './ui-bits'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import type { SessionUser } from './types'
import {
  BadgeCheck, BarChart3, CalendarClock, ChevronRight, FileText, KeyRound, Loader2, Mail, ShieldCheck,
} from 'lucide-react'

type Mode = 'auth' | 'forgot' | 'reset'

const DEMO = [
  { label: 'Admin', email: 'admin@brightloop.com', password: 'Admin@123!', hint: 'full control', dot: 'bg-emerald-400' },
  { label: 'Staff', email: 'maya@brightloop.com', password: 'Staff@123!', hint: 'day-to-day work', dot: 'bg-amber-400' },
  { label: 'Customer', email: 'accounts@kaveritextiles.in', password: 'Customer@123!', hint: 'self-service portal', dot: 'bg-sky-400' },
]

const FEATURES = [
  { icon: CalendarClock, text: 'Billing day that invoices every due subscription automatically' },
  { icon: FileText, text: 'Draft → Confirmed → Paid invoices with taxes applied by rule' },
  { icon: BadgeCheck, text: 'Discounts that apply themselves on the next invoice' },
  { icon: BarChart3, text: 'Active subscriptions, revenue and overdue at a glance' },
]

export function AuthScreen({
  onAuthed,
  resetToken,
  onResetConsumed,
}: {
  onAuthed: (user: SessionUser) => void
  resetToken?: string
  onResetConsumed: () => void
}) {
  const [mode, setMode] = useState<Mode>(resetToken ? 'reset' : 'auth')
  const [busy, setBusy] = useState(false)
  const [loginEmail, setLoginEmail] = useState('')
  const [loginPassword, setLoginPassword] = useState('')
  const [regName, setRegName] = useState('')
  const [regEmail, setRegEmail] = useState('')
  const [regPassword, setRegPassword] = useState('')
  const [forgotEmail, setForgotEmail] = useState('')
  const [resetLink, setResetLink] = useState<string | null>(null)
  const [resetPassword, setResetPassword] = useState('')

  async function doLogin(email: string, password: string) {
    setBusy(true)
    try {
      const res = await api.post<{ user: SessionUser }>('/api/auth/login', { email, password })
      onAuthed(res.user)
      toast({ title: `Welcome back, ${res.user.name.split(' ')[0]}` })
    } catch (err) {
      toast({ title: 'Sign in failed', description: err instanceof Error ? err.message : 'Try again', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function doRegister() {
    setBusy(true)
    try {
      const res = await api.post<{ user: SessionUser }>('/api/auth/register', {
        name: regName, email: regEmail, password: regPassword,
      })
      onAuthed(res.user)
      toast({ title: 'Account created', description: 'Your customer portal is ready.' })
    } catch (err) {
      toast({ title: 'Could not create account', description: err instanceof Error ? err.message : 'Try again', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function doForgot() {
    setBusy(true)
    try {
      const res = await api.post<{ sent: boolean; resetUrl: string | null }>('/api/auth/forgot', { email: forgotEmail })
      setResetLink(res.resetUrl)
      toast({
        title: 'Reset link generated',
        description: 'No mail server is connected in this demo, so the link is shown below.',
      })
    } catch (err) {
      toast({ title: 'Something went wrong', description: err instanceof Error ? err.message : 'Try again', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function doReset() {
    if (!resetToken) return
    setBusy(true)
    try {
      await api.post('/api/auth/reset', { token: resetToken, password: resetPassword })
      toast({ title: 'Password updated', description: 'Sign in with your new password.' })
      onResetConsumed()
      setMode('auth')
    } catch (err) {
      toast({ title: 'Reset failed', description: err instanceof Error ? err.message : 'Try again', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="dark relative min-h-screen overflow-hidden bg-[oklch(0.155_0.018_172)] text-foreground">
      {/* ambient décor */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="auth-orb absolute -top-44 left-[-12%] h-[36rem] w-[36rem] rounded-full bg-[radial-gradient(circle_at_center,oklch(0.62_0.15_163/0.3),transparent_62%)] blur-3xl" />
        <div className="auth-orb-slow absolute -bottom-52 right-[-10%] h-[34rem] w-[34rem] rounded-full bg-[radial-gradient(circle_at_center,oklch(0.75_0.12_85/0.14),transparent_62%)] blur-3xl" />
        <div className="absolute top-1/3 left-1/2 h-[22rem] w-[22rem] -translate-x-1/2 rounded-full bg-[radial-gradient(circle_at_center,oklch(0.65_0.1_195/0.1),transparent_65%)] blur-3xl" />
        <div className="auth-grid absolute inset-0" />
      </div>

      <div className="relative z-10 flex min-h-screen flex-col lg:flex-row">
        {/* Brand panel */}
        <div className="relative hidden flex-1 flex-col justify-between gap-10 p-10 text-white lg:flex xl:p-14">
          <Logo size={40} dark />

          <div className="max-w-xl space-y-7">
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-300/25 bg-emerald-300/10 px-3.5 py-1.5 text-[11px] font-semibold tracking-[0.16em] text-emerald-200 uppercase">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-300 shadow-[0_0_10px_2px_oklch(0.8_0.14_163/0.7)]" />
              Brightloop workspace
            </span>

            <h1 className="text-4xl font-bold leading-[1.12] tracking-tight xl:text-[2.75rem]">
              Plans, subscriptions and recurring billing —{' '}
              <span className="bg-gradient-to-r from-emerald-300 via-teal-200 to-amber-200 bg-clip-text text-transparent">
                in one place.
              </span>
            </h1>

            <p className="max-w-lg text-[15px] leading-relaxed text-white/60">
              No more spreadsheets for subscriptions, invoices typed by hand, or payments matched by scrolling
              bank statements. Brightloop runs the whole life of your subscription business.
            </p>

            <ul className="space-y-2.5">
              {FEATURES.map((f) => (
                <li key={f.text} className="auth-glass flex items-center gap-3 rounded-xl px-4 py-3 text-[13.5px] text-white/75 backdrop-blur-sm">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-emerald-400/15 text-emerald-300">
                    <f.icon className="h-4 w-4" aria-hidden="true" />
                  </span>
                  {f.text}
                </li>
              ))}
            </ul>

            <div className="auth-glass flex w-fit flex-wrap items-center gap-x-3 gap-y-2 rounded-2xl px-5 py-3.5 backdrop-blur-sm">
              <span className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-white/40">
                Invoice lifecycle
              </span>
              <span className="flex items-center gap-1.5 text-[12px] font-semibold">
                <span className="rounded-md bg-white/10 px-2 py-1 text-white/70">Draft</span>
                <ChevronRight className="h-3 w-3 text-white/30" />
                <span className="rounded-md bg-white/10 px-2 py-1 text-white/70">Confirmed</span>
                <ChevronRight className="h-3 w-3 text-white/30" />
                <span className="rounded-md bg-emerald-400/20 px-2 py-1 text-emerald-200">Paid</span>
              </span>
            </div>
          </div>

          <p className="flex items-center gap-2 text-xs text-white/45">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-300/80" />
            Admin, internal staff and customer portal roles — each sees exactly what they should.
          </p>
        </div>

        {/* Auth panel */}
        <div className="relative flex flex-1 items-center justify-center px-4 py-12 sm:px-8">
          <div className="w-full max-w-md">
            <div className="mb-8 flex justify-center lg:hidden"><Logo size={38} dark /></div>

            <div className="auth-card auth-input-fx auth-tabs-fx rounded-3xl p-6 sm:p-8">
              {mode === 'forgot' ? (
                <div className="space-y-5">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight">Forgot your password?</h2>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Enter your registered email and we will generate a reset link.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="forgot-email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-muted-foreground" />
                      <Input id="forgot-email" type="email" className="pl-9" placeholder="you@company.com"
                        value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)} />
                    </div>
                  </div>
                  {resetLink ? (
                    <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm dark:border-emerald-800 dark:bg-emerald-950/50">
                      <p className="font-medium text-emerald-800 dark:text-emerald-300">Email simulated</p>
                      <p className="mt-1 text-emerald-700/80 dark:text-emerald-200/80">
                        This demo has no mail server, so here is your reset link:
                      </p>
                      <a className="mt-2 block break-all font-mono text-xs text-emerald-700 underline dark:text-emerald-300"
                        href={resetLink}>{resetLink}</a>
                    </div>
                  ) : null}
                  <div className="flex gap-2">
                    <Button className="auth-btn-glow flex-1" onClick={doForgot} disabled={busy || !forgotEmail}>
                      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Send reset link'}
                    </Button>
                    <Button variant="outline" onClick={() => { setMode('auth'); setResetLink(null) }}>Back</Button>
                  </div>
                </div>
              ) : mode === 'reset' ? (
                <div className="space-y-5">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight">Set a new password</h2>
                    <p className="mt-1 text-sm text-muted-foreground">
                      More than 8 characters with an uppercase letter, a lowercase letter and a special character.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reset-pw">New password</Label>
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-muted-foreground" />
                      <Input id="reset-pw" type="password" className="pl-9" placeholder="•••••••••"
                        value={resetPassword} onChange={(e) => setResetPassword(e.target.value)} />
                    </div>
                  </div>
                  <Button className="auth-btn-glow w-full" onClick={doReset} disabled={busy || !resetPassword}>
                    {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Update password'}
                  </Button>
                  <Button variant="ghost" className="w-full" onClick={() => setMode('auth')}>Back to sign in</Button>
                </div>
              ) : (
                <Tabs defaultValue="login" className="w-full">
                  <TabsList className="mb-6 grid w-full grid-cols-2">
                    <TabsTrigger value="login">Sign in</TabsTrigger>
                    <TabsTrigger value="register">Create account</TabsTrigger>
                  </TabsList>

                  <TabsContent value="login" className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-email">Email</Label>
                      <Input id="login-email" type="email" placeholder="you@company.com"
                        value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && loginEmail && loginPassword && doLogin(loginEmail, loginPassword)} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="login-pw">Password</Label>
                        <button className="text-xs font-medium text-primary hover:underline"
                          onClick={() => setMode('forgot')} type="button">
                          Forgot password?
                        </button>
                      </div>
                      <Input id="login-pw" type="password" placeholder="•••••••••"
                        value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && loginEmail && loginPassword && doLogin(loginEmail, loginPassword)} />
                    </div>
                    <Button className="auth-btn-glow w-full" onClick={() => doLogin(loginEmail, loginPassword)}
                      disabled={busy || !loginEmail || !loginPassword}>
                      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Sign in'}
                    </Button>

                    <div className="pt-2">
                      <p className="mb-2 text-center text-xs text-muted-foreground">
                        Demo dataset — try a ready-made account
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                        {DEMO.map((d) => (
                          <button key={d.label} type="button"
                            className="rounded-xl border border-white/10 bg-white/[0.04] p-2.5 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-emerald-300/45 hover:bg-white/[0.08]"
                            onClick={() => doLogin(d.email, d.password)}>
                            <div className="flex items-center gap-1.5 text-[13px] font-semibold text-white/90">
                              <span className={cn('h-1.5 w-1.5 rounded-full', d.dot)} />
                              {d.label}
                            </div>
                            <div className="mt-0.5 text-[10.5px] leading-snug text-white/45">{d.hint}</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="register" className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="reg-name">Your name or business</Label>
                      <Input id="reg-name" placeholder="Kaveri Textiles"
                        value={regName} onChange={(e) => setRegName(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reg-email">Email</Label>
                      <Input id="reg-email" type="email" placeholder="you@company.com"
                        value={regEmail} onChange={(e) => setRegEmail(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reg-pw">Password</Label>
                      <Input id="reg-pw" type="password" placeholder="More than 8 characters"
                        value={regPassword} onChange={(e) => setRegPassword(e.target.value)} />
                      <p className="text-xs text-muted-foreground">
                        Over 8 characters, with an uppercase letter, a lowercase letter and a special character.
                      </p>
                    </div>
                    <Button className="auth-btn-glow w-full" onClick={doRegister} disabled={busy || !regName || !regEmail || !regPassword}>
                      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create customer account'}
                    </Button>
                  </TabsContent>
                </Tabs>
              )}
            </div>

            <p className="mt-6 text-center text-[11px] tracking-wide text-white/35">
              Protected workspace · Brightloop Software
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
