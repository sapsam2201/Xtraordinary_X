'use client'

import { fmtMoney } from './format'
import type { Product, TaxRule } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Plus, Trash2 } from 'lucide-react'

export type LineDraft = {
  productId: string
  variantId: string | null
  quantity: number
  unitPrice: number
  taxRate: number
  description?: string | null
}

export function LinesEditor({
  lines, onChange, products, taxRules,
}: {
  lines: LineDraft[]
  onChange: (lines: LineDraft[]) => void
  products: Product[]
  taxRules: TaxRule[]
}) {
  function update(i: number, patch: Partial<LineDraft>) {
    onChange(lines.map((l, idx) => (idx === i ? { ...l, ...patch } : l)))
  }

  function pickProduct(i: number, productId: string) {
    const product = products.find((p) => p.id === productId)
    if (!product) return
    update(i, { productId, variantId: null, unitPrice: product.salesPrice })
  }

  function pickVariant(i: number, variantId: string) {
    const line = lines[i]
    const product = products.find((p) => p.id === line.productId)
    const variant = product?.variants.find((v) => v.id === variantId)
    if (!product) return
    update(i, { variantId, unitPrice: product.salesPrice + (variant?.priceDelta ?? 0) })
  }

  function addLine() {
    const first = products[0]
    onChange([...lines, { productId: first?.id ?? '', variantId: null, quantity: 1, unitPrice: first?.salesPrice ?? 0, taxRate: taxRules[0]?.rate ?? 0 }])
  }

  const subtotal = lines.reduce((s, l) => s + l.quantity * l.unitPrice, 0)
  const taxTotal = lines.reduce((s, l) => s + (l.quantity * l.unitPrice * l.taxRate) / 100, 0)

  return (
    <div className="space-y-3">
      <div className="overflow-x-auto rounded-lg border scroll-slim">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-2.5 py-2 font-medium">Product</th>
              <th className="px-2.5 py-2 font-medium">Variant</th>
              <th className="w-20 px-2.5 py-2 font-medium">Qty</th>
              <th className="w-28 px-2.5 py-2 font-medium">Unit price</th>
              <th className="w-32 px-2.5 py-2 font-medium">Tax</th>
              <th className="w-24 px-2.5 py-2 text-right font-medium">Amount</th>
              <th className="w-10" />
            </tr>
          </thead>
          <tbody>
            {lines.map((line, i) => {
              const product = products.find((p) => p.id === line.productId)
              return (
                <tr key={i} className="border-t">
                  <td className="px-2.5 py-1.5">
                    <Select value={line.productId} onValueChange={(v) => pickProduct(i, v)}>
                      <SelectTrigger size="sm" className="w-full min-w-40" aria-label="Product">
                        <SelectValue placeholder="Choose product" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map((p) => (
                          <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-2.5 py-1.5">
                    {product && product.variants.length > 0 ? (
                      <Select value={line.variantId ?? ''} onValueChange={(v) => pickVariant(i, v)}>
                        <SelectTrigger size="sm" className="w-full min-w-32" aria-label="Variant">
                          <SelectValue placeholder="None" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          {product.variants.map((v) => (
                            <SelectItem key={v.id} value={v.id}>
                              {v.value}{v.priceDelta ? ` (+${v.priceDelta})` : ''}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : <span className="text-xs text-muted-foreground">—</span>}
                  </td>
                  <td className="px-2.5 py-1.5">
                    <Input type="number" min={1} className="h-8" value={line.quantity}
                      onChange={(e) => update(i, { quantity: Math.max(1, Number(e.target.value) || 1) })}
                      aria-label="Quantity" />
                  </td>
                  <td className="px-2.5 py-1.5">
                    <Input type="number" min={0} step="0.01" className="h-8" value={line.unitPrice}
                      onChange={(e) => update(i, { unitPrice: Math.max(0, Number(e.target.value) || 0) })}
                      aria-label="Unit price" />
                  </td>
                  <td className="px-2.5 py-1.5">
                    <Select value={String(line.taxRate)} onValueChange={(v) => update(i, { taxRate: Number(v) })}>
                      <SelectTrigger size="sm" className="w-full" aria-label="Tax rate">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {taxRules.map((t) => (
                          <SelectItem key={t.id} value={String(t.rate)}>{t.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-2.5 py-1.5 text-right font-medium">{fmtMoney(line.quantity * line.unitPrice)}</td>
                  <td className="px-1 py-1.5">
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive"
                      onClick={() => onChange(lines.filter((_, idx) => idx !== i))}
                      disabled={lines.length === 1} aria-label="Remove line">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <Button type="button" variant="outline" size="sm" onClick={addLine}>
          <Plus className="mr-1.5 h-3.5 w-3.5" /> Add line
        </Button>
        <div className="flex items-center gap-4 text-sm">
          <span className="text-muted-foreground">Subtotal <b className="text-foreground">{fmtMoney(subtotal)}</b></span>
          <span className="text-muted-foreground">Tax <b className="text-foreground">{fmtMoney(taxTotal)}</b></span>
          <span className="font-bold">{fmtMoney(subtotal + taxTotal)}</span>
        </div>
      </div>
    </div>
  )
}
