'use client'

/**
 * Fired whenever an API responds 401 so the app root can end the session.
 */
export const UNAUTHORIZED_EVENT = 'bl:unauthorized'

const TOKEN_KEY = 'bl_token'

// Browsers may block cookies inside third-party iframes (embedded previews),
// which would silently kill cookie-based sessions. The session token is also
// kept in localStorage and sent as a Bearer header, which works everywhere.
function loadToken(): string | null {
  try {
    return window.localStorage.getItem(TOKEN_KEY)
  } catch {
    return null
  }
}

function saveToken(token: string | null) {
  try {
    if (token) window.localStorage.setItem(TOKEN_KEY, token)
    else window.localStorage.removeItem(TOKEN_KEY)
  } catch {
    /* storage unavailable — cookie session still applies */
  }
}

function notifyUnauthorized() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event(UNAUTHORIZED_EVENT))
  }
}

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const token = loadToken()
  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  if (token) headers.Authorization = `Bearer ${token}`

  const res = await fetch(url, {
    cache: 'no-store',
    ...options,
    headers: { ...headers, ...(options?.headers as Record<string, string> | undefined) },
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    if (res.status === 401) {
      saveToken(null)
      notifyUnauthorized()
    }
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`)
  }
  // Persist session tokens returned by login/register.
  if (data && typeof data === 'object' && typeof (data as { token?: unknown }).token === 'string') {
    saveToken((data as { token: string }).token)
  }
  return data as T
}

export const api = {
  get: <T,>(url: string) => request<T>(url),
  post: <T,>(url: string, body?: unknown) =>
    request<T>(url, { method: 'POST', body: JSON.stringify(body ?? {}) }),
  put: <T,>(url: string, body?: unknown) =>
    request<T>(url, { method: 'PUT', body: JSON.stringify(body ?? {}) }),
  patch: <T,>(url: string, body?: unknown) =>
    request<T>(url, { method: 'PATCH', body: JSON.stringify(body ?? {}) }),
  del: <T,>(url: string) => request<T>(url, { method: 'DELETE' }),
}

/**
 * Fetches every row of a paged list endpoint (pages of 1000, in parallel after the first).
 * The API caps a single response, so plain `api.get('/api/invoices')` silently truncates big lists.
 */
export async function getAll<K extends string, T>(path: string, key: K): Promise<Record<K, T[]>> {
  const sep = path.includes('?') ? '&' : '?'
  const PAGE = 1000
  const first = await request<Record<string, unknown>>(`${path}${sep}limit=${PAGE}&offset=0`)
  const rows = [...((first[key] as T[]) ?? [])]
  const total = typeof first.total === 'number' ? first.total : rows.length
  const rest: Promise<Record<string, unknown>>[] = []
  for (let off = PAGE; off < total; off += PAGE) {
    rest.push(request<Record<string, unknown>>(`${path}${sep}limit=${PAGE}&offset=${off}`))
  }
  for (const page of await Promise.all(rest)) rows.push(...((page[key] as T[]) ?? []))
  return { [key]: rows } as Record<K, T[]>
}

/** Downloads a CSV (or any file) from an authenticated endpoint. */
export async function downloadFile(url: string, filename: string): Promise<void> {
  const token = loadToken()
  const res = await fetch(url, { cache: 'no-store', headers: token ? { Authorization: `Bearer ${token}` } : {} })
  if (!res.ok) {
    if (res.status === 401) {
      saveToken(null)
      notifyUnauthorized()
    }
    const data = await res.json().catch(() => ({}))
    throw new Error((data as { error?: string }).error || `Download failed (${res.status})`)
  }
  const blob = await res.blob()
  const href = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = href
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(href)
}

/** Drop the locally stored session token (used on logout). */
export function clearSession() {
  saveToken(null)
}
