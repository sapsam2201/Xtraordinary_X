'use client'

import { useEffect, useMemo, useState } from 'react'
import { api } from './api-client'
import { fmtDate, fmtMoney, METHOD_LABEL } from './format'
import { PageHeader, Spinner, StatusBadge } from './ui-bits'
import type { Invoice, Payment, Subscription } from './types'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { LucideIcon } from 'lucide-react'
import {
  CalendarClock, CreditCard, FileText, History, RefreshCw,
} from 'lucide-react'

type EventKind = 'invoice' | 'payment' | 'subscription'

type FeedEvent = {
  id: string
  kind: EventKind
  when: string
  title: string
  body: string
  status?: string
}

const KIND_STYLE: Record<EventKind, { icon: LucideIcon; tone: string }> = {
  invoice: { icon: FileText, tone: 'bg-primary/10 text-primary' },
  payment: { icon: CreditCard, tone: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' },
  subscription: { icon: RefreshCw, tone: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300' },
}

function relTime(d: string) {
  const diff = Date.now() - new Date(d).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const days = Math.floor(h / 24)
  if (days < 7) return `${days}d ago`
  return fmtDate(d)
}

function dayLabel(d: string) {
  const dt = new Date(d)
  const startOf = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime()
  const diff = Math.round((startOf(new Date()) - startOf(dt)) / 86400000)
  if (diff === 0) return 'Today'
  if (diff === 1) return 'Yesterday'
  if (diff > 1 && diff < 7) return dt.toLocaleDateString('en-IN', { weekday: 'long' })
  return fmtDate(d)
}

export function Activity() {
  const [invoices, setInvoices] = useState<Invoice[] | null>(null)
  const [payments, setPayments] = useState<Payment[] | null>(null)
  const [subs, setSubs] = useState<Subscription[] | null>(null)
  const [filter, setFilter] = useState<'all' | EventKind>('all')
  const [error, setError] = useState('')

  useEffect(() => {
    ;(async () => {
      try {
        const [i, p, s] = await Promise.all([
          api.get<{ invoices: Invoice[] }>('/api/invoices'),
          api.get<{ payments: Payment[] }>('/api/payments'),
          api.get<{ subscriptions: Subscription[] }>('/api/subscriptions'),
        ])
        setInvoices(i.invoices)
        setPayments(p.payments)
        setSubs(s.subscriptions)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load activity')
      }
    })()
  }, [])

  const events = useMemo<FeedEvent[]>(() => {
    if (!invoices || !payments || !subs) return []
    const list: FeedEvent[] = []
    for (const i of invoices) {
      list.push({
        id: `inv-${i.id}`,
        kind: 'invoice',
        when: i.issueDate,
        title: `Invoice ${i.number} ${i.status === 'PAID' ? 'settled' : 'issued'} for ${i.customer?.name ?? 'customer'}`,
        body: `${fmtMoney(i.total)} · due ${fmtDate(i.dueDate)}${i.subscription?.plan?.name ? ` · ${i.subscription.plan.name}` : ''}`,
        status: i.status,
      })
    }
    for (const p of payments) {
      list.push({
        id: `pay-${p.id}`,
        kind: 'payment',
        when: p.date,
        title: `Payment ${p.number} received from ${p.customer?.name ?? 'customer'}`,
        body: `${fmtMoney(p.amount)} via ${METHOD_LABEL[p.method] ?? p.method}${p.invoice?.number ? ` against ${p.invoice.number}` : ''}`,
      })
    }
    for (const s of subs) {
      list.push({
        id: `sub-${s.id}`,
        kind: 'subscription',
        when: s.createdAt,
        title: `Subscription ${s.number} created for ${s.customer?.name ?? 'customer'}`,
        body: `${s.plan?.name ?? 'Custom lines'} · ${s.lines.length} line${s.lines.length === 1 ? '' : 's'}`,
        status: s.status,
      })
    }
    return list.sort((a, b) => new Date(b.when).getTime() - new Date(a.when).getTime())
  }, [invoices, payments, subs])

  const shown = filter === 'all' ? events : events.filter((e) => e.kind === filter)

  const groups = useMemo(() => {
    const map = new Map<string, FeedEvent[]>()
    for (const e of shown.slice(0, 120)) {
      const label = dayLabel(e.when)
      const arr = map.get(label) ?? []
      arr.push(e)
      map.set(label, arr)
    }
    return [...map.entries()]
  }, [shown])

  if (error) {
    return (
      <div className="space-y-3">
        <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>
        <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
          <RefreshCw className="h-4 w-4" /> Try again
        </Button>
      </div>
    )
  }
  if (!invoices || !payments || !subs) return <Spinner />

  const CHIPS: { key: typeof filter; label: string; icon: LucideIcon }[] = [
    { key: 'all', label: `All (${events.length})`, icon: History },
    { key: 'invoice', label: `Invoices (${events.filter((e) => e.kind === 'invoice').length})`, icon: FileText },
    { key: 'payment', label: `Payments (${events.filter((e) => e.kind === 'payment').length})`, icon: CreditCard },
    { key: 'subscription', label: `Subscriptions (${events.filter((e) => e.kind === 'subscription').length})`, icon: RefreshCw },
  ]

  return (
    <div className="space-y-6">
      <PageHeader
        title="Activity feed"
        subtitle="A single timeline of everything happening across subscriptions, invoices and payments."
      />

      <div className="flex gap-2 overflow-x-auto pb-1 scroll-slim">
        {CHIPS.map((c) => (
          <button key={c.key} onClick={() => setFilter(c.key)}
            className={cn(
              'inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition-colors',
              filter === c.key
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground'
            )}>
            <c.icon className="h-3.5 w-3.5" /> {c.label}
          </button>
        ))}
      </div>

      {groups.length === 0 ? (
        <div className="rounded-3xl border border-dashed bg-card py-14 text-center text-sm text-muted-foreground">
          No activity recorded yet.
        </div>
      ) : (
        <div className="space-y-8">
          {groups.map(([label, items]) => (
            <section key={label}>
              <div className="mb-3 flex items-center gap-3">
                <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">{label}</h2>
                <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">{items.length}</span>
                <div className="h-px flex-1 bg-border" />
              </div>
              <div className="space-y-2">
                {items.map((e) => {
                  const style = KIND_STYLE[e.kind]
                  const Icon = style.icon
                  return (
                    <div key={e.id} className="relative flex items-start gap-3.5 rounded-2xl border bg-card p-4 shadow-sm transition-colors hover:border-primary/30">
                      <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-full', style.tone)}>
                        <Icon className="h-4.5 w-4.5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13.5px] font-semibold">{e.title}</p>
                        <p className="truncate text-xs text-muted-foreground">{e.body}</p>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-1.5">
                        <span className="text-[11px] text-muted-foreground">{relTime(e.when)}</span>
                        {e.status ? <StatusBadge status={e.status} /> : null}
                      </div>
                    </div>
                  )
                })}
              </div>
            </section>
          ))}
        </div>
      )}

      {shown.length > 120 ? (
        <p className="flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
          <CalendarClock className="h-3.5 w-3.5" /> Showing the 120 most recent events — use the filters to narrow down
        </p>
      ) : null}
    </div>
  )
}
