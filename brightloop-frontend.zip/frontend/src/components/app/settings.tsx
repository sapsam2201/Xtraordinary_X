'use client'

import { useState } from 'react'
import { api } from './api-client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { toast } from '@/hooks/use-toast'
import { DatabaseZap, KeyRound, Loader2 } from 'lucide-react'
import type { SessionUser } from './types'

export function Settings({ user }: { user: SessionUser }) {
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [busyPw, setBusyPw] = useState(false)
  const [busySeed, setBusySeed] = useState(false)

  async function changePassword() {
    setBusyPw(true)
    try {
      await api.put('/api/auth/password', { current, next })
      toast({ title: 'Password changed', description: 'Use the new password next time.' })
      setCurrent('')
      setNext('')
    } catch (err) {
      toast({ title: 'Could not change password', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusyPw(false)
    }
  }

  async function reseed() {
    if (!confirm('Re-initialize the demo dataset? All current data will be replaced with a fresh Brightloop month.')) return
    setBusySeed(true)
    try {
      await api.post('/api/seed')
      toast({ title: 'Dataset re-initialized', description: 'Reloading with a fresh month at Brightloop…' })
      window.setTimeout(() => window.location.reload(), 900)
    } catch (err) {
      toast({ title: 'Could not re-initialize', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusySeed(false)
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><KeyRound className="h-4.5 w-4.5 text-primary" /> Change your password</CardTitle>
          <CardDescription>More than 8 characters with an uppercase letter, a lowercase letter and a special character.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Current password</Label>
            <Input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>New password</Label>
            <Input type="password" value={next} onChange={(e) => setNext(e.target.value)} />
          </div>
          <div className="sm:col-span-2">
            <Button onClick={changePassword} disabled={busyPw || !current || !next}>
              {busyPw ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null} Update password
            </Button>
          </div>
        </CardContent>
      </Card>

      {user.role === 'ADMIN' ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base"><DatabaseZap className="h-4.5 w-4.5 text-primary" /> Demo dataset</CardTitle>
            <CardDescription>
              Re-initialize the full Brightloop dataset: 22 customers, 6 plans, 7 products, subscriptions, invoices, payments and discount usage — fresh dates anchored to today.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="secondary" onClick={reseed} disabled={busySeed}>
              {busySeed ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <DatabaseZap className="mr-1.5 h-4 w-4" />}
              Reset demo data
            </Button>
          </CardContent>
        </Card>
      ) : null}
    </div>
  )
}
