'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { fmtMoney } from './format'
import { ErrorNote, PageHeader, Spinner } from './ui-bits'
import type { Product, ProductVariant } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from '@/hooks/use-toast'
import { Archive, Boxes, Loader2, Package, Pencil, Plus, Tag, Trash2 } from 'lucide-react'

const TYPE_LABEL: Record<string, string> = {
  SOFTWARE: 'Software',
  ADDON: 'Add-on',
  SERVICE: 'Service',
}

type VariantDraft = { id?: string; name: string; value: string; priceDelta: number }

export function Products({ isAdmin }: { isAdmin: boolean }) {
  const [products, setProducts] = useState<Product[] | null>(null)
  const [error, setError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)
  const [busy, setBusy] = useState(false)
  const [form, setForm] = useState<{ name: string; type: string; salesPrice: string; costPrice: string; notes: string }>({ name: '', type: 'SOFTWARE', salesPrice: '', costPrice: '', notes: '' })
  const [variants, setVariants] = useState<VariantDraft[]>([])

  const load = useCallback(async () => {
    setError('')
    try {
      const res = await api.get<{ products: Product[] }>('/api/products')
      setProducts(res.products)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load products')
    }
  }, [])

  useEffect(() => { load() }, [load])

  function openCreate() {
    setEditing(null)
    setForm({ name: '', type: 'SOFTWARE', salesPrice: '', costPrice: '', notes: '' })
    setVariants([])
    setFormOpen(true)
  }

  function openEdit(p: Product) {
    setEditing(p)
    setForm({ name: p.name, type: p.type, salesPrice: String(p.salesPrice), costPrice: String(p.costPrice), notes: p.notes ?? '' })
    setVariants(p.variants.map((v) => ({ id: v.id, name: v.name, value: v.value, priceDelta: v.priceDelta })))
    setFormOpen(true)
  }

  async function save() {
    setBusy(true)
    try {
      const payload = {
        name: form.name,
        type: form.type,
        salesPrice: Number(form.salesPrice) || 0,
        costPrice: Number(form.costPrice) || 0,
        notes: form.notes,
        variants: variants.filter((v) => v.value.trim()),
      }
      if (editing) {
        await api.patch(`/api/products/${editing.id}`, payload)
        toast({ title: 'Product updated' })
      } else {
        await api.post('/api/products', payload)
        toast({ title: 'Product added' })
      }
      setFormOpen(false)
      await load()
    } catch (err) {
      toast({ title: 'Could not save product', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function archive(p: Product) {
    if (!confirm(p._count?.subLines ? `Archive "${p.name}"? It is used by subscriptions, so it will be deactivated instead of deleted.` : `Delete "${p.name}"?`)) return
    try {
      await api.del(`/api/products/${p.id}`)
      toast({ title: p._count?.subLines ? 'Product archived' : 'Product deleted' })
      await load()
    } catch (err) {
      toast({ title: 'Could not remove product', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  if (!products && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Products"
        subtitle="What Brightloop sells — software, add-ons and services, with variants like brand editions."
        actions={
          isAdmin ? (
            <Button onClick={openCreate}><Plus className="mr-1.5 h-4 w-4" /> Add product</Button>
          ) : (
            <p className="text-xs text-muted-foreground">Only the admin can change the catalog — you have view access.</p>
          )
        }
      />

      {error ? <ErrorNote message={error} /> : null}

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
        {(products ?? []).map((p) => (
          <div key={p.id} className={`rounded-xl border bg-card p-4 shadow-sm transition-shadow hover:shadow-md ${p.active ? '' : 'opacity-60'}`}>
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-primary/12 p-2.5 text-primary">
                  <Package className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-semibold leading-tight">{p.name}</p>
                  <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
                    <Tag className="h-3 w-3" /> {TYPE_LABEL[p.type] ?? p.type}
                    {!p.active ? <span className="ml-1 rounded-full bg-zinc-200 px-1.5 text-[10px] font-semibold text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">archived</span> : null}
                  </p>
                </div>
              </div>
              {isAdmin ? (
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(p)} aria-label="Edit product">
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-destructive" onClick={() => archive(p)} aria-label="Delete product">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ) : null}
            </div>

            <div className="mt-3 flex items-baseline gap-2">
              <p className="text-xl font-bold">{fmtMoney(p.salesPrice)}</p>
              <p className="text-xs text-muted-foreground">sales · cost {fmtMoney(p.costPrice)} · margin {fmtMoney(p.salesPrice - p.costPrice)}</p>
            </div>

            {p.notes ? <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{p.notes}</p> : null}

            {p.variants.length > 0 ? (
              <div className="mt-3 flex flex-wrap gap-1.5 border-t pt-3">
                {p.variants.map((v: ProductVariant) => (
                  <span key={v.id} className="rounded-full border bg-muted/60 px-2 py-0.5 text-[11px] font-medium">
                    {v.name}: {v.value}{v.priceDelta ? ` · +${fmtMoney(v.priceDelta)}` : ''}
                  </span>
                ))}
              </div>
            ) : null}
          </div>
        ))}
      </div>

      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false) }}>
        <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto scroll-slim">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit product' : 'New product'}</DialogTitle>
            <DialogDescription>Name, type, sales price, cost price and notes — plus any variants it comes in.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Name *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Brightloop CRM" />
            </div>
            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger aria-label="Product type"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="SOFTWARE">Software</SelectItem>
                  <SelectItem value="ADDON">Add-on</SelectItem>
                  <SelectItem value="SERVICE">Service</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Sales price (₹) *</Label>
              <Input type="number" min={0} value={form.salesPrice} onChange={(e) => setForm({ ...form, salesPrice: e.target.value })} placeholder="499" />
            </div>
            <div className="space-y-1.5">
              <Label>Cost price (₹) *</Label>
              <Input type="number" min={0} value={form.costPrice} onChange={(e) => setForm({ ...form, costPrice: e.target.value })} placeholder="180" />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Notes</Label>
              <Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="What it does, who it is for…" />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-1.5"><Boxes className="h-4 w-4" /> Variants</Label>
              <Button type="button" variant="outline" size="sm"
                onClick={() => setVariants([...variants, { name: 'Brand', value: '', priceDelta: 0 }])}>
                <Plus className="mr-1 h-3 w-3" /> Add variant
              </Button>
            </div>
            {variants.length === 0 ? (
              <p className="rounded-lg border border-dashed px-3 py-2 text-xs text-muted-foreground">
                e.g. a “Brand” variant where choosing Odoo adds 560 to the price.
              </p>
            ) : (
              <div className="space-y-2">
                {variants.map((v, i) => (
                  <div key={i} className="grid grid-cols-[1fr_1.4fr_100px_36px] items-center gap-2">
                    <Input placeholder="Group (Brand)" value={v.name} onChange={(e) => setVariants(variants.map((x, idx) => idx === i ? { ...x, name: e.target.value } : x))} />
                    <Input placeholder="Option (Odoo)" value={v.value} onChange={(e) => setVariants(variants.map((x, idx) => idx === i ? { ...x, value: e.target.value } : x))} />
                    <Input type="number" placeholder="+560" value={v.priceDelta} onChange={(e) => setVariants(variants.map((x, idx) => idx === i ? { ...x, priceDelta: Number(e.target.value) || 0 } : x))} />
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8 hover:text-destructive"
                      onClick={() => setVariants(variants.filter((_, idx) => idx !== i))} aria-label="Remove variant">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}
                <p className="text-[11px] text-muted-foreground">Group · Option · Price added to the sales price</p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={busy || !form.name || form.salesPrice === ''}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Archive className="mr-1.5 h-4 w-4" />}
              {editing ? 'Save changes' : 'Add product'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
