'use client'

import { useEffect, useRef, useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { api } from './api-client'
import { fmtMoney } from './format'
import type { Invoice } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from '@/hooks/use-toast'
import { CheckCircle2, Copy, Loader2, QrCode, Smartphone } from 'lucide-react'

type UpiInfo = {
  upiUri: string
  upiId: string
  payee: string
  amount: number
  currency: string
  reference: string
  placeholder: boolean
  selfConfirm: boolean
}

/**
 * Customer payment panel: shows a UPI QR for the outstanding balance of an invoice.
 * The QR encodes a standard UPI link, so GPay, PhonePe, Paytm, BHIM etc. can scan it.
 * While the panel is open it checks every few seconds whether the invoice got paid
 * (recorded by our team, or confirmed here in demo mode) and closes itself when it is.
 */
export function UpiPayPanel({
  invoice, onClose, onPaid,
}: {
  invoice: Invoice
  onClose: () => void
  onPaid: () => void
}) {
  const [info, setInfo] = useState<UpiInfo | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [utr, setUtr] = useState('')
  const [busy, setBusy] = useState(false)
  const paidRef = useRef(onPaid)
  const doneRef = useRef(false)
  useEffect(() => { paidRef.current = onPaid })
  const finish = () => {
    if (doneRef.current) return          // confirm button and the status check can race; only report once
    doneRef.current = true
    paidRef.current()
  }

  useEffect(() => {
    let alive = true
    api.get<UpiInfo>(`/api/invoices/${invoice.id}/upi`)
      .then((d) => { if (alive) setInfo(d) })
      .catch((e) => { if (alive) setError(e instanceof Error ? e.message : 'Could not load the payment QR.') })
    return () => { alive = false }
  }, [invoice.id])

  // detect that the invoice has been settled (e.g. staff recorded the payment)
  useEffect(() => {
    if (!info) return
    const timer = setInterval(async () => {
      try {
        const res = await api.get<{ invoice: { status: string } }>(`/api/invoices/${invoice.id}`)
        if (res.invoice.status === 'PAID') finish()
      } catch { /* keep waiting */ }
    }, 8000)
    return () => clearInterval(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [info, invoice.id])

  async function copy(text: string, what: string) {
    try {
      await navigator.clipboard.writeText(text)
      toast({ title: `${what} copied` })
    } catch {
      toast({ title: 'Could not copy', description: text, variant: 'destructive' })
    }
  }

  async function confirmPaid() {
    if (!info) return
    setBusy(true)
    try {
      const ref = utr.replace(/[^A-Za-z0-9]/g, '').slice(0, 22)
      await api.post('/api/payments', {
        invoiceId: invoice.id, method: 'UPI', amount: info.amount,
        note: ref ? `UPI QR · UTR ${ref}` : 'UPI QR',
      })
      finish()
    } catch (err) {
      toast({ title: 'Could not record payment', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="print-hide rounded-xl border bg-muted/30 p-4">
      <p className="mb-3 flex items-center gap-2 text-sm font-bold">
        <QrCode className="h-4 w-4" /> Pay {invoice.number} with any UPI app
      </p>

      {error ? (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-200">
          {error}
          <div className="mt-3"><Button variant="ghost" size="sm" onClick={onClose}>Close</Button></div>
        </div>
      ) : !info ? (
        <div className="flex items-center gap-2 py-8 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Preparing your payment QR…
        </div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-[auto,1fr]">
          <div className="mx-auto flex flex-col items-center gap-2">
            {/* QR codes need dark-on-light to scan reliably, so it stays white in dark mode too */}
            <div className="rounded-xl bg-white p-3 shadow-sm">
              <QRCodeSVG value={info.upiUri} size={208} level="M" bgColor="#ffffff" fgColor="#000000" />
            </div>
            <p className="text-center text-[11px] text-muted-foreground">Scan with GPay, PhonePe, Paytm, BHIM…</p>
          </div>

          <div className="space-y-3 text-sm">
            <div>
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Amount to pay</p>
              <p className="text-2xl font-black">{fmtMoney(info.amount)}</p>
              <p className="text-xs text-muted-foreground">to {info.payee} · ref {info.reference}</p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <code className="rounded bg-background px-2 py-1 text-xs">{info.upiId}</code>
              <Button type="button" size="sm" variant="outline" onClick={() => copy(info.upiId, 'UPI ID')}>
                <Copy className="mr-1.5 h-3.5 w-3.5" /> Copy UPI ID
              </Button>
              <Button asChild size="sm" variant="outline">
                <a href={info.upiUri}><Smartphone className="mr-1.5 h-3.5 w-3.5" /> Open UPI app</a>
              </Button>
            </div>

            {info.placeholder ? (
              <p className="rounded-md border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-xs text-amber-900 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-200">
                Demo QR — the receiving UPI ID is a placeholder. Set <b>UPI_ID</b> on the server for real payments.
              </p>
            ) : null}

            {info.selfConfirm ? (
              <div className="space-y-2 border-t pt-3">
                <Label htmlFor="utr">UPI reference / UTR (optional)</Label>
                <Input id="utr" placeholder="12-digit reference from your UPI app" value={utr} onChange={(e) => setUtr(e.target.value)} />
                <div className="flex gap-2">
                  <Button onClick={confirmPaid} disabled={busy}>
                    {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <CheckCircle2 className="mr-1.5 h-4 w-4" />}
                    I’ve paid {fmtMoney(info.amount)}
                  </Button>
                  <Button variant="ghost" onClick={onClose}>Not now</Button>
                </div>
                <p className="text-[11px] text-muted-foreground">Demo mode: this simulates the payment confirmation a payment gateway would send.</p>
              </div>
            ) : (
              <div className="space-y-2 border-t pt-3">
                <p className="text-xs text-muted-foreground">
                  Once the payment reaches us, our team marks this invoice as paid and it updates here automatically.
                  Please keep your UPI reference handy in case we need it.
                </p>
                <Button variant="outline" onClick={onClose}>Done</Button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
