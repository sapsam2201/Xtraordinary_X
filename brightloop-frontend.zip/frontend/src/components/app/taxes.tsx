'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { ErrorNote, PageHeader, Spinner } from './ui-bits'
import type { TaxRule } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { toast } from '@/hooks/use-toast'
import { Loader2, Plus, Receipt, Trash2 } from 'lucide-react'

export function Taxes({ isAdmin }: { isAdmin: boolean }) {
  const [taxRules, setTaxRules] = useState<TaxRule[] | null>(null)
  const [error, setError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [name, setName] = useState('')
  const [rate, setRate] = useState('')
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    setError('')
    try {
      const res = await api.get<{ taxRules: TaxRule[] }>('/api/tax-rules')
      setTaxRules(res.taxRules)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load tax rules')
    }
  }, [])

  useEffect(() => { load() }, [load])

  async function save() {
    setBusy(true)
    try {
      await api.post('/api/tax-rules', { name, rate: Number(rate) })
      toast({ title: 'Tax rule added', description: 'New lines can now use it.' })
      setFormOpen(false)
      setName('')
      setRate('')
      await load()
    } catch (err) {
      toast({ title: 'Could not add tax rule', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function remove(t: TaxRule) {
    if (!confirm(`Delete tax rule "${t.name}"? Existing invoices keep their recorded rates.`)) return
    try {
      await api.del(`/api/tax-rules/${t.id}`)
      toast({ title: 'Tax rule deleted' })
      await load()
    } catch (err) {
      toast({ title: 'Could not delete', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  if (!taxRules && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Tax rules"
        subtitle="The admin sets the rules; every invoice line calculates its tax from them automatically."
        actions={
          isAdmin ? (
            <Button onClick={() => setFormOpen(true)}><Plus className="mr-1.5 h-4 w-4" /> Add tax rule</Button>
          ) : (
            <p className="text-xs text-muted-foreground">Only the admin can change tax rules.</p>
          )
        }
      />

      {error ? <ErrorNote message={error} /> : null}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {(taxRules ?? []).map((t) => (
          <div key={t.id} className="group flex items-center justify-between rounded-xl border bg-card p-4 shadow-sm transition-shadow hover:shadow-md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary/12 p-2.5 text-primary"><Receipt className="h-5 w-5" /></div>
              <div>
                <p className="font-semibold leading-tight">{t.name}</p>
                <p className="text-xs text-muted-foreground">{t.rate}% on every eligible line</p>
              </div>
            </div>
            {isAdmin ? (
              <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                onClick={() => remove(t)} aria-label={`Delete ${t.name}`}>
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            ) : null}
          </div>
        ))}
      </div>

      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false) }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Add tax rule</DialogTitle>
            <DialogDescription>e.g. GST 18% or Export Zero Rate.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Name *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="GST 18%" />
            </div>
            <div className="space-y-1.5">
              <Label>Rate (%) *</Label>
              <Input type="number" min={0} max={100} step="0.01" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="18" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={busy || !name || rate === ''}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null} Add rule
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
