'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { fmtDate, fmtMoney, statusLabel } from './format'
import { AnimatedNumber, CardsSkeleton, ChartSkeleton, Segmented } from './interactive'
import { ErrorNote, PageHeader, StatCard, StatusBadge } from './ui-bits'
import { BillingRunDialog } from './invoices'
import type { DashboardData } from './types'
import { Button } from '@/components/ui/button'
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card'
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, BarChart, Bar, Legend,
} from 'recharts'
import {
  AlertTriangle, ArrowRight, BadgeIndianRupee, CalendarClock, ChevronRight,
  FileText, PlayCircle, RefreshCw, TrendingDown, TrendingUp, Users, Wallet, Zap,
} from 'lucide-react'

const PIE_COLORS = ['#2563eb', '#0ea5e9', '#f59e0b', '#f43f5e', '#8b5cf6', '#94a3b8']

const PERIODS = [
  { value: 'this_month', label: 'Month' },
  { value: 'quarter', label: 'Quarter' },
  { value: 'year', label: 'Year' },
  { value: 'all', label: 'All' },
] as const

export type DashboardNav =
  | { view: 'invoices'; status?: string }
  | { view: 'subscriptions'; status?: string; q?: string }
  | { view: 'reports' }

export function Dashboard({ onOpenInvoice, onNavigate }: {
  onOpenInvoice: (id: string) => void
  onNavigate: (nav: DashboardNav) => void
}) {
  const [data, setData] = useState<DashboardData | null>(null)
  const [dueCount, setDueCount] = useState<number | null>(null)
  const [autoCloseCount, setAutoCloseCount] = useState(0)
  const [duePreview, setDuePreview] = useState<{ number: string; customer: string }[]>([])
  const [period, setPeriod] = useState<string>('this_month')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [refreshing, setRefreshing] = useState(false)
  const [billingOpen, setBillingOpen] = useState(false)
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null)

  const load = useCallback(async (showSpinner = false) => {
    if (showSpinner) setRefreshing(true)
    setError('')
    try {
      const [d, p] = await Promise.all([
        api.get<DashboardData>(`/api/dashboard?period=${period}`),
        api.get<{ dueCount: number; autoCloseCount: number; due: { number: string; customer: string }[] }>('/api/billing'),
      ])
      setData(d)
      setDueCount(p.dueCount)
      setAutoCloseCount(p.autoCloseCount)
      setDuePreview(p.due)
      setUpdatedAt(new Date())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [period])

  useEffect(() => { load(true) }, [load])

  if (loading && !data) {
    return (
      <div className="space-y-6" aria-busy="true">
        <div className="h-14 w-72 animate-pulse rounded-lg bg-muted/70" />
        <div className="h-24 animate-pulse rounded-xl bg-muted/60" />
        <CardsSkeleton count={4} />
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          <Card className="xl:col-span-2"><ChartSkeleton /></Card>
          <Card><ChartSkeleton /></Card>
        </div>
        <CardsSkeleton count={4} />
      </div>
    )
  }
  if (error && !data) {
    return (
      <div className="space-y-3">
        <ErrorNote message={error || 'No data'} />
        <Button variant="outline" size="sm" onClick={() => load(true)}>
          <RefreshCw className="h-4 w-4" /> Try again
        </Button>
      </div>
    )
  }
  if (!data) return null

  const k = data.kpis
  const revDelta = k.revenueThisMonth - k.revenuePrevMonth
  const deltaPct = k.revenuePrevMonth > 0 ? Math.round((revDelta / k.revenuePrevMonth) * 100) : null
  const invoicePie = data.invoicesByStatus.filter((s) => s.count > 0)

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Overview"
        title="Billing overview"
        subtitle="Active subscriptions, revenue, payments and outstanding — the whole month in one view."
        actions={
          <>
            <span className="hidden text-[11px] text-muted-foreground lg:inline" aria-live="polite">
              {updatedAt ? `Updated ${updatedAt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}` : ''}
            </span>
            <Button variant="outline" size="icon" onClick={() => load(true)} disabled={refreshing} aria-label="Refresh data">
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            </Button>
            <Segmented
              value={period}
              onChange={setPeriod}
              options={PERIODS.map((p) => ({ value: p.value, label: p.label }))}
              aria-label="Reporting period"
            />
          </>
        }
      />

      {/* Billing day hero */}
      <Card className="cb-hero relative overflow-hidden border-0 text-white">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0">
          <div className="absolute -right-16 -top-24 h-64 w-64 rounded-full bg-blue-400/15 blur-2xl" />
          <div className="absolute -bottom-28 left-1/3 h-56 w-56 rounded-full bg-violet-300/10 blur-2xl" />
          <svg className="absolute right-6 top-0 h-full opacity-[0.07]" viewBox="0 0 200 120" fill="none" preserveAspectRatio="xMaxYMid slice">
            <path d="M0 90c40 0 40-60 80-60s40 60 80 60 40-60 80-60" stroke="white" strokeWidth="3" strokeLinecap="round" />
          </svg>
        </div>
        <CardContent className="relative flex flex-wrap items-center justify-between gap-4 p-6">
          <div className="flex items-start gap-4">
            <div className="rounded-lg bg-blue-400/20 p-3 shadow-[0_0_24px_-4px_rgba(96,165,250,0.5)] ring-1 ring-blue-300/30">
              <Zap className="h-6 w-6 text-blue-200" />
            </div>
            <div>
              <p className="text-lg font-bold">Billing day</p>
              <p className="mt-0.5 text-sm text-blue-50/80">
                {dueCount && dueCount > 0
                  ? `${dueCount} subscription${dueCount === 1 ? '' : 's'} due for invoicing right now${autoCloseCount ? ` · ${autoCloseCount} finished plan${autoCloseCount === 1 ? '' : 's'} will close` : ''}.`
                  : 'Everything is billed — no subscriptions are waiting.'}
              </p>
              {dueCount && dueCount > 0 ? (
                <p className="mt-1 text-xs text-blue-100/60">
                  Next up: {duePreview.slice(0, 3).map((d) => `${d.number} (${d.customer})`).join(', ')}{dueCount > 3 ? ` +${dueCount - 3} more` : ''}
                </p>
              ) : null}
            </div>
          </div>
          <Button size="lg" className="bg-white text-[oklch(0.29_0.065_264)] hover:bg-blue-50" onClick={() => setBillingOpen(true)}>
            <PlayCircle className="mr-2 h-4.5 w-4.5" />
            Run billing day
          </Button>
        </CardContent>
      </Card>

      {/* KPI cards — click to drill into the underlying list */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4 stagger">
        <StatCard
          label="Active subscriptions" icon={RefreshCw} tone="blue"
          onClick={() => onNavigate({ view: 'subscriptions', status: 'ACTIVE' })}
          value={<AnimatedNumber value={k.activeSubscriptions} />}
          sub={<span className="inline-flex items-center gap-0.5">{k.customers} customers on the books <ChevronRight className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-100" /></span>}
        />
        <StatCard
          label="Monthly recurring revenue" icon={BadgeIndianRupee} tone="indigo"
          onClick={() => onNavigate({ view: 'reports' })}
          value={<AnimatedNumber value={k.mrr} format={(v) => fmtMoney(v, true)} />}
          sub="Normalised from live subscription lines"
        />
        <StatCard
          label={period === 'this_month' ? 'Revenue this month' : 'Revenue in period'} icon={Wallet} tone="default"
          onClick={() => onNavigate({ view: 'invoices' })}
          value={<AnimatedNumber value={k.revenueInPeriod} format={(v) => fmtMoney(v, true)} />}
          sub={
            <span className="inline-flex items-center gap-1">
              {revDelta >= 0 ? <TrendingUp className="h-3.5 w-3.5 text-emerald-600" /> : <TrendingDown className="h-3.5 w-3.5 text-rose-600" />}
              {deltaPct === null ? `Prev month ${fmtMoney(k.revenuePrevMonth, true)}` : `${revDelta >= 0 ? '+' : ''}${deltaPct}% vs last month`}
            </span>
          }
        />
        <StatCard
          label="Outstanding" icon={FileText} tone="amber"
          onClick={() => onNavigate({ view: 'invoices', status: 'CONFIRMED' })}
          value={<AnimatedNumber value={k.outstandingTotal} format={(v) => fmtMoney(v, true)} />}
          sub={`${k.openInvoices} open invoice${k.openInvoices === 1 ? '' : 's'}`}
        />
      </div>

      {/* Overdue banner */}
      {k.overdueCount > 0 ? (
        <div className="flex flex-wrap items-center gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 dark:border-rose-900 dark:bg-rose-950/40">
          <AlertTriangle className="h-5 w-5 shrink-0 text-rose-600 dark:text-rose-400" />
          <p className="flex-1 text-sm text-rose-800 dark:text-rose-200">
            <span className="font-bold">{k.overdueCount} overdue invoice{k.overdueCount === 1 ? '' : 's'}</span> worth{' '}
            <span className="font-bold">{fmtMoney(k.overdueAmount)}</span> — chase these before they turn into lost revenue.
          </p>
          <Button size="sm" variant="outline" className="border-rose-300 text-rose-700 hover:bg-rose-100 hover:text-rose-800 dark:border-rose-800 dark:text-rose-300"
            onClick={() => onNavigate({ view: 'invoices', status: 'CONFIRMED' })}>
            Review <ArrowRight className="ml-1 h-3.5 w-3.5" />
          </Button>
        </div>
      ) : null}

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Revenue collected</CardTitle>
            <CardDescription>Payments received over the last 6 months</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.revenueByMonth} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#2563eb" stopOpacity={0.32} />
                    <stop offset="100%" stopColor="#2563eb" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} vertical={false} />
                <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} />
                <YAxis tickLine={false} axisLine={false} fontSize={12} tickFormatter={(v: number) => fmtMoney(v, true)} width={62} />
                <Tooltip
                  formatter={(v) => [fmtMoney(Number(v)), 'Collected']}
                  contentStyle={{ borderRadius: 10, border: '1px solid rgba(0,0,0,0.08)' }}
                  cursor={{ stroke: '#2563eb', strokeOpacity: 0.25, strokeWidth: 1.5 }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#2563eb" strokeWidth={2.5} fill="url(#revGrad)"
                  activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Invoices by status</CardTitle>
            <CardDescription className="flex items-center gap-1">
              Click a slice to open those invoices
              <Zap className="h-3 w-3 text-amber-500" />
            </CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={invoicePie} dataKey="count" nameKey="status" innerRadius={52} outerRadius={82}
                  paddingAngle={3} strokeWidth={0}
                  onClick={(entry) => { const st = (entry as { status?: string })?.status; if (st) onNavigate({ view: 'invoices', status: st }) }}
                  className="cursor-pointer outline-none"
                >
                  {invoicePie.map((entry, i) => (
                    <Cell key={entry.status} fill={PIE_COLORS[i % PIE_COLORS.length]}
                      className="cursor-pointer transition-opacity hover:opacity-80 focus:outline-none" />
                  ))}
                </Pie>
                <Tooltip formatter={(v, n) => [v, statusLabel(String(n))]} contentStyle={{ borderRadius: 10 }} />
                <Legend formatter={(v) => statusLabel(String(v))} iconType="circle" iconSize={8} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Active subscriptions by plan</CardTitle>
            <CardDescription>Click a plan to see its subscriptions</CardDescription>
          </CardHeader>
          <CardContent className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data.subsByPlan} layout="vertical" margin={{ left: 8, right: 16 }}
                onClick={(e) => { const plan = (e?.activePayload?.[0]?.payload as { plan?: string } | undefined)?.plan; if (plan) onNavigate({ view: 'subscriptions', q: plan }) }}
                className="cursor-pointer outline-none"
              >
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} horizontal={false} />
                <XAxis type="number" tickLine={false} axisLine={false} fontSize={12} allowDecimals={false} />
                <YAxis type="category" dataKey="plan" tickLine={false} axisLine={false} fontSize={11} width={130} />
                <Tooltip contentStyle={{ borderRadius: 10 }} cursor={{ fill: 'currentColor', opacity: 0.06 }} />
                <Bar dataKey="count" fill="#3b82f6" radius={[0, 6, 6, 0]} barSize={16} name="Active subs"
                  className="transition-opacity hover:opacity-80" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Overdue table */}
        <Card className="xl:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-base">Overdue invoices</CardTitle>
              <CardDescription>Oldest first — follow up today</CardDescription>
            </div>
            <AlertTriangle className="h-4.5 w-4.5 text-rose-500" />
          </CardHeader>
          <CardContent>
            {data.overdueList.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">Nothing overdue. Enjoy the quiet.</p>
            ) : (
              <div className="overflow-hidden rounded-lg border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2 font-medium">Invoice</th>
                      <th className="px-3 py-2 font-medium">Customer</th>
                      <th className="px-3 py-2 font-medium text-right">Balance</th>
                      <th className="px-3 py-2 font-medium text-right">Due</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.overdueList.map((i) => (
                      <tr key={i.id} tabIndex={0} role="button"
                        className="group cursor-pointer border-t transition-colors hover:bg-muted/40 focus-visible:bg-muted/40 focus-visible:outline-none"
                        onClick={() => onOpenInvoice(i.id)}
                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onOpenInvoice(i.id) } }}>
                        <td className="px-3 py-2 font-medium group-hover:text-primary">{i.number}</td>
                        <td className="px-3 py-2">{i.customer}</td>
                        <td className="px-3 py-2 text-right font-semibold text-rose-600">
                          {fmtMoney(i.total - i.amountPaid)}
                        </td>
                        <td className="px-3 py-2 text-right">
                          <span className="rounded-full bg-rose-100 px-2 py-0.5 text-xs font-semibold text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                            {i.daysOverdue}d late
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent + renewals */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Latest invoices</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            {data.recentInvoices.map((i) => (
              <button key={i.id} onClick={() => onOpenInvoice(i.id)}
                className="group flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition-colors hover:bg-muted/50">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-blue-100 text-blue-600 transition-transform group-hover:scale-110 dark:bg-blue-950/70 dark:text-blue-300">
                  <FileText className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13.5px] font-medium group-hover:text-primary">{i.number} · {i.customer}</p>
                  <p className="text-xs text-muted-foreground">Issued {fmtDate(i.issueDate)} · due {fmtDate(i.dueDate)}</p>
                </div>
                <div className="text-right">
                  <p className="text-[13.5px] font-semibold">{fmtMoney(i.total)}</p>
                  <StatusBadge status={i.status} className="mt-0.5" />
                </div>
                <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/0 transition-all group-hover:text-muted-foreground/70" />
              </button>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Renewals in the next 30 days</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            {data.upcomingRenewals.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">No plans ending soon.</p>
            ) : (
              data.upcomingRenewals.map((s) => (
                <button key={s.id}
                  onClick={() => onNavigate({ view: 'subscriptions', q: s.number })}
                  className="group flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition-colors hover:bg-muted/50">
                  <div className="flex h-8 w-8 items-center justify-center rounded-md bg-blue-100 text-blue-700 transition-transform group-hover:scale-110 dark:bg-blue-950/70 dark:text-blue-300">
                    <CalendarClock className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-medium">{s.customer}</p>
                    <p className="text-xs text-muted-foreground">{s.number} · {s.plan}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[13px] font-medium">{fmtDate(s.expiryDate)}</p>
                    {s.canRenew ? <p className="text-[11px] font-medium text-blue-600 dark:text-blue-400">renewable</p> : <p className="text-[11px] text-muted-foreground">auto-close</p>}
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/0 transition-all group-hover:text-muted-foreground/70" />
                </button>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Subscription status strip */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Users className="h-4 w-4" /> Subscription pipeline</CardTitle>
          <CardDescription>Every stage is clickable — jump straight into that list</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3 stagger">
          {data.subscriptionsByStatus.map((s) => (
            <button key={s.status} onClick={() => onNavigate({ view: 'subscriptions', status: s.status })}
              className="group flex items-center gap-2 rounded-lg border px-3 py-2 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md">
              <StatusBadge status={s.status} />
              <span className="num text-lg font-bold group-hover:text-primary">{s.count}</span>
            </button>
          ))}
        </CardContent>
      </Card>

      {/* Billing day dialog (shared with Invoices view) */}
      <BillingRunDialog open={billingOpen} onClose={() => setBillingOpen(false)} onRan={() => load()} />
    </div>
  )
}
