'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { api, getAll } from './api-client'
import { ExportButton } from './export-button'
import { fmtMoney } from './format'
import { ErrorNote, PageHeader, Spinner, StatCard } from './ui-bits'
import { AnimatedNumber, Segmented } from './interactive'
import type { DashboardData, Invoice, Payment, Subscription } from './types'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  ResponsiveContainer, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, Legend,
} from 'recharts'
import {
  ArrowDownRight, ArrowUpRight, BadgeIndianRupee, Crown, FileText, RefreshCw,
  Target, TrendingUp, Wallet,
} from 'lucide-react'

const PIE_COLORS = ['#10b981', '#f59e0b', '#14b8a6', '#f43f5e', '#a78bfa', '#8b93a7', '#fb923c']

function monthlyNorm(amount: number, cycle: string) {
  if (cycle === 'DAILY') return amount * 30
  if (cycle === 'WEEKLY') return (amount * 30) / 7
  if (cycle === 'YEARLY') return amount / 12
  return amount
}

const METHOD_LABELS: Record<string, string> = {
  CARD: 'Card',
  BANK_TRANSFER: 'Bank transfer',
  UPI: 'UPI',
  CASH: 'Cash',
  CHEQUE: 'Cheque',
}

export function Reports() {
  const [dash, setDash] = useState<DashboardData | null>(null)
  const [subs, setSubs] = useState<Subscription[] | null>(null)
  const [invoices, setInvoices] = useState<Invoice[] | null>(null)
  const [payments, setPayments] = useState<Payment[] | null>(null)
  const [customerCount, setCustomerCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [revChart, setRevChart] = useState<'bars' | 'trend'>('bars')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [d, s, i, p, c] = await Promise.all([
        api.get<DashboardData>('/api/dashboard?period=all'),
        getAll<'subscriptions', Subscription>('/api/subscriptions', 'subscriptions'),
        getAll<'invoices', Invoice>('/api/invoices', 'invoices'),
        getAll<'payments', Payment>('/api/payments', 'payments'),
        api.get<{ customers: unknown[]; total: number }>('/api/customers?limit=1').catch(() => ({ customers: [], total: 0 })),
      ])
      setDash(d)
      setSubs(s.subscriptions)
      setInvoices(i.invoices)
      setPayments(p.payments)
      setCustomerCount(c.total)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load reports')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const analysis = useMemo(() => {
    if (!subs || !invoices || !payments || !dash) return null

    // MRR by plan (active subscriptions, normalised to a month)
    const mrrByPlanMap: Record<string, number> = {}
    let mrrTotal = 0
    for (const s of subs.filter((x) => x.status === 'ACTIVE')) {
      const plan = s.plan?.name ?? 'Custom'
      const cycle = s.plan?.billingCycle ?? 'MONTHLY'
      const t = s.lines.reduce((sum, l) => sum + l.quantity * l.unitPrice * (1 + l.taxRate / 100), 0)
      const m = monthlyNorm(t, cycle)
      mrrByPlanMap[plan] = (mrrByPlanMap[plan] ?? 0) + m
      mrrTotal += m
    }
    const mrrByPlan = Object.entries(mrrByPlanMap)
      .map(([plan, mrr]) => ({ plan, mrr: Math.round(mrr) }))
      .sort((a, b) => b.mrr - a.mrr)

    // collection quality
    const real = invoices.filter((i) => i.status === 'CONFIRMED' || i.status === 'PAID')
    const billed = real.reduce((sum, i) => sum + i.total, 0)
    const collected = real.reduce((sum, i) => sum + i.amountPaid, 0)
    const collectionRate = billed > 0 ? Math.round((collected / billed) * 100) : 100
    const avgInvoice = real.length > 0 ? Math.round(billed / real.length) : 0

    // invoice aging buckets (open, past due)
    const today = Date.now()
    const buckets = [
      { bucket: '1–30d', count: 0, total: 0 },
      { bucket: '31–60d', count: 0, total: 0 },
      { bucket: '61–90d', count: 0, total: 0 },
      { bucket: '90d+', count: 0, total: 0 },
    ]
    for (const inv of invoices) {
      if (inv.status !== 'CONFIRMED') continue
      const over = Math.floor((today - new Date(inv.dueDate).getTime()) / 86400000)
      if (over <= 0) continue
      const idx = over <= 30 ? 0 : over <= 60 ? 1 : over <= 90 ? 2 : 3
      buckets[idx].count += 1
      buckets[idx].total += inv.total - inv.amountPaid
    }

    // payment method mix
    const methodMap: Record<string, number> = {}
    for (const p of payments) {
      const label = METHOD_LABELS[p.method] ?? p.method
      methodMap[label] = (methodMap[label] ?? 0) + p.amount
    }
    const methodMix = Object.entries(methodMap)
      .map(([name, value]) => ({ name, value: Math.round(value) }))
      .sort((a, b) => b.value - a.value)

    // top customers by payments received
    const custMap: Record<string, number> = {}
    for (const p of payments) {
      const name = p.customer?.name ?? 'Unknown'
      custMap[name] = (custMap[name] ?? 0) + p.amount
    }
    const topCustomers = Object.entries(custMap)
      .map(([name, amount]) => ({ name, amount: Math.round(amount) }))
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 6)

    // revenue insights
    const months = dash.revenueByMonth
    const best = months.reduce((m, x) => (x.revenue > m.revenue ? x : m), months[0] ?? { month: '—', revenue: 0 })
    const last = months[months.length - 1]
    const prev = months[months.length - 2]
    const momDelta = prev ? last.revenue - prev.revenue : 0
    const momPct = prev && prev.revenue > 0 ? Math.round((momDelta / prev.revenue) * 100) : null

    const arpu = customerCount > 0 ? Math.round(mrrTotal / customerCount) : 0

    return { mrrTotal, mrrByPlan, collectionRate, avgInvoice, buckets, methodMix, topCustomers, best, momDelta, momPct, arpu }
  }, [subs, invoices, payments, dash, customerCount])

  if (loading) return <Spinner />
  if (error || !dash || !analysis) {
    return (
      <div className="space-y-3">
        <ErrorNote message={error || 'No data'} />
        <Button variant="outline" size="sm" onClick={load}>
          <RefreshCw className="h-4 w-4" /> Try again
        </Button>
      </div>
    )
  }

  const a = analysis

  return (
    <div className="space-y-6">
      <PageHeader
        title="Reports & analytics"
        subtitle="Recurring revenue, collections and customer value — computed live from your books."
        actions={
          <div className="flex flex-wrap gap-2">
            <ExportButton label="Invoices CSV" url="/api/invoices.csv" filename="invoices.csv" />
            <ExportButton label="Payments CSV" url="/api/payments.csv" filename="payments.csv" />
            <ExportButton label="Subscriptions CSV" url="/api/subscriptions.csv" filename="subscriptions.csv" />
          </div>
        }
      />

      {/* KPI row */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4 stagger">
        <StatCard
          label="Monthly recurring revenue"
          value={<AnimatedNumber value={a.mrrTotal} format={(v) => fmtMoney(v, true)} />}
          sub="Normalised across billing cycles" icon={BadgeIndianRupee} tone="teal"
        />
        <StatCard
          label="ARPU"
          value={<AnimatedNumber value={a.arpu} format={(v) => fmtMoney(v, true)} />}
          sub={`Across ${customerCount || dash.kpis.customers} customers`} icon={Target} tone="emerald"
        />
        <StatCard
          label="Collection rate"
          value={<AnimatedNumber value={a.collectionRate} format={(v) => `${Math.round(v)}%`} />}
          sub="Collected vs billed (all time)" icon={TrendingUp} tone="default"
        />
        <StatCard
          label="Avg invoice value"
          value={<AnimatedNumber value={a.avgInvoice} format={(v) => fmtMoney(v)} />}
          sub="Non-draft invoices" icon={FileText} tone="amber"
        />
      </div>

      {/* insight strip */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <InsightCard
          icon={a.momDelta >= 0 ? ArrowUpRight : ArrowDownRight}
          tone={a.momDelta >= 0 ? 'emerald' : 'rose'}
          title="Month over month"
          body={`Latest month collected ${fmtMoney(dash.revenueByMonth[dash.revenueByMonth.length - 1]?.revenue ?? 0, true)}${a.momPct === null ? '' : ` — ${a.momDelta >= 0 ? 'up' : 'down'} ${Math.abs(a.momPct)}% vs the previous month`}.`}
        />
        <InsightCard
          icon={Crown}
          tone="amber"
          title="Best month"
          body={`${a.best.month} leads the books with ${fmtMoney(a.best.revenue, true)} collected.`}
        />
        <InsightCard
          icon={Wallet}
          tone="teal"
          title="Recurring engine"
          body={`${a.mrrByPlan.length} plan${a.mrrByPlan.length === 1 ? '' : 's'} contribute to MRR — ${a.mrrByPlan[0]?.plan ?? '—'} is the biggest earner at ${fmtMoney(a.mrrByPlan[0]?.mrr ?? 0, true)}/mo.`}
        />
      </div>

      {/* charts row 1 */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader className="flex-row items-start justify-between space-y-0">
            <div>
              <CardTitle className="text-base">Revenue collected</CardTitle>
              <CardDescription>Payments received per month</CardDescription>
            </div>
            <Segmented
              value={revChart}
              onChange={setRevChart}
              options={[
                { value: 'bars', label: 'Bars' },
                { value: 'trend', label: 'Trend' },
              ]}
              size="sm"
              aria-label="Revenue chart style"
            />
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              {revChart === 'bars' ? (
                <BarChart data={dash.revenueByMonth} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} />
                  <YAxis tickLine={false} axisLine={false} fontSize={12} tickFormatter={(v: number) => fmtMoney(v, true)} width={62} />
                  <Tooltip
                    formatter={(v) => [fmtMoney(Number(v)), 'Collected']}
                    contentStyle={{ borderRadius: 10, border: '1px solid rgba(0,0,0,0.08)' }}
                    cursor={{ fill: 'currentColor', opacity: 0.06 }}
                  />
                  <Bar dataKey="revenue" fill="#10b981" radius={[6, 6, 0, 0]} maxBarSize={44} name="Collected" className="transition-opacity hover:opacity-80" />
                </BarChart>
              ) : (
                <AreaChart data={dash.revenueByMonth} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="repGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} />
                  <YAxis tickLine={false} axisLine={false} fontSize={12} tickFormatter={(v: number) => fmtMoney(v, true)} width={62} />
                  <Tooltip
                    formatter={(v) => [fmtMoney(Number(v)), 'Collected']}
                    contentStyle={{ borderRadius: 10, border: '1px solid rgba(0,0,0,0.08)' }}
                    cursor={{ stroke: '#10b981', strokeOpacity: 0.3, strokeWidth: 1.5 }}
                  />
                  <Area type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={2.5} fill="url(#repGrad)"
                    activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }} />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">How customers pay</CardTitle>
            <CardDescription>Share of payments by method</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            {a.methodMix.length === 0 ? (
              <p className="pt-16 text-center text-sm text-muted-foreground">No payments recorded yet.</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={a.methodMix} dataKey="value" nameKey="name" innerRadius={52} outerRadius={82} paddingAngle={3} strokeWidth={0}>
                    {a.methodMix.map((entry, i) => (
                      <Cell key={entry.name} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v) => fmtMoney(Number(v))} contentStyle={{ borderRadius: 10 }} />
                  <Legend iconType="circle" iconSize={8} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* charts row 2 */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">MRR by plan</CardTitle>
            <CardDescription>Normalised monthly value of active subscriptions</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={a.mrrByPlan} layout="vertical" margin={{ left: 8, right: 16 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} horizontal={false} />
                <XAxis type="number" tickLine={false} axisLine={false} fontSize={12} tickFormatter={(v: number) => fmtMoney(v, true)} />
                <YAxis type="category" dataKey="plan" tickLine={false} axisLine={false} fontSize={11} width={130} />
                <Tooltip formatter={(v) => fmtMoney(Number(v))} contentStyle={{ borderRadius: 10 }} />
                <Bar dataKey="mrr" fill="#14b8a6" radius={[0, 6, 6, 0]} barSize={16} name="MRR" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Invoice aging</CardTitle>
            <CardDescription>Open invoices by days past due</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={a.buckets} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} vertical={false} />
                <XAxis dataKey="bucket" tickLine={false} axisLine={false} fontSize={12} />
                <YAxis tickLine={false} axisLine={false} fontSize={12} allowDecimals={false} />
                <Tooltip
                  formatter={(v, n) => (n === 'count' ? [v, 'Invoices'] : [fmtMoney(Number(v)), 'Outstanding'])}
                  contentStyle={{ borderRadius: 10 }}
                />
                <Bar dataKey="count" fill="#f43f5e" radius={[6, 6, 0, 0]} maxBarSize={44} name="count" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* top customers */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Top customers by payments</CardTitle>
          <CardDescription>All-time collections, ranked</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {a.topCustomers.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No payments recorded yet.</p>
          ) : (
            a.topCustomers.map((c, i) => {
              const max = a.topCustomers[0].amount || 1
              return (
                <div key={c.name}>
                  <div className="mb-1.5 flex items-center justify-between gap-3 text-sm">
                    <span className="flex min-w-0 items-center gap-2">
                      <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-bold ${i === 0 ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300' : 'bg-muted text-muted-foreground'}`}>
                        {i + 1}
                      </span>
                      <span className="truncate font-medium">{c.name}</span>
                    </span>
                    <span className="shrink-0 font-bold">{fmtMoney(c.amount, true)}</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className={`h-full rounded-full ${i === 0 ? 'bg-gradient-to-r from-amber-400 to-orange-400' : 'bg-gradient-to-r from-emerald-500 to-teal-400'}`}
                      style={{ width: `${Math.max(4, Math.round((c.amount / max) * 100))}%` }}
                    />
                  </div>
                </div>
              )
            })
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function InsightCard({
  icon: Icon, tone, title, body,
}: {
  icon: typeof TrendingUp
  tone: 'emerald' | 'amber' | 'teal' | 'rose'
  title: string
  body: string
}) {
  const tones: Record<string, string> = {
    emerald: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
    teal: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300',
    amber: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
    rose: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300',
  }
  return (
    <div className="flex items-start gap-3.5 rounded-2xl border bg-card p-4 shadow-sm">
      <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${tones[tone]}`}>
        <Icon className="h-5 w-5" aria-hidden="true" />
      </div>
      <div className="min-w-0">
        <p className="text-sm font-bold">{title}</p>
        <p className="mt-0.5 text-[13px] leading-relaxed text-muted-foreground">{body}</p>
      </div>
    </div>
  )
}
