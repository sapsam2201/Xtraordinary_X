'use client'

import { statusClass, statusLabel } from './format'
import { cn } from '@/lib/utils'
import type { LucideIcon } from 'lucide-react'

export function Logo({ size = 36, dark = false }: { size?: number; dark?: boolean }) {
  return (
    <div className="flex items-center gap-2.5 select-none">
      <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
        <rect width="48" height="48" rx="13" className={dark ? 'fill-emerald-400/90' : 'fill-emerald-500'} />
        <path
          d="M14 30.5c0-8 6-8 10-8s10 0 10-8M14 15h17M14 33h17"
          stroke="white" strokeWidth="3.4" strokeLinecap="round"
        />
        <circle cx="33" cy="14.5" r="3" fill="white" />
        <circle cx="14" cy="33" r="3" fill="white" />
      </svg>
      <div className="leading-tight">
        <div className={cn('font-bold tracking-tight text-[15px]', dark ? 'text-white' : 'text-foreground')}>
          Brightloop
        </div>
        <div className={cn('text-[10.5px] font-medium uppercase tracking-widest', dark ? 'text-emerald-200/70' : 'text-muted-foreground')}>
          Subscriptions
        </div>
      </div>
    </div>
  )
}

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-semibold tracking-wide',
        statusClass(status),
        className
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" aria-hidden="true" />
      {statusLabel(status)}
    </span>
  )
}

const STAT_TONES: Record<string, string> = {
  default: 'bg-slate-100 text-slate-600 dark:bg-slate-800/80 dark:text-slate-300',
  blue: 'bg-blue-100 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300',
  indigo: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300',
  emerald: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300',
  amber: 'bg-amber-100 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300',
  rose: 'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300',
  teal: 'bg-teal-100 text-teal-700 dark:bg-teal-950/70 dark:text-teal-300',
}

export function StatCard({
  label, value, sub, icon: Icon, tone = 'default', onClick, href,
}: {
  label: string
  value: React.ReactNode
  sub?: React.ReactNode
  icon: LucideIcon
  tone?: 'default' | 'blue' | 'indigo' | 'emerald' | 'amber' | 'rose' | 'teal'
  onClick?: () => void
  href?: string
}) {
  const body = (
    <>
      <div className="flex items-center justify-between gap-3">
        <p className="text-[12.5px] font-medium text-muted-foreground">{label}</p>
        <div className={cn('rounded-md p-2 shrink-0', STAT_TONES[tone])}>
          <Icon className="h-4 w-4" aria-hidden="true" />
        </div>
      </div>
      <p className="mt-1 text-[24px] font-semibold leading-tight tracking-tight text-foreground">{value}</p>
      {sub ? <div className="mt-1.5 text-xs text-muted-foreground">{sub}</div> : null}
    </>
  )
  const shell = cn(
    'block rounded-lg border bg-card px-5 py-4 text-left shadow-[0_1px_2px_oklch(0.24_0.035_264/0.05)] transition-all duration-200',
    onClick || href
      ? 'cursor-pointer hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-[0_10px_24px_-8px_oklch(0.35_0.06_264/0.22)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50'
      : 'hover:shadow-[0_4px_16px_-4px_oklch(0.35_0.06_264/0.14)]',
  )
  if (href) {
    return <a href={href} className={shell}>{body}</a>
  }
  if (onClick) {
    return <button type="button" onClick={onClick} className={shell}>{body}</button>
  }
  return <div className={shell}>{body}</div>
}

export function EmptyState({ title, hint, icon: Icon }: { title: string; hint?: string; icon?: LucideIcon }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed bg-card py-14 text-center">
      {Icon ? (
        <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-7 w-7" aria-hidden="true" />
        </div>
      ) : null}
      <div>
        <p className="font-semibold text-foreground">{title}</p>
        {hint ? <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">{hint}</p> : null}
      </div>
    </div>
  )
}

export function PageHeader({
  title, subtitle, actions, eyebrow,
}: {
  title: string
  subtitle?: string
  actions?: React.ReactNode
  eyebrow?: string
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        {eyebrow ? (
          <p className="mb-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-primary/80">{eyebrow}</p>
        ) : null}
        <h1 className="text-[21px] font-bold leading-tight tracking-tight text-foreground">{title}</h1>
        {subtitle ? <p className="mt-1 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">{subtitle}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  )
}

const AVATAR_HUES = [
  'bg-blue-100 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300',
  'bg-violet-100 text-violet-700 dark:bg-violet-950/70 dark:text-violet-300',
  'bg-teal-100 text-teal-700 dark:bg-teal-950/70 dark:text-teal-300',
  'bg-amber-100 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300',
  'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300',
  'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/70 dark:text-cyan-300',
]

export function Avatar({ name, className }: { name: string; className?: string }) {
  const initials = name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase()
  let hash = 0
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0
  return (
    <div
      className={cn(
        'flex shrink-0 items-center justify-center rounded-md font-semibold',
        AVATAR_HUES[hash % AVATAR_HUES.length],
        className ?? 'h-8 w-8 text-[12px]',
      )}
      aria-hidden="true"
    >
      {initials}
    </div>
  )
}

export function Spinner({ className }: { className?: string }) {
  return (
    <div className={cn('flex items-center justify-center py-16', className)} role="status" aria-label="Loading">
      <div className="h-7 w-7 animate-spin rounded-full border-[3px] border-primary/25 border-t-primary" />
    </div>
  )
}

export function ErrorNote({ message }: { message: string }) {
  return (
    <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
      {message}
    </div>
  )
}
