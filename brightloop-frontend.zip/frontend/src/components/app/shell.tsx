'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { fmtMoney } from './format'
import { Logo } from './ui-bits'
import { CommandPalette } from './command-palette'
import type { SessionUser } from './types'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTitle } from '@/components/ui/sheet'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Activity, BadgePercent, BarChart3, Bell, CalendarClock, ChevronRight, CreditCard, FileStack, FileText,
  Layers, LayoutDashboard, LogOut, Moon, Package, Receipt, RefreshCw, Search, Settings, Sun, UserCog, Users,
} from 'lucide-react'

export type ViewKey =
  | 'dashboard' | 'subscriptions' | 'invoices' | 'payments' | 'billingruns'
  | 'customers' | 'products' | 'plans' | 'templates' | 'discounts' | 'taxes'
  | 'reports' | 'activity' | 'staff' | 'settings'

const NAV: { key: ViewKey; label: string; icon: typeof LayoutDashboard; adminOnly?: boolean; group: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, group: 'Overview' },
  { key: 'subscriptions', label: 'Subscriptions', icon: RefreshCw, group: 'Recurring billing' },
  { key: 'invoices', label: 'Invoices', icon: FileText, group: 'Recurring billing' },
  { key: 'payments', label: 'Payments', icon: CreditCard, group: 'Recurring billing' },
  { key: 'billingruns', label: 'Billing runs', icon: CalendarClock, group: 'Recurring billing' },
  { key: 'customers', label: 'Customers', icon: Users, group: 'Customers & catalog' },
  { key: 'products', label: 'Products', icon: Package, group: 'Customers & catalog' },
  { key: 'plans', label: 'Plans', icon: Layers, group: 'Customers & catalog' },
  { key: 'templates', label: 'Quotation templates', icon: FileStack, group: 'Customers & catalog' },
  { key: 'discounts', label: 'Discounts', icon: BadgePercent, group: 'Finance setup' },
  { key: 'taxes', label: 'Tax rules', icon: Receipt, group: 'Finance setup' },
  { key: 'reports', label: 'Reports & analytics', icon: BarChart3, group: 'Insights' },
  { key: 'activity', label: 'Activity feed', icon: Activity, group: 'Insights' },
  { key: 'staff', label: 'Staff & roles', icon: UserCog, group: 'Administration', adminOnly: true },
  { key: 'settings', label: 'Settings', icon: Settings, group: 'Administration' },
]

type DashAlerts = {
  kpis: { overdueCount: number; overdueAmount: number }
  overdueList: { id: string; number: string; customer: string; total: number; amountPaid: number; daysOverdue: number }[]
}

type Alerts = {
  overdueCount: number
  overdueAmount: number
  overdueList: { id: string; number: string; customer: string; total: number; amountPaid: number; daysOverdue: number }[]
  dueCount: number
}

export function Shell({
  user, view, onView, onLogout, onOpenInvoice, children,
}: {
  user: SessionUser
  view: ViewKey
  onView: (v: ViewKey) => void
  onLogout: () => void
  onOpenInvoice?: (id: string) => void
  children: React.ReactNode
}) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [dark, setDark] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [alerts, setAlerts] = useState<Alerts | null>(null)

  // Live "needs attention" feed for the header bell. Refreshed whenever the
  // user moves between views so the badge stays fresh without polling.
  const loadAlerts = useCallback(() => {
    Promise.all([
      api.get<DashAlerts>('/api/dashboard?period=this_month').catch(() => null),
      api.get<{ dueCount: number }>('/api/billing').catch(() => null),
    ]).then(([d, b]) => {
      if (d || b) {
        setAlerts({
          overdueCount: d?.kpis.overdueCount ?? 0,
          overdueAmount: d?.kpis.overdueAmount ?? 0,
          overdueList: d?.overdueList ?? [],
          dueCount: b?.dueCount ?? 0,
        })
      }
    })
  }, [])

  useEffect(() => { loadAlerts() }, [loadAlerts, view])

  // While an internal user is in the workspace, re-skin the design tokens
  // to the enterprise navy/blue palette (dialogs included, since they
  // portal to <body>). The customer portal never mounts this component.
  useEffect(() => {
    document.documentElement.classList.add('cb-theme')
    return () => document.documentElement.classList.remove('cb-theme')
  }, [])

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setSearchOpen((v) => !v)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  function toggleTheme() {
    const next = !dark
    setDark(next)
    document.documentElement.classList.toggle('dark', next)
  }

  const items = NAV.filter((n) => !n.adminOnly || user.role === 'ADMIN')
  const groups = [...new Set(items.map((i) => i.group))]
  const current = NAV.find((n) => n.key === view)
  const currentGroup = current?.group ?? ''

  function navigateFromPalette(target: string, invoiceId?: string) {
    if (invoiceId && onOpenInvoice) {
      onOpenInvoice(invoiceId)
      return
    }
    onView(target as ViewKey)
  }

  const navList = (
    <nav className="flex-1 space-y-4 overflow-y-auto px-3 py-4 scroll-slim" aria-label="Main navigation">
      {groups.map((group) => (
        <div key={group}>
          <p className="mb-1 px-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-400/60">
            {group}
          </p>
          <div className="space-y-px">
            {items.filter((i) => i.group === group).map((item) => (
              <button
                key={item.key}
                onClick={() => { onView(item.key); setMobileOpen(false) }}
                aria-current={view === item.key ? 'page' : undefined}
                className={cn(
                  'group relative flex w-full items-center gap-2.5 rounded-md px-2.5 py-[7px] text-[13px] font-medium transition-colors duration-150',
                  view === item.key
                    ? 'bg-white/[0.09] text-white'
                    : 'text-slate-300/80 hover:bg-white/[0.05] hover:text-white'
                )}
              >
                {view === item.key ? (
                  <span className="absolute left-0 top-1/2 h-4.5 w-[3px] -translate-y-1/2 rounded-r-full bg-blue-400" aria-hidden="true" />
                ) : null}
                <item.icon className={cn('h-4 w-4 shrink-0 transition-colors', view === item.key ? 'text-blue-300' : 'text-slate-400 group-hover:text-slate-200')} aria-hidden="true" />
                <span className="truncate">{item.label}</span>
                {item.adminOnly ? (
                  <span className="ml-auto rounded bg-blue-400/15 px-1.5 py-0.5 text-[9px] font-bold tracking-wider text-blue-300">ADMIN</span>
                ) : null}
              </button>
            ))}
          </div>
        </div>
      ))}
    </nav>
  )

  const userCard = (
    <div className="border-t border-white/10 p-3">
      <div className="flex items-center gap-3 rounded-md bg-white/[0.05] px-3 py-2.5 ring-1 ring-white/[0.07] transition-colors hover:bg-white/[0.09]">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-blue-400/20 text-[12px] font-bold text-blue-200 ring-1 ring-blue-400/30">
          {user.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold text-white">{user.name}</p>
          <p className="text-[11px] text-slate-400">
            {user.role === 'ADMIN' ? 'Administrator' : 'Internal staff'}
          </p>
        </div>
        <button onClick={onLogout} aria-label="Sign out"
          className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-white/10 hover:text-white">
          <LogOut className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  )

  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="cb-sidebar sticky top-0 hidden h-screen w-[236px] shrink-0 flex-col lg:flex print-hide">
        <div className="border-b border-white/[0.08] px-5 py-4">
          <Logo size={32} dark />
        </div>
        {navList}
        {userCard}
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="cb-sidebar w-72 border-0 p-0 text-white">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          <div className="flex h-full flex-col">
            <div className="border-b border-white/[0.08] px-5 py-4"><Logo size={32} dark /></div>
            {navList}
            {userCard}
          </div>
        </SheetContent>
      </Sheet>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 border-b bg-background/90 backdrop-blur print-hide">
          <div className="flex h-14 items-center gap-3 px-4 sm:px-6">
            <Button variant="ghost" size="icon" className="-ml-2 lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </Button>

            {/* Breadcrumb */}
            <div className="flex min-w-0 items-center gap-1 text-[13px]" aria-label="Breadcrumb">
              <span className="hidden text-muted-foreground sm:inline">Brightloop</span>
              <ChevronRight className="hidden h-3.5 w-3.5 text-muted-foreground/50 sm:inline" aria-hidden="true" />
              {currentGroup ? (
                <>
                  <span className="hidden text-muted-foreground md:inline">{currentGroup}</span>
                  <ChevronRight className="hidden h-3.5 w-3.5 text-muted-foreground/50 md:inline" aria-hidden="true" />
                </>
              ) : null}
              <span className="truncate font-semibold text-foreground">{current?.label ?? 'Brightloop'}</span>
            </div>

            <div className="ml-auto flex items-center gap-2">
              {/* Needs-attention bell */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="relative flex h-9 w-9 items-center justify-center rounded-md border bg-card text-muted-foreground transition-colors hover:text-foreground" aria-label={`Alerts${alerts ? `, ${alerts.overdueCount} overdue, ${alerts.dueCount} due for billing` : ''}`}>
                    <Bell className="h-4 w-4" />
                    {alerts && (alerts.overdueCount > 0 || alerts.dueCount > 0) ? (
                      <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[9.5px] font-bold text-white ring-2 ring-background">
                        {alerts.overdueCount + alerts.dueCount > 9 ? '9+' : alerts.overdueCount + alerts.dueCount}
                      </span>
                    ) : null}
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80 p-0">
                  <DropdownMenuLabel className="flex items-center justify-between border-b px-3 py-2.5">
                    <span className="text-sm">Needs attention</span>
                    {alerts ? (
                      <span className="text-[11px] font-normal text-muted-foreground">
                        {alerts.overdueCount === 0 && alerts.dueCount === 0 ? 'All clear' : `${alerts.overdueCount + alerts.dueCount} item${alerts.overdueCount + alerts.dueCount === 1 ? '' : 's'}`}
                      </span>
                    ) : null}
                  </DropdownMenuLabel>
                  <div className="max-h-80 overflow-y-auto scroll-slim">
                    {!alerts ? (
                      <p className="px-4 py-6 text-center text-sm text-muted-foreground">Checking…</p>
                    ) : alerts.overdueCount === 0 && alerts.dueCount === 0 ? (
                      <div className="px-4 py-8 text-center">
                        <span className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-300">
                          <Activity className="h-5 w-5" />
                        </span>
                        <p className="text-sm font-semibold">Everything is on track</p>
                        <p className="mt-0.5 text-xs text-muted-foreground">No overdue invoices, no billing waiting.</p>
                      </div>
                    ) : (
                      <>
                        {alerts.overdueCount > 0 ? (
                          <button onClick={() => onView('invoices')} className="flex w-full items-center gap-3 px-3 py-2.5 text-left transition-colors hover:bg-accent">
                            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-rose-100 text-rose-600 dark:bg-rose-950 dark:text-rose-300">
                              <FileText className="h-4 w-4" />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="block text-[13px] font-semibold">{alerts.overdueCount} overdue invoice{alerts.overdueCount === 1 ? '' : 's'}</span>
                              <span className="block text-xs text-muted-foreground">{fmtMoney(alerts.overdueAmount)} outstanding — review now</span>
                            </span>
                            <ChevronRight className="h-4 w-4 text-muted-foreground/50" />
                          </button>
                        ) : null}
                        {alerts.overdueList.slice(0, 4).map((i) => (
                          <button key={i.id} onClick={() => { if (onOpenInvoice) onOpenInvoice(i.id) }} className="flex w-full items-center gap-3 px-3 py-2 pl-11 text-left transition-colors hover:bg-accent">
                            <span className="min-w-0 flex-1 truncate text-[13px] font-medium">{i.number} · {i.customer}</span>
                            <span className="shrink-0 rounded-full bg-rose-100 px-2 py-0.5 text-[10.5px] font-bold text-rose-700 dark:bg-rose-950 dark:text-rose-300">{i.daysOverdue}d</span>
                          </button>
                        ))}
                        {alerts.dueCount > 0 ? (
                          <button onClick={() => onView('billingruns')} className="flex w-full items-center gap-3 border-t px-3 py-2.5 text-left transition-colors hover:bg-accent">
                            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-blue-100 text-blue-600 dark:bg-blue-950 dark:text-blue-300">
                              <CalendarClock className="h-4 w-4" />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="block text-[13px] font-semibold">{alerts.dueCount} subscription{alerts.dueCount === 1 ? '' : 's'} due for billing</span>
                              <span className="block text-xs text-muted-foreground">Run billing day from the dashboard</span>
                            </span>
                            <ChevronRight className="h-4 w-4 text-muted-foreground/50" />
                          </button>
                        ) : null}
                      </>
                    )}
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Global search trigger */}
              <button
                onClick={() => setSearchOpen(true)}
                data-state={searchOpen ? 'open' : 'closed'}
                className="cb-search flex h-9 w-9 items-center justify-center rounded-md border bg-card text-muted-foreground transition-colors hover:text-foreground sm:w-64 sm:justify-start sm:px-3"
                aria-label="Search (Ctrl+K)"
              >
                <Search className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span className="ml-2 hidden text-[13px] sm:inline">Search everything…</span>
                <kbd className="ml-auto hidden rounded border bg-muted px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground sm:block">
                  ⌘K
                </kbd>
              </button>

              <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Toggle dark mode">
                {dark ? <Sun className="h-4.5 w-4.5" /> : <Moon className="h-4.5 w-4.5" />}
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex h-9 items-center gap-2 rounded-md pl-1 pr-2 transition-colors hover:bg-accent" aria-label="Account menu">
                    <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary/15 text-[11px] font-bold text-primary">
                      {user.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}
                    </span>
                    <span className="hidden text-[13px] font-medium md:inline">{user.name.split(' ')[0]}</span>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="text-sm font-semibold">{user.name}</div>
                    <div className="text-xs font-normal text-muted-foreground">{user.email}</div>
                    <div className="mt-1.5 inline-flex items-center rounded bg-primary/10 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary">
                      {user.role === 'ADMIN' ? 'Administrator' : 'Internal staff'}
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => onView('settings')}>Settings</DropdownMenuItem>
                  <DropdownMenuItem onClick={onLogout} className="text-destructive focus:text-destructive">Sign out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl view-enter">{children}</div>
        </main>

        <footer className="border-t py-4 text-center text-xs text-muted-foreground print-hide mt-auto">
          Brightloop Software — plans, subscriptions &amp; recurring billing in one place
        </footer>
      </div>

      <CommandPalette
        open={searchOpen}
        onOpenChange={setSearchOpen}
        onNavigate={navigateFromPalette}
      />
    </div>
  )
}
