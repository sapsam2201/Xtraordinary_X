'use client'

import { useState } from 'react'
import { Download, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { toast } from '@/hooks/use-toast'
import { downloadFile } from './api-client'

/** Downloads the current (filtered) list as a CSV file from an authenticated API endpoint. */
export function ExportButton({
  url, filename, label = 'Export CSV', variant = 'outline',
}: {
  url: string
  filename: string
  label?: string
  variant?: 'outline' | 'secondary' | 'ghost'
}) {
  const [busy, setBusy] = useState(false)
  async function run() {
    setBusy(true)
    try {
      await downloadFile(url, filename)
    } catch (err) {
      toast({ title: 'Export failed', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }
  return (
    <Button variant={variant} onClick={run} disabled={busy}>
      {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Download className="mr-1.5 h-4 w-4" />}
      {label}
    </Button>
  )
}

/** Builds a query string from the filters the user currently has applied (empty values are skipped). */
export function filterQuery(f: Record<string, string | undefined>): string {
  const p = new URLSearchParams()
  for (const [k, v] of Object.entries(f)) if (v && v !== 'ALL') p.set(k, v)
  const s = p.toString()
  return s ? `?${s}` : ''
}
