'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { fmtDate } from './format'
import { ErrorNote, PageHeader, Spinner } from './ui-bits'
import type { StaffUser } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { toast } from '@/hooks/use-toast'
import { Loader2, ShieldCheck, UserCog, UserRound } from 'lucide-react'

export function Staff({ currentUserId }: { currentUserId: string }) {
  const [users, setUsers] = useState<StaffUser[] | null>(null)
  const [error, setError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'STAFF' })

  const load = useCallback(async () => {
    setError('')
    try {
      const res = await api.get<{ users: StaffUser[] }>('/api/users')
      setUsers(res.users)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load users')
    }
  }, [])

  useEffect(() => { load() }, [load])

  async function addStaff() {
    setBusy(true)
    try {
      await api.post('/api/users', form)
      toast({ title: 'Staff member added', description: `${form.email} can sign in now.` })
      setFormOpen(false)
      setForm({ name: '', email: '', password: '', role: 'STAFF' })
      await load()
    } catch (err) {
      toast({ title: 'Could not add staff', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function toggleActive(u: StaffUser) {
    try {
      await api.patch(`/api/users/${u.id}`, { isActive: !u.isActive })
      toast({ title: u.isActive ? 'Account deactivated' : 'Account reactivated' })
      await load()
    } catch (err) {
      toast({ title: 'Could not update', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function removeUser(u: StaffUser) {
    if (!confirm(`Remove ${u.name}'s account completely?`)) return
    try {
      await api.del(`/api/users/${u.id}`)
      toast({ title: 'Account removed' })
      await load()
    } catch (err) {
      toast({ title: 'Could not remove', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  if (!users && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Staff & roles"
        subtitle="Admin controls the whole system, staff handle day-to-day work with limited access, customers see only their own portal."
        actions={<Button onClick={() => setFormOpen(true)}><UserCog className="mr-1.5 h-4 w-4" /> Add staff member</Button>}
      />

      {error ? <ErrorNote message={error} /> : null}

      <div className="overflow-hidden rounded-xl border bg-card shadow-sm">
        <div className="overflow-x-auto scroll-slim">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Person</th>
                <th className="px-4 py-3 font-medium">Email</th>
                <th className="px-4 py-3 font-medium">Role</th>
                <th className="px-4 py-3 font-medium">Joined</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {(users ?? []).map((u) => (
                <tr key={u.id} className="border-t transition-colors hover:bg-muted/40">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold ${u.role === 'ADMIN' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300' : u.role === 'STAFF' ? 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300' : 'bg-muted text-muted-foreground'}`}>
                        {u.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}
                      </div>
                      <div>
                        <p className="font-medium leading-tight">{u.name}</p>
                        {u.customer ? <p className="text-[11px] text-muted-foreground">portal of {u.customer.name}</p> : null}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={u.role === 'ADMIN' ? 'border-amber-300 text-amber-700 dark:border-amber-800 dark:text-amber-300' : ''}>
                      {u.role === 'ADMIN' ? <ShieldCheck className="mr-1 h-3 w-3" /> : <UserRound className="mr-1 h-3 w-3" />}
                      {u.role}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-xs">{fmtDate(u.createdAt)}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold ${u.isActive ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-zinc-200 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400'}`}>
                      {u.isActive ? 'active' : 'deactivated'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    {u.id !== currentUserId && u.role !== 'CUSTOMER' ? (
                      <div className="flex justify-end gap-1.5">
                        <Button variant="outline" size="sm" className="h-7 text-[11px]" onClick={() => toggleActive(u)}>
                          {u.isActive ? 'Deactivate' : 'Activate'}
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 text-[11px] hover:text-destructive" onClick={() => removeUser(u)}>
                          Remove
                        </Button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">{u.id === currentUserId ? 'you' : '—'}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false) }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add a staff member</DialogTitle>
            <DialogDescription>Only the admin can add staff. They get day-to-day access with limited permissions.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Name *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Maya Iyer" />
            </div>
            <div className="space-y-1.5">
              <Label>Email *</Label>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="maya@brightloop.com" />
            </div>
            <div className="space-y-1.5">
              <Label>Temporary password *</Label>
              <Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="Over 8 chars, Aa1 + special" />
            </div>
            <div className="space-y-1.5">
              <Label>Role</Label>
              <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                <SelectTrigger aria-label="Role"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="STAFF">Internal staff</SelectItem>
                  <SelectItem value="ADMIN">Administrator</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button onClick={addStaff} disabled={busy || !form.name || !form.email || !form.password}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null} Add member
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
