'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { CYCLE_LABEL, fmtDate, fmtMoney } from './format'
import { ErrorNote, PageHeader, Spinner, StatCard } from './ui-bits'
import type { BillingPreview } from './types'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  AlertTriangle, CalendarClock, FileText, Loader2, PlayCircle, RefreshCw,
  Timer, Wallet,
} from 'lucide-react'
import { toast } from '@/hooks/use-toast'

export function BillingRuns({ onChanged }: { onChanged?: () => void }) {
  const [preview, setPreview] = useState<BillingPreview | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [running, setRunning] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      setPreview(await api.get<BillingPreview>('/api/billing'))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load billing preview')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  async function runBilling() {
    setRunning(true)
    try {
      const res = await api.post<{ invoicesCreated: number; subscriptionsClosed: number }>('/api/billing')
      toast({
        title: 'Billing day complete',
        description: `${res.invoicesCreated} invoice(s) created, ${res.subscriptionsClosed} finished plan(s) closed.`,
      })
      await load()
      onChanged?.()
    } catch (err) {
      toast({ title: 'Billing run failed', description: err instanceof Error ? err.message : 'Try again', variant: 'destructive' })
    } finally {
      setRunning(false)
    }
  }

  if (loading) return <Spinner />
  if (error || !preview) {
    return (
      <div className="space-y-3">
        <ErrorNote message={error || 'No data'} />
        <Button variant="outline" size="sm" onClick={load}>
          <RefreshCw className="h-4 w-4" /> Try again
        </Button>
      </div>
    )
  }

  const dueTotal = preview.due.reduce((sum, d) => sum + d.estimatedAmount, 0)

  return (
    <div className="space-y-6">
      <PageHeader
        title="Billing runs"
        subtitle="Everything billing day will do — review it, then run it."
        actions={
          <Button size="lg" onClick={runBilling} disabled={running || preview.dueCount === 0}>
            {running ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlayCircle className="mr-2 h-4.5 w-4.5" />}
            Run billing day
          </Button>
        }
      />

      {/* summary */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="Subscriptions due now" value={String(preview.dueCount)}
          sub="Next billing date reached, no open invoice" icon={CalendarClock} tone="teal"
        />
        <StatCard
          label="Estimated batch value" value={fmtMoney(dueTotal, true)}
          sub="Pre-tax sum of due subscription lines" icon={Wallet} tone="emerald"
        />
        <StatCard
          label="Plans ready to auto-close" value={String(preview.autoCloseCount)}
          sub="Past expiry on auto-close plans" icon={Timer} tone="amber"
        />
      </div>

      {/* how it works */}
      <Card className="border-dashed">
        <CardHeader>
          <CardTitle className="text-base">How billing day works</CardTitle>
          <CardDescription>One click walks the whole ledger</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {[
            { n: 1, title: 'Generate invoices', body: 'Every active subscription whose next billing date has arrived gets a fresh invoice.' },
            { n: 2, title: 'Apply discounts & tax', body: 'Eligible discount rules and the line tax rates are applied automatically.' },
            { n: 3, title: 'Advance the cycle', body: 'Next billing dates roll forward so nothing bills twice.' },
            { n: 4, title: 'Close finished plans', body: 'Auto-close plans past their expiry are wrapped up with a final invoice.' },
          ].map((step) => (
            <div key={step.n} className="flex items-start gap-3 rounded-xl bg-muted/50 p-3.5">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-[12.5px] font-bold text-primary-foreground">
                {step.n}
              </span>
              <div>
                <p className="text-[13.5px] font-bold">{step.title}</p>
                <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{step.body}</p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* due table */}
      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="text-base">Due for invoicing</CardTitle>
            <CardDescription>Oldest first — these are exactly what billing day will process</CardDescription>
          </div>
          {preview.dueCount > 0 ? (
            <span className="rounded-full bg-teal-100 px-3 py-1 text-xs font-bold text-teal-800 dark:bg-teal-950 dark:text-teal-300">
              {preview.dueCount} queued
            </span>
          ) : null}
        </CardHeader>
        <CardContent>
          {preview.due.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">
              Nothing is due — every active subscription already has this cycle&apos;s invoice. Check back tomorrow.
            </p>
          ) : (
            <div className="overflow-x-auto rounded-lg border">
              <table className="w-full min-w-[720px] text-sm">
                <thead className="bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2 font-medium">Subscription</th>
                    <th className="px-3 py-2 font-medium">Customer</th>
                    <th className="px-3 py-2 font-medium">Plan</th>
                    <th className="px-3 py-2 font-medium">Cycle</th>
                    <th className="px-3 py-2 font-medium">Billing date</th>
                    <th className="px-3 py-2 text-right font-medium">Est. amount</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.due.map((d) => (
                    <tr key={d.id} className="border-t transition-colors hover:bg-muted/40">
                      <td className="px-3 py-2 font-medium">{d.number}</td>
                      <td className="px-3 py-2">{d.customer}</td>
                      <td className="px-3 py-2">{d.plan}</td>
                      <td className="px-3 py-2 text-muted-foreground">{CYCLE_LABEL[d.billingCycle] ?? d.billingCycle}</td>
                      <td className="px-3 py-2">
                        <span className="inline-flex items-center gap-1.5">
                          {fmtDate(d.nextBillingDate)}
                          {d.overdueDays > 0 ? (
                            <span className="rounded-full bg-rose-100 px-2 py-0.5 text-[11px] font-semibold text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                              {d.overdueDays}d late
                            </span>
                          ) : null}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-right font-semibold">{fmtMoney(d.estimatedAmount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* auto close */}
      {preview.autoCloseCount > 0 ? (
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <AlertTriangle className="h-4.5 w-4.5 text-amber-500" /> Auto-close queue
              </CardTitle>
              <CardDescription>These plans are past their expiry and will close on the next run</CardDescription>
            </div>
            <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-800 dark:bg-amber-950 dark:text-amber-300">
              {preview.autoCloseCount} waiting
            </span>
          </CardHeader>
          <CardContent>
            <div className="divide-y overflow-hidden rounded-lg border">
              {preview.autoClose.map((s) => (
                <div key={s.id} className="flex flex-wrap items-center gap-3 px-3.5 py-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300">
                    <FileText className="h-4.5 w-4.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{s.number} · {s.customer.name}</p>
                    <p className="text-xs text-muted-foreground">{s.plan.name} · expired {fmtDate(s.expiryDate)}</p>
                  </div>
                  <span className="text-xs font-semibold text-amber-700 dark:text-amber-300">closes on next run</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  )
}
