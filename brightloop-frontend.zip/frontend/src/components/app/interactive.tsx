'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'

/* ------------------------------------------------------------------ */
/* Animated count-up numbers                                           */
/* ------------------------------------------------------------------ */

/** Animates from the previous value to `target` with an ease-out curve. */
export function useCountUp(target: number, duration = 900): number {
  const [display, setDisplay] = useState(target)
  const fromRef = useRef(target)

  useEffect(() => {
    const reduced = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    if (reduced) {
      const id = requestAnimationFrame(() => {
        fromRef.current = target
        setDisplay(target)
      })
      return () => cancelAnimationFrame(id)
    }
    const from = fromRef.current
    const start = performance.now()
    let raf = 0
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(from + (target - from) * eased)
      if (t < 1) {
        raf = requestAnimationFrame(tick)
      } else {
        fromRef.current = target
      }
    }
    raf = requestAnimationFrame(tick)
    return () => {
      cancelAnimationFrame(raf)
      fromRef.current = target
    }
  }, [target, duration])

  return display
}

/** A number that counts up on mount and whenever the value changes. */
export function AnimatedNumber({
  value, format, className,
}: {
  value: number
  format?: (n: number) => string
  className?: string
}) {
  const v = useCountUp(value)
  return (
    <span className={cn('num', className)}>
      {format ? format(v) : Math.round(v).toLocaleString('en-IN')}
    </span>
  )
}

/* ------------------------------------------------------------------ */
/* Local storage state (SSR-safe)                                      */
/* ------------------------------------------------------------------ */

export function useLocalStorage<T>(key: string, initial: T): [T, (v: T | ((prev: T) => T)) => void] {
  const [value, setValue] = useState<T>(initial)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    queueMicrotask(() => {
      try {
        const raw = window.localStorage.getItem(key)
        if (raw !== null) setValue(JSON.parse(raw) as T)
      } catch { /* ignore */ }
      setReady(true)
    })
  }, [key])

  useEffect(() => {
    if (!ready) return
    try { window.localStorage.setItem(key, JSON.stringify(value)) } catch { /* ignore */ }
  }, [key, value, ready])

  return [value, setValue as (v: T | ((prev: T) => T)) => void]
}

/* ------------------------------------------------------------------ */
/* Sortable + paginated table state                                    */
/* ------------------------------------------------------------------ */

export type SortDir = 'asc' | 'desc'
export type SortState = { key: string; dir: SortDir } | null

export function useTable<T>(rows: T[], opts?: { initialSort?: SortState; pageSize?: number }) {
  const [sort, setSort] = useState<SortState>(opts?.initialSort ?? null)
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(opts?.pageSize ?? 10)

  const toggleSort = useCallback((key: string) => {
    setSort((s) => {
      if (s && s.key === key) return s.dir === 'asc' ? { key, dir: 'desc' } : null
      return { key, dir: 'asc' }
    })
    setPage(1)
  }, [])

  const sorted = useMemo(() => {
    if (!sort) return rows
    const mul = sort.dir === 'asc' ? 1 : -1
    return [...rows].sort((a, b) => {
      const av = (a as Record<string, unknown>)[sort.key]
      const bv = (b as Record<string, unknown>)[sort.key]
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * mul
      return String(av ?? '').localeCompare(String(bv ?? '')) * mul
    })
  }, [rows, sort])

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize))
  const safePage = Math.min(page, totalPages)
  const paged = useMemo(
    () => sorted.slice((safePage - 1) * pageSize, safePage * pageSize),
    [sorted, safePage, pageSize],
  )

  return {
    sort, toggleSort,
    page: safePage, setPage,
    pageSize, setPageSize: (n: number) => { setPageSize(n); setPage(1) },
    sorted, paged, totalPages,
  }
}

/** Returns `value` after it has stopped changing for `ms` (keeps search boxes from firing a request per keystroke). */
export function useDebounced<T>(value: T, ms = 300): T {
  const [v, setV] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms)
    return () => clearTimeout(t)
  }, [value, ms])
  return v
}

/**
 * Paging + sorting state for tables whose rows are fetched one page at a time from the API.
 * `apply(params)` adds limit / offset / sort / dir to a query string.
 */
export function useServerTable(opts?: { initialSort?: SortState; pageSize?: number }) {
  const [sort, setSort] = useState<SortState>(opts?.initialSort ?? null)
  const [page, setPage] = useState(1)
  const [pageSize, setPageSizeState] = useState(opts?.pageSize ?? 10)

  const toggleSort = useCallback((key: string) => {
    setSort((s) => {
      if (s && s.key === key) return s.dir === 'asc' ? { key, dir: 'desc' } : null
      return { key, dir: 'asc' }
    })
    setPage(1)
  }, [])

  const apply = useCallback((params: URLSearchParams) => {
    params.set('limit', String(pageSize))
    params.set('offset', String((page - 1) * pageSize))
    if (sort) {
      params.set('sort', sort.key)
      params.set('dir', sort.dir)
    }
  }, [page, pageSize, sort])

  return {
    sort, toggleSort, page, setPage, pageSize, apply,
    setPageSize: (n: number) => { setPageSizeState(n); setPage(1) },
    totalPagesFor: (total: number) => Math.max(1, Math.ceil(total / pageSize)),
  }
}

/** Clickable table header with a sort-direction indicator. */
export function SortTh({
  label, k, sort, onSort, align = 'left', className,
}: {
  label: string
  k: string
  sort: SortState
  onSort: (key: string) => void
  align?: 'left' | 'right' | 'center'
  className?: string
}) {
  const active = sort?.key === k
  const dir = active ? sort.dir : null
  return (
    <th
      className={cn('px-4 py-3 font-medium', align === 'right' && 'text-right', align === 'center' && 'text-center', className)}
      aria-sort={active ? (dir === 'asc' ? 'ascending' : 'descending') : 'none'}
    >
      <button
        onClick={() => onSort(k)}
        className={cn(
          'group inline-flex items-center gap-1 rounded transition-colors hover:text-foreground',
          align === 'right' && 'flex-row-reverse',
        )}
      >
        {label}
        {dir === 'asc' ? (
          <ArrowUp className="h-3 w-3 text-primary" aria-hidden="true" />
        ) : dir === 'desc' ? (
          <ArrowDown className="h-3 w-3 text-primary" aria-hidden="true" />
        ) : (
          <ArrowUpDown className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-60" aria-hidden="true" />
        )}
      </button>
    </th>
  )
}

/** Table footer with row counts, page size and page controls. */
export function Pager({
  page, totalPages, total, pageSize, onPage, onPageSize,
}: {
  page: number
  totalPages: number
  total: number
  pageSize: number
  onPage: (p: number) => void
  onPageSize: (n: number) => void
}) {
  if (total === 0) return null
  const from = (page - 1) * pageSize + 1
  const to = Math.min(total, page * pageSize)
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 border-t px-4 py-2.5 text-xs text-muted-foreground">
      <p>
        Showing <b className="font-semibold text-foreground">{from}–{to}</b> of{' '}
        <b className="font-semibold text-foreground">{total}</b>
      </p>
      <div className="flex items-center gap-2.5">
        <label className="flex items-center gap-1.5">
          <span className="hidden sm:inline">Rows</span>
          <select
            value={pageSize}
            onChange={(e) => onPageSize(Number(e.target.value))}
            aria-label="Rows per page"
            className="rounded-md border bg-card px-1.5 py-1 text-xs outline-none transition-colors hover:border-primary/40"
          >
            {[10, 25, 50].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </label>
        <Button variant="outline" size="icon" className="h-7 w-7" disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label="Previous page">
          <ChevronLeft className="h-3.5 w-3.5" />
        </Button>
        <span className="tabular-nums">Page {page} of {totalPages}</span>
        <Button variant="outline" size="icon" className="h-7 w-7" disabled={page >= totalPages} onClick={() => onPage(page + 1)} aria-label="Next page">
          <ChevronRight className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Loading skeletons                                                   */
/* ------------------------------------------------------------------ */

const SKELETON_WIDTHS = ['w-20', 'w-36', 'w-24', 'w-16', 'w-24', 'w-14', 'w-20', 'w-16', 'w-24']

/** Skeleton shaped like the data tables used across the workspace. */
export function TableSkeleton({ rows = 6, cols = 6 }: { rows?: number; cols?: number }) {
  return (
    <div className="overflow-hidden rounded-xl border bg-card" aria-hidden="true">
      <div className="flex gap-4 bg-muted/60 px-4 py-3.5">
        {Array.from({ length: cols }).map((_, i) => (
          <Skeleton key={i} className={cn('h-3', SKELETON_WIDTHS[i % SKELETON_WIDTHS.length])} />
        ))}
      </div>
      <div className="divide-y">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="flex items-center gap-4 px-4 py-4" style={{ opacity: 1 - r * 0.09 }}>
            {Array.from({ length: cols }).map((_, c) => (
              <Skeleton key={c} className={cn('h-3.5', SKELETON_WIDTHS[(c + r) % SKELETON_WIDTHS.length])} />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}

/** Skeleton for a row of stat/KPI cards. */
export function CardsSkeleton({ count = 4, className }: { count?: number; className?: string }) {
  return (
    <div className={cn('grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4', className)} aria-hidden="true">
      {Array.from({ length: count }).map((_, i) => (
        <Skeleton key={i} className="h-28 rounded-lg" style={{ opacity: 1 - i * 0.09 }} />
      ))}
    </div>
  )
}

/** Skeleton for a chart block. */
export function ChartSkeleton({ className }: { className?: string }) {
  return (
    <div className={cn('flex h-64 items-end gap-2 px-6 pb-6 pt-4', className)} aria-hidden="true">
      {[38, 62, 45, 78, 55, 90, 48, 70, 60, 84, 52, 74].map((h, i) => (
        <Skeleton key={i} className="flex-1 rounded-t-md" style={{ height: `${h}%` }} />
      ))}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Segmented control                                                   */
/* ------------------------------------------------------------------ */

export function Segmented<T extends string>({
  value, onChange, options, size = 'md', 'aria-label': ariaLabel,
}: {
  value: T
  onChange: (v: T) => void
  options: { value: T; label: string }[]
  size?: 'sm' | 'md'
  'aria-label'?: string
}) {
  return (
    <div role="tablist" aria-label={ariaLabel} className="inline-flex items-center gap-0.5 rounded-lg border bg-muted/50 p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          role="tab"
          aria-selected={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            'rounded-md font-semibold transition-all duration-200',
            size === 'sm' ? 'px-2.5 py-1 text-[11.5px]' : 'px-3 py-1.5 text-xs',
            value === o.value
              ? 'bg-card text-foreground shadow-sm ring-1 ring-black/[0.06] dark:ring-white/10'
              : 'text-muted-foreground hover:text-foreground',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Progress ring                                                       */
/* ------------------------------------------------------------------ */

export function ProgressRing({
  value, size = 44, stroke = 4, className, children,
}: {
  value: number
  size?: number
  stroke?: number
  className?: string
  children?: React.ReactNode
}) {
  const pct = useCountUp(Math.max(0, Math.min(100, value)), 1100)
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  return (
    <div className={cn('relative inline-flex shrink-0 items-center justify-center', className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden="true">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} className="stroke-current opacity-20" />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (pct / 100) * c}
        />
      </svg>
      {children ? (
        <div className="absolute inset-0 flex items-center justify-center">{children}</div>
      ) : null}
    </div>
  )
}
