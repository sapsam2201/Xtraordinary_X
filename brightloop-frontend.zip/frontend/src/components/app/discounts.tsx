'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { fmtDate, fmtMoney, toDateInput } from './format'
import { ErrorNote, PageHeader, Spinner } from './ui-bits'
import type { DiscountRule, Product } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { toast } from '@/hooks/use-toast'
import { BadgePercent, Loader2, Percent, Plus, Tag, Trash2 } from 'lucide-react'

const EMPTY = {
  name: '', type: 'PERCENTAGE', value: '', scope: 'SUBSCRIPTION', productId: '',
  minPurchase: '', minQuantity: '', startDate: toDateInput(new Date()), endDate: '', maxUses: '',
}

export function Discounts({ isAdmin }: { isAdmin: boolean }) {
  const [discounts, setDiscounts] = useState<DiscountRule[] | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [error, setError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [form, setForm] = useState({ ...EMPTY })
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    setError('')
    try {
      const [d, p] = await Promise.all([
        api.get<{ discounts: DiscountRule[] }>('/api/discounts'),
        api.get<{ products: Product[] }>('/api/products'),
      ])
      setDiscounts(d.discounts)
      setProducts(p.products)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load discounts')
    }
  }, [])

  useEffect(() => { load() }, [load])

  async function save() {
    setBusy(true)
    try {
      await api.post('/api/discounts', {
        ...form,
        value: Number(form.value),
        minPurchase: form.minPurchase === '' ? null : Number(form.minPurchase),
        minQuantity: form.minQuantity === '' ? null : Number(form.minQuantity),
        maxUses: form.maxUses === '' ? null : Number(form.maxUses),
      })
      toast({ title: 'Discount rule created', description: 'It will apply to the next invoices automatically.' })
      setFormOpen(false)
      setForm({ ...EMPTY })
      await load()
    } catch (err) {
      toast({ title: 'Could not create discount', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function toggleActive(d: DiscountRule) {
    try {
      await api.patch(`/api/discounts/${d.id}`, { active: !d.active })
      await load()
    } catch (err) {
      toast({ title: 'Could not update', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function remove(d: DiscountRule) {
    if (!confirm(`Delete discount "${d.name}"?`)) return
    try {
      await api.del(`/api/discounts/${d.id}`)
      toast({ title: 'Discount deleted' })
      await load()
    } catch (err) {
      toast({ title: 'Could not delete', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  if (!discounts && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Discounts"
        subtitle="Fixed amounts or percentages with conditions — they appear on the next invoice on their own and stop when they expire or run out."
        actions={
          isAdmin ? (
            <Button onClick={() => { setForm({ ...EMPTY }); setFormOpen(true) }}>
              <Plus className="mr-1.5 h-4 w-4" /> New discount rule
            </Button>
          ) : (
            <p className="text-xs text-muted-foreground">Only the admin can create discount rules.</p>
          )
        }
      />

      {error ? <ErrorNote message={error} /> : null}

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
        {(discounts ?? []).map((d) => {
          const now = new Date()
          const expired = new Date(d.endDate) < now
          const exhausted = d.maxUses != null && d.usedCount >= d.maxUses
          const off = d.active === false || expired || exhausted
          return (
            <div key={d.id} className={`rounded-xl border bg-card p-4 shadow-sm transition-shadow hover:shadow-md ${off ? 'opacity-65' : ''}`}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-primary/12 p-2.5 text-primary">
                    {d.type === 'PERCENTAGE' ? <Percent className="h-5 w-5" /> : <Tag className="h-5 w-5" />}
                  </div>
                  <div>
                    <p className="font-semibold leading-tight">{d.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {d.type === 'PERCENTAGE' ? `${d.value}% off` : `${fmtMoney(d.value)} off`} ·{' '}
                      {d.scope === 'PRODUCT' ? d.product?.name : 'whole subscription'}
                    </p>
                  </div>
                </div>
                {isAdmin ? (
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" className="h-7 text-[11px]" onClick={() => toggleActive(d)}>
                      {d.active ? 'Disable' : 'Enable'}
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-destructive" onClick={() => remove(d)} aria-label="Delete discount">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ) : null}
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div><span className="text-muted-foreground">Window</span><p className="font-medium">{fmtDate(d.startDate)} → {fmtDate(d.endDate)}</p></div>
                <div><span className="text-muted-foreground">Conditions</span><p className="font-medium">
                  {d.minQuantity ? `min ${d.minQuantity} units` : null}
                  {d.minPurchase ? `${d.minQuantity ? ' · ' : ''}min ${fmtMoney(d.minPurchase)}` : null}
                  {!d.minQuantity && !d.minPurchase ? 'none' : null}
                </p></div>
              </div>

              {d.maxUses != null ? (
                <div className="mt-3">
                  <div className="mb-1 flex items-center justify-between text-[11px] text-muted-foreground">
                    <span>Usage limit</span>
                    <span className="font-semibold">{d.usedCount}/{d.maxUses}{expired ? ' · expired' : exhausted ? ' · used up' : ''}</span>
                  </div>
                  <Progress value={Math.min(100, (d.usedCount / d.maxUses) * 100)} className="h-1.5" />
                </div>
              ) : (
                <p className="mt-3 text-[11px] text-muted-foreground">Used {d.usedCount} times · no limit</p>
              )}
            </div>
          )
        })}
      </div>

      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false) }}>
        <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto scroll-slim">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><BadgePercent className="h-5 w-5 text-primary" /> New discount rule</DialogTitle>
            <DialogDescription>Only admins create discounts. They apply automatically on the next invoice when their conditions are met.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Name *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="VOLUME10" />
            </div>
            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger aria-label="Discount type"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PERCENTAGE">Percentage</SelectItem>
                  <SelectItem value="FIXED">Fixed amount</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>{form.type === 'PERCENTAGE' ? 'Percent off *' : 'Amount off (₹) *'}</Label>
              <Input type="number" min={0} step="0.01" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} placeholder={form.type === 'PERCENTAGE' ? '10' : '200'} />
            </div>
            <div className="space-y-1.5">
              <Label>Applies to</Label>
              <Select value={form.scope} onValueChange={(v) => setForm({ ...form, scope: v, productId: '' })}>
                <SelectTrigger aria-label="Discount scope"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="SUBSCRIPTION">Whole subscription</SelectItem>
                  <SelectItem value="PRODUCT">Specific product</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Product</Label>
              <Select value={form.productId || 'none'} onValueChange={(v) => setForm({ ...form, productId: v === 'none' ? '' : v })} disabled={form.scope !== 'PRODUCT'}>
                <SelectTrigger aria-label="Discount product"><SelectValue placeholder={form.scope === 'PRODUCT' ? 'Choose product' : '—'} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">—</SelectItem>
                  {products.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Minimum purchase (₹)</Label>
              <Input type="number" min={0} value={form.minPurchase} onChange={(e) => setForm({ ...form, minPurchase: e.target.value })} placeholder="optional" />
            </div>
            <div className="space-y-1.5">
              <Label>Minimum quantity</Label>
              <Input type="number" min={1} value={form.minQuantity} onChange={(e) => setForm({ ...form, minQuantity: e.target.value })} placeholder="optional" />
            </div>
            <div className="space-y-1.5">
              <Label>Start date *</Label>
              <Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>End date *</Label>
              <Input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Max uses</Label>
              <Input type="number" min={1} value={form.maxUses} onChange={(e) => setForm({ ...form, maxUses: e.target.value })} placeholder="unlimited" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={busy || !form.name || !form.value || !form.endDate}
              title={form.scope === 'PRODUCT' && !form.productId ? 'Choose a product' : undefined}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
              Create rule
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
