'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from './api-client'
import { CYCLE_LABEL, fmtMoney } from './format'
import { EmptyState, ErrorNote, PageHeader, Spinner } from './ui-bits'
import { LinesEditor, type LineDraft } from './lines-editor'
import type { Plan, Product, QuotationTemplate, TaxRule } from './types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from '@/hooks/use-toast'
import { FileStack, Loader2, Pencil, Plus, Trash2 } from 'lucide-react'

export function Templates() {
  const [templates, setTemplates] = useState<QuotationTemplate[] | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [plans, setPlans] = useState<Plan[]>([])
  const [taxRules, setTaxRules] = useState<TaxRule[]>([])
  const [error, setError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [planId, setPlanId] = useState('')
  const [validDays, setValidDays] = useState('30')
  const [lines, setLines] = useState<LineDraft[]>([])

  const load = useCallback(async () => {
    setError('')
    try {
      const [t, p, pl, tr] = await Promise.all([
        api.get<{ templates: QuotationTemplate[] }>('/api/templates'),
        api.get<{ products: Product[] }>('/api/products'),
        api.get<{ plans: Plan[] }>('/api/plans'),
        api.get<{ taxRules: TaxRule[] }>('/api/tax-rules'),
      ])
      setTemplates(t.templates)
      setProducts(p.products)
      setPlans(pl.plans)
      setTaxRules(tr.taxRules)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load templates')
    }
  }, [])

  useEffect(() => { load() }, [load])

  function openCreate() {
    setName('')
    setDescription('')
    setPlanId('')
    setValidDays('30')
    setLines([{
      productId: products[0]?.id ?? '', variantId: null, quantity: 1,
      unitPrice: products[0]?.salesPrice ?? 0, taxRate: taxRules[0]?.rate ?? 0,
    }])
    setFormOpen(true)
  }

  async function save() {
    setBusy(true)
    try {
      await api.post('/api/templates', {
        name, description, planId: planId || null, validDays: Number(validDays) || 30, lines,
      })
      toast({ title: 'Template created', description: 'Sales can now start subscriptions from it.' })
      setFormOpen(false)
      await load()
    } catch (err) {
      toast({ title: 'Could not save template', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function remove(t: QuotationTemplate) {
    if (!confirm(`Delete template "${t.name}"?`)) return
    try {
      await api.del(`/api/templates/${t.id}`)
      toast({ title: 'Template deleted' })
      await load()
    } catch (err) {
      toast({ title: 'Could not delete', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  if (!templates && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Quotation templates"
        subtitle="Ready-made plan and product lines that stay valid for a set number of days — quotes in two clicks."
        actions={<Button onClick={openCreate}><Plus className="mr-1.5 h-4 w-4" /> New template</Button>}
      />

      {error ? <ErrorNote message={error} /> : null}

      {templates && templates.length === 0 ? (
        <EmptyState icon={FileStack} title="No templates yet" hint="Create a template so sales reps can start from the right plan and product lines." />
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {(templates ?? []).map((t) => {
            const total = t.lines.reduce((s, l) => s + l.quantity * l.unitPrice * (1 + l.taxRate / 100), 0)
            return (
              <div key={t.id} className="group flex flex-col rounded-xl border bg-card p-4 shadow-sm transition-shadow hover:shadow-md">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold leading-tight">{t.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {t.plan ? `${t.plan.name} · ${CYCLE_LABEL[t.plan.billingCycle]}` : 'Ad-hoc lines'} · valid {t.validDays} days
                    </p>
                  </div>
                  <div className="flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                    <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-destructive" onClick={() => remove(t)} aria-label="Delete template">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
                {t.description ? <p className="mt-2 text-xs text-muted-foreground">{t.description}</p> : null}
                <div className="mt-3 space-y-1 border-t pt-3 text-xs">
                  {t.lines.map((l) => (
                    <div key={l.id} className="flex items-center justify-between gap-2">
                      <span className="truncate text-muted-foreground">{l.quantity}× {l.product?.name}</span>
                      <span className="font-medium">{fmtMoney(l.quantity * l.unitPrice)}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-center justify-between border-t pt-3">
                  <span className="text-xs text-muted-foreground">Quote total incl. tax</span>
                  <span className="font-bold">{fmtMoney(total)}</span>
                </div>
              </div>
            )
          })}
        </div>
      )}

      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false) }}>
        <DialogContent className="max-h-[92vh] max-w-3xl overflow-y-auto scroll-slim">
          <DialogHeader>
            <DialogTitle>New quotation template</DialogTitle>
            <DialogDescription>Pick the plan, the product lines and how long the quote stays valid.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1.5">
              <Label>Template name *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Enterprise Suite" />
            </div>
            <div className="space-y-1.5">
              <Label>Linked plan</Label>
              <Select value={planId || 'none'} onValueChange={(v) => setPlanId(v === 'none' ? '' : v)}>
                <SelectTrigger aria-label="Linked plan"><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {plans.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Valid for (days)</Label>
              <Input type="number" min={1} value={validDays} onChange={(e) => setValidDays(e.target.value)} />
            </div>
            <div className="space-y-1.5 sm:col-span-3">
              <Label>Description</Label>
              <Textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Product lines</Label>
            <LinesEditor lines={lines} onChange={setLines} products={products} taxRules={taxRules} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={busy || !name || lines.length === 0}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Pencil className="mr-1.5 h-4 w-4" />}
              Create template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
