'use client'

import { useEffect, useMemo, useState } from 'react'
import { api } from './api-client'
import { fmtDate, fmtMoney, METHOD_LABEL } from './format'
import { EmptyState, ErrorNote, PageHeader, Spinner } from './ui-bits'
import type { Payment } from './types'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { toast } from '@/hooks/use-toast'
import { Search, Wallet } from 'lucide-react'

const METHODS = ['ALL', 'BANK_TRANSFER', 'UPI', 'CARD', 'CASH', 'CHEQUE']

export function Payments() {
  const [payments, setPayments] = useState<Payment[] | null>(null)
  const [method, setMethod] = useState('ALL')
  const [q, setQ] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const params = new URLSearchParams()
        if (method !== 'ALL') params.set('method', method)
        if (from) params.set('from', from)
        if (to) params.set('to', to)
        const res = await api.get<{ payments: Payment[] }>(`/api/payments?${params}`)
        if (!cancelled) {
          setError('')
          setPayments(res.payments)
        }
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Failed to load payments')
      }
    })()
    return () => { cancelled = true }
  }, [method, from, to])

  const filtered = useMemo(() => {
    if (!payments) return []
    if (!q) return payments
    return payments.filter((p) =>
      `${p.number} ${p.invoice?.number ?? ''} ${p.customer?.name ?? ''}`.toLowerCase().includes(q.toLowerCase())
    )
  }, [payments, q])

  const total = filtered.reduce((s, p) => s + p.amount, 0)

  if (!payments && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Payments"
        subtitle="Money in — recorded with method, amount, date and a note against the right invoice."
      />

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap gap-1.5">
          {METHODS.map((m) => (
            <button key={m} onClick={() => setMethod(m)}
              className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                method === m ? 'border-primary bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:border-primary/40'
              }`}>
              {m === 'ALL' ? 'All methods' : METHOD_LABEL[m]}
            </button>
          ))}
        </div>
        <div className="relative ml-auto w-full sm:w-56">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search payment, invoice, customer…" className="pl-8" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="flex items-center gap-1.5">
          <Input type="date" className="w-36" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" />
          <span className="text-xs text-muted-foreground">to</span>
          <Input type="date" className="w-36" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" />
        </div>
      </div>

      {error ? <ErrorNote message={error} /> : null}

      {filtered.length === 0 ? (
        <EmptyState icon={Wallet} title="No payments found" hint="Payments are recorded from an invoice — open an outstanding invoice and record one." />
      ) : (
        <>
          <div className="overflow-hidden rounded-xl border bg-card shadow-sm">
            <div className="overflow-x-auto scroll-slim">
              <table className="w-full min-w-[760px] text-sm">
                <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3 font-medium">Payment</th>
                    <th className="px-4 py-3 font-medium">Date</th>
                    <th className="px-4 py-3 font-medium">Invoice</th>
                    <th className="px-4 py-3 font-medium">Customer</th>
                    <th className="px-4 py-3 font-medium">Method</th>
                    <th className="px-4 py-3 font-medium">Note</th>
                    <th className="px-4 py-3 text-right font-medium">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.slice(0, 300).map((p) => (
                    <tr key={p.id} className="border-t transition-colors hover:bg-muted/40">
                      <td className="px-4 py-3 font-semibold">{p.number}</td>
                      <td className="px-4 py-3 text-xs">{fmtDate(p.date)}</td>
                      <td className="px-4 py-3 font-medium">{p.invoice?.number}</td>
                      <td className="px-4 py-3">{p.customer?.name}</td>
                      <td className="px-4 py-3">
                        <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium">{METHOD_LABEL[p.method] ?? p.method}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{p.note ?? '—'}</td>
                      <td className="px-4 py-3 text-right font-semibold text-emerald-700 dark:text-emerald-400">{fmtMoney(p.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {filtered.length > 300 ? (
              <p className="border-t px-4 py-2 text-center text-xs text-muted-foreground">Showing the newest 300 of {filtered.length} payments.</p>
            ) : null}
          </div>
          <div className="flex justify-end">
            <Button variant="outline" className="pointer-events-none">
              Total in view: <b className="ml-1.5">{fmtMoney(total)}</b>
            </Button>
          </div>
        </>
      )}
    </div>
  )
}
