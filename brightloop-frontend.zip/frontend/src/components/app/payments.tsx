'use client'

import { useEffect, useRef, useState } from 'react'
import { api } from './api-client'
import { fmtDate, fmtMoney, METHOD_LABEL } from './format'
import { EmptyState, ErrorNote, PageHeader, Spinner } from './ui-bits'
import { Pager, SortTh, useDebounced, useServerTable } from './interactive'
import { ExportButton, filterQuery } from './export-button'
import type { Payment } from './types'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Search, Wallet } from 'lucide-react'

const METHODS = ['ALL', 'BANK_TRANSFER', 'UPI', 'CARD', 'CASH', 'CHEQUE']

export function Payments() {
  const [payments, setPayments] = useState<Payment[] | null>(null)
  const [total, setTotal] = useState(0)
  const [totalAmount, setTotalAmount] = useState(0)
  const [method, setMethod] = useState('ALL')
  const [q, setQ] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [error, setError] = useState('')
  const table = useServerTable({ initialSort: { key: 'date', dir: 'desc' }, pageSize: 25 })
  const qd = useDebounced(q, 300)
  const reqId = useRef(0)
  const { apply: applyPaging, setPage } = table

  useEffect(() => { setPage(1) }, [method, qd, from, to, setPage])

  useEffect(() => {
    const id = ++reqId.current
    ;(async () => {
      try {
        const params = new URLSearchParams()
        if (method !== 'ALL') params.set('method', method)
        if (qd.trim()) params.set('q', qd.trim())
        if (from) params.set('from', from)
        if (to) params.set('to', to)
        applyPaging(params)
        const res = await api.get<{ payments: Payment[]; total: number; totalAmount: number }>(`/api/payments?${params}`)
        if (id !== reqId.current) return
        setError('')
        setPayments(res.payments)
        setTotal(res.total)
        setTotalAmount(res.totalAmount)
      } catch (err) {
        if (id === reqId.current) setError(err instanceof Error ? err.message : 'Failed to load payments')
      }
    })()
  }, [method, qd, from, to, applyPaging])

  if (!payments && !error) return <Spinner />

  return (
    <div className="space-y-5">
      <PageHeader
        title="Payments"
        subtitle="Money in — recorded with method, amount, date and a note against the right invoice."
        actions={<ExportButton url={`/api/payments.csv${filterQuery({ method, q: qd.trim(), from, to })}`} filename="payments.csv" />}
      />

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap gap-1.5">
          {METHODS.map((m) => (
            <button key={m} onClick={() => setMethod(m)}
              className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                method === m ? 'border-primary bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:border-primary/40'
              }`}>
              {m === 'ALL' ? 'All methods' : METHOD_LABEL[m]}
            </button>
          ))}
        </div>
        <div className="relative ml-auto w-full sm:w-56">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search payment, invoice, customer…" className="pl-8" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="flex items-center gap-1.5">
          <Input type="date" className="w-36" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" />
          <span className="text-xs text-muted-foreground">to</span>
          <Input type="date" className="w-36" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" />
        </div>
      </div>

      {error ? <ErrorNote message={error} /> : null}

      {(payments ?? []).length === 0 ? (
        <EmptyState icon={Wallet} title="No payments found" hint="Payments are recorded from an invoice — open an outstanding invoice and record one." />
      ) : (
        <>
          <div className="overflow-hidden rounded-xl border bg-card shadow-sm">
            <div className="overflow-x-auto scroll-slim">
              <table className="w-full min-w-[760px] text-sm">
                <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <SortTh label="Payment" k="number" sort={table.sort} onSort={table.toggleSort} />
                    <SortTh label="Date" k="date" sort={table.sort} onSort={table.toggleSort} />
                    <SortTh label="Invoice" k="invoice" sort={table.sort} onSort={table.toggleSort} />
                    <SortTh label="Customer" k="customer" sort={table.sort} onSort={table.toggleSort} />
                    <SortTh label="Method" k="method" sort={table.sort} onSort={table.toggleSort} />
                    <th className="px-4 py-3 font-medium">Note</th>
                    <SortTh label="Amount" k="amount" sort={table.sort} onSort={table.toggleSort} align="right" />
                  </tr>
                </thead>
                <tbody>
                  {(payments ?? []).map((p) => (
                    <tr key={p.id} className="border-t transition-colors hover:bg-muted/40">
                      <td className="px-4 py-3 font-semibold">{p.number}</td>
                      <td className="px-4 py-3 text-xs">{fmtDate(p.date)}</td>
                      <td className="px-4 py-3 font-medium">{p.invoice?.number}</td>
                      <td className="px-4 py-3">{p.customer?.name}</td>
                      <td className="px-4 py-3">
                        <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium">{METHOD_LABEL[p.method] ?? p.method}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{p.note ?? '—'}</td>
                      <td className="px-4 py-3 text-right font-semibold text-emerald-700 dark:text-emerald-400">{fmtMoney(p.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pager page={table.page} totalPages={table.totalPagesFor(total)} total={total}
              pageSize={table.pageSize} onPage={table.setPage} onPageSize={table.setPageSize} />
          </div>
          <div className="flex justify-end">
            <Button variant="outline" className="pointer-events-none">
              Total for current filters: <b className="ml-1.5">{fmtMoney(totalAmount)}</b>
            </Button>
          </div>
        </>
      )}
    </div>
  )
}
