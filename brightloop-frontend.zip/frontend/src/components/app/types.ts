export type Role = 'ADMIN' | 'STAFF' | 'CUSTOMER'

export type SessionUser = {
  id: string
  email: string
  name: string
  role: Role
  customerId: string | null
  customerName?: string | null
}

export type Product = {
  id: string
  name: string
  type: string
  salesPrice: number
  costPrice: number
  notes: string | null
  active: boolean
  variants: ProductVariant[]
  _count?: { subLines: number }
}

export type ProductVariant = {
  id: string
  productId: string
  name: string
  value: string
  priceDelta: number
}

export type Plan = {
  id: string
  name: string
  description: string | null
  productId: string | null
  product?: { name: string } | null
  price: number
  billingCycle: string
  minQuantity: number
  availableFrom: string | null
  availableTo: string | null
  autoClose: boolean
  canCloseEarly: boolean
  canPause: boolean
  canRenew: boolean
  active: boolean
  _count?: { subscriptions: number }
}

export type TaxRule = { id: string; name: string; rate: number; active: boolean }

export type DiscountRule = {
  id: string
  name: string
  type: 'PERCENTAGE' | 'FIXED'
  value: number
  scope: 'PRODUCT' | 'SUBSCRIPTION'
  productId: string | null
  product?: { name: string } | null
  minPurchase: number | null
  minQuantity: number | null
  startDate: string
  endDate: string
  maxUses: number | null
  usedCount: number
  active: boolean
}

export type TemplateLine = {
  id: string
  productId: string
  product?: { name: string }
  variantId: string | null
  quantity: number
  unitPrice: number
  taxRate: number
  sortOrder: number
}

export type QuotationTemplate = {
  id: string
  name: string
  description: string | null
  planId: string | null
  plan?: { name: string; billingCycle: string; price: number } | null
  validDays: number
  lines: TemplateLine[]
}

export type Customer = {
  id: string
  name: string
  email: string
  phone: string | null
  company: string | null
  address: string | null
  city: string | null
  country: string | null
  taxId: string | null
  notes: string | null
  _count?: { subscriptions: number; invoices: number; payments: number }
}

export type SubscriptionLine = {
  id?: string
  productId: string
  variantId: string | null
  description: string | null
  product?: { name: string; variants?: ProductVariant[] }
  quantity: number
  unitPrice: number
  taxRate: number
  sortOrder?: number
}

export type Subscription = {
  id: string
  number: string
  customerId: string
  customer?: { id: string; name: string; email: string }
  planId: string | null
  plan?: Plan | null
  status: string
  startDate: string
  expiryDate: string | null
  paymentTerms: string
  nextBillingDate: string | null
  closedAt: string | null
  closeReason: string | null
  notes: string | null
  createdAt: string
  lines: SubscriptionLine[]
  invoices?: Invoice[]
  _count?: { invoices: number }
}

export type InvoiceLine = {
  id: string
  productId: string | null
  description: string
  quantity: number
  unitPrice: number
  discount: number
  taxRate: number
  taxAmount: number
  netAmount: number
  total: number
}

export type Payment = {
  id: string
  number: string
  invoiceId: string
  invoice?: { id: string; number: string; total: number }
  customerId: string
  customer?: { id: string; name: string }
  method: string
  amount: number
  date: string
  note: string | null
}

export type Invoice = {
  id: string
  number: string
  subscriptionId: string | null
  subscription?: { id: string; number: string; plan?: { name: string } | null } | null
  customerId: string
  customer?: Customer
  status: string
  issueDate: string
  dueDate: string
  subtotal: number
  discountTotal: number
  discountNote: string | null
  taxTotal: number
  total: number
  amountPaid: number
  sentAt: string | null
  paidAt: string | null
  periodStart: string | null
  periodEnd: string | null
  notes: string | null
  lines?: InvoiceLine[]
  payments?: Payment[]
  _count?: { payments: number }
}

export type DashboardData = {
  kpis: {
    activeSubscriptions: number
    customers: number
    mrr: number
    revenueInPeriod: number
    revenueThisMonth: number
    revenuePrevMonth: number
    outstandingTotal: number
    openInvoices: number
    overdueCount: number
    overdueAmount: number
  }
  invoicesByStatus: { status: string; count: number; total: number }[]
  subscriptionsByStatus: { status: string; count: number }[]
  subsByPlan: { plan: string; count: number }[]
  revenueByMonth: { month: string; revenue: number }[]
  recentInvoices: {
    id: string; number: string; customer: string; status: string
    total: number; amountPaid: number; issueDate: string; dueDate: string
  }[]
  overdueList: {
    id: string; number: string; customer: string; total: number
    amountPaid: number; dueDate: string; daysOverdue: number
  }[]
  upcomingRenewals: {
    id: string; number: string; customer: string; plan: string
    expiryDate: string; canRenew: boolean
  }[]
}

export type BillingPreview = {
  dueCount: number
  due: {
    id: string; number: string; customer: string; plan: string; billingCycle: string
    nextBillingDate: string; estimatedAmount: number; overdueDays: number
  }[]
  autoCloseCount: number
  autoClose: { id: string; number: string; customer: { name: string }; plan: { name: string }; expiryDate: string }[]
}

export type StaffUser = {
  id: string
  email: string
  name: string
  role: string
  isActive: boolean
  createdAt: string
  customerId: string | null
  customer?: { name: string } | null
}
