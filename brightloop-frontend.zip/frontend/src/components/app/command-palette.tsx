'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { api } from './api-client'
import { fmtMoney } from './format'
import { StatusBadge } from './ui-bits'
import type { Customer, Invoice, Subscription } from './types'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import {
  ArrowRight, CreditCard, FileText, Layers, RefreshCw, Search, Users,
} from 'lucide-react'

export type NavView = 'subscriptions' | 'invoices' | 'payments' | 'customers' | 'plans'

type Result =
  | { kind: 'customer'; id: string; title: string; hint: string }
  | { kind: 'subscription'; id: string; title: string; hint: string; status: string }
  | { kind: 'invoice'; id: string; title: string; hint: string; status: string; amount: number }

const QUICK_LINKS: { view: NavView; label: string; icon: typeof Layers; hint: string }[] = [
  { view: 'subscriptions', label: 'Go to Subscriptions', icon: RefreshCw, hint: 'Manage the full lifecycle' },
  { view: 'invoices', label: 'Go to Invoices & Billing', icon: FileText, hint: 'Draft, send, collect' },
  { view: 'payments', label: 'Go to Payments', icon: CreditCard, hint: 'Money in, by method' },
  { view: 'customers', label: 'Go to Customers', icon: Users, hint: 'Accounts & contact details' },
  { view: 'plans', label: 'Go to Plans', icon: Layers, hint: 'Pricing & billing cycles' },
]

export function CommandPalette({
  open, onOpenChange, onNavigate,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  onNavigate: (view: NavView, invoiceId?: string) => void
}) {
  const [q, setQ] = useState('')
  const [customers, setCustomers] = useState<Customer[]>([])
  const [subs, setSubs] = useState<Subscription[]>([])
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [loading, setLoading] = useState(false)
  const [cursor, setCursor] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!open) return
    queueMicrotask(() => {
      setQ('')
      setCursor(0)
      setLoading(true)
    })
    let cancelled = false
    Promise.all([
      api.get<{ customers: Customer[] }>('/api/customers'),
      api.get<{ subscriptions: Subscription[] }>('/api/subscriptions'),
      api.get<{ invoices: Invoice[] }>('/api/invoices'),
    ])
      .then(([c, s, i]) => {
        if (cancelled) return
        setCustomers(c.customers)
        setSubs(s.subscriptions)
        setInvoices(i.invoices)
      })
      .catch(() => {
        /* palette stays usable with quick links */
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => { cancelled = true }
  }, [open])

  const results = useMemo<Result[]>(() => {
    const needle = q.trim().toLowerCase()
    if (!needle) return []
    const out: Result[] = []
    for (const c of customers) {
      if (`${c.name} ${c.email} ${c.company ?? ''}`.toLowerCase().includes(needle)) {
        out.push({ kind: 'customer', id: c.id, title: c.name, hint: c.company || c.email })
      }
    }
    for (const s of subs) {
      if (`${s.number} ${s.customer?.name ?? ''} ${s.plan?.name ?? ''}`.toLowerCase().includes(needle)) {
        out.push({ kind: 'subscription', id: s.id, title: s.number, hint: `${s.customer?.name ?? '—'} · ${s.plan?.name ?? 'custom'}`, status: s.status })
      }
    }
    for (const i of invoices) {
      if (`${i.number} ${i.customer?.name ?? ''}`.toLowerCase().includes(needle)) {
        out.push({ kind: 'invoice', id: i.id, title: i.number, hint: i.customer?.name ?? '—', status: i.status, amount: i.total })
      }
    }
    return out.slice(0, 9)
  }, [q, customers, subs, invoices])

  const go = useCallback((r: Result) => {
    onOpenChange(false)
    if (r.kind === 'customer') onNavigate('customers')
    else if (r.kind === 'subscription') onNavigate('subscriptions')
    else onNavigate('invoices', r.id)
  }, [onNavigate, onOpenChange])

  function onKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setCursor((c) => Math.min(c + 1, results.length - 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setCursor((c) => Math.max(c - 1, 0))
    } else if (e.key === 'Enter' && results[cursor]) {
      e.preventDefault()
      go(results[cursor])
    }
  }

  const showQuick = !q.trim()

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        aria-describedby={undefined}
        className="top-[18%] max-w-xl translate-y-0 gap-0 overflow-hidden p-0"
        onKeyDown={onKeyDown}
      >
        <DialogTitle className="sr-only">Global search</DialogTitle>
        <div className="flex items-center gap-2.5 border-b px-4">
          <Search className="h-4.5 w-4.5 shrink-0 text-muted-foreground" aria-hidden="true" />
          <input
            ref={inputRef}
            autoFocus
            value={q}
            onChange={(e) => { setQ(e.target.value); setCursor(0) }}
            placeholder="Search customers, subscriptions, invoices…"
            aria-label="Search customers, subscriptions, invoices"
            className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
          <kbd className="hidden rounded border bg-muted px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground sm:block">ESC</kbd>
        </div>

        <div className="max-h-[46vh] overflow-y-auto scroll-slim p-2">
          {showQuick ? (
            <div>
              <p className="px-2 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">Quick actions</p>
              {QUICK_LINKS.map((l) => (
                <button key={l.view} onClick={() => { onOpenChange(false); onNavigate(l.view) }}
                  className="flex w-full items-center gap-3 rounded-md px-2 py-2 text-left transition-colors hover:bg-accent">
                  <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 text-primary">
                    <l.icon className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13.5px] font-medium">{l.label}</span>
                    <span className="block text-xs text-muted-foreground">{l.hint}</span>
                  </span>
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground/50" aria-hidden="true" />
                </button>
              ))}
            </div>
          ) : loading && results.length === 0 ? (
            <p className="px-3 py-8 text-center text-sm text-muted-foreground">Searching…</p>
          ) : results.length === 0 ? (
            <p className="px-3 py-8 text-center text-sm text-muted-foreground">No matches for “{q}”.</p>
          ) : (
            <div>
              {(['customer', 'subscription', 'invoice'] as const).map((kind) => {
                const group = results.filter((r) => r.kind === kind)
                if (group.length === 0) return null
                const label = kind === 'customer' ? 'Customers' : kind === 'subscription' ? 'Subscriptions' : 'Invoices'
                return (
                  <div key={kind} className="pb-1">
                    <p className="px-2 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">{label}</p>
                    {group.map((r) => {
                      const active = results[cursor] === r
                      return (
                        <button
                          key={`${r.kind}-${r.id}`}
                          onClick={() => go(r)}
                          onMouseEnter={() => setCursor(results.indexOf(r))}
                          className={`flex w-full items-center gap-3 rounded-md px-2 py-2 text-left transition-colors ${
                            active ? 'bg-accent' : ''
                          }`}
                        >
                          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-muted text-muted-foreground">
                            {r.kind === 'customer' ? <Users className="h-4 w-4" aria-hidden="true" />
                              : r.kind === 'subscription' ? <RefreshCw className="h-4 w-4" aria-hidden="true" />
                              : <FileText className="h-4 w-4" aria-hidden="true" />}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[13.5px] font-medium">{r.title}</span>
                            <span className="block truncate text-xs text-muted-foreground">{r.hint}</span>
                          </span>
                          {r.kind === 'invoice' ? (
                            <span className="text-[13px] font-semibold">{fmtMoney(r.amount)}</span>
                          ) : null}
                          {r.kind !== 'customer' ? <StatusBadge status={r.status} /> : null}
                        </button>
                      )
                    })}
                  </div>
                )
              })}
              <p className="px-2 pb-1 pt-2 text-[11px] text-muted-foreground">
                <kbd className="rounded border bg-muted px-1 py-0.5 text-[10px] font-semibold">↑↓</kbd> navigate ·{' '}
                <kbd className="rounded border bg-muted px-1 py-0.5 text-[10px] font-semibold">↵</kbd> open
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
