# Brightloop – Frontend (Next.js 16 + Tailwind + shadcn/ui)

Runs on http://localhost:3000. It has no database or business logic: every `/api/*` request is
proxied to the backend (separate project) configured in `next.config.ts`.

## Run
Start the backend first (http://127.0.0.1:8000), then:
```bash
./run.sh            # Windows: run.bat      (or: npm install && npm run dev)
```
Backend somewhere else? `BACKEND_URL=https://your-api.example.com npm run dev` (see `.env.example`).

## Layout
```
next.config.ts                  proxies /api/* to BACKEND_URL
src/app/page.tsx                app shell / routing between screens
src/components/app/             one file per screen: dashboard, subscriptions, invoices, payments,
                                plans, products, discounts, taxes, templates, customers, staff,
                                reports, billing-runs, portal (customer view), auth-screen ...
src/components/app/api-client.ts  fetch wrapper (Bearer token, 401 handling)
src/components/ui/              shadcn primitives
```

## Adding a screen (example: "coupons")
1. Create `src/components/app/coupons.tsx` (copy `taxes.tsx` as a starting point).
2. Load data with `api.get('/api/coupons')` from `api-client.ts`.
3. Register the screen in `shell.tsx` (sidebar item) and `page.tsx` (view switch).
